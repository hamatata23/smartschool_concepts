# Operations and integration

## Database access and permissions

Create the database/source schema separately. The normal worker needs SELECT on
the MySQL source, SELECT/INSERT on the output, and SELECT/INSERT/UPDATE on control.
`init-output` additionally needs CREATE and INDEX. The runtime also checks
table/column/index metadata. MySQL sources and engine tables must use InnoDB.
Named advisory locks must work through the connection/proxy you use; direct
connections are the tested path. Do not use a connection pool that changes server
sessions while a run is active.

MongoDB needs find on source/output/control, insert on output/control, update on
control, and listCollections/listIndexes. Initialization needs createCollection
and createIndex. Engine collections require simple collation. Extra unique/TTL
indexes are rejected. Give the application that records real exam results its own
source-writing credentials. The prediction worker does not update actual scores.

Keep source filter types and collation equivalent if comparing backends. The
example SQL uses binary string collation; MongoDB defaults to simple collation.
Existing SQL case-insensitive columns or MongoDB custom collations may select
different cohorts. The shared algorithm guarantees the same computation for
equivalent normalized inputs, not automatic equivalence of arbitrary schemas.

## Reading current results

Use `python app.py show-current --config ... --env-file .env` or the Python API:

```python
from adapters import connect
from settings import load_config, load_env

load_env(".env")
config = load_config("config.mongodb.recommend.json")
store = connect(config)
try:
    current = store.read_current()
    for row in current["results"]:
        print(row["student_id"], row["result"])
finally:
    store.close()
```

`active` contains `run_id`, `result_count`, timestamps, task, output and metadata.
Every result contains `pipeline_name`, `run_id`, `source_key`, `student_id`, task,
input hash, creation time and a nested result. SQL stores the nested object in
`result_json`; the adapter exposes it as `result`, matching MongoDB. Source IDs
are encoded as `int:123`, `str:123`, or `oid:...` so unlike native IDs cannot collide.

For direct database consumers: read the active pointer for the pipeline, then
query that exact `run_id` and pipeline in its named output. Pin the pointer once
per response. Do not select all rows or assume the newest timestamp is current.
MySQL stores the pointer in `active_json`; MongoDB stores it in `active` on the
control document whose `_id` is the pipeline name. Check result count, task,
configuration compatibility and freshness. The bundled reader performs contract
and count checks but does not enforce a business-specific maximum age.

## Publication and failures

MySQL inserts the new batch and updates the pointer in one InnoDB transaction.
A connection-scoped named lock excludes concurrent workers for the same database,
control table and pipeline. Losing the connection loses the lock; the adapter
does not silently reconnect during a transaction.

MongoDB stages an immutable batch, verifies its count, then atomically switches a
single control document's pointer. A time-limited owner token fences publication;
an expired or replaced worker cannot publish. The engine uses majority reads and
writes on primary connections. This protocol works without a multi-document
transaction. If staging fails, orphan rows can remain but the prior pointer stays
current. If the network fails during publication, the outcome may be unknown;
read the pointer to resolve it and rerun safely.

Both retain previous complete batches. A no-change run verifies the current count
and refreshes `last_checked_at` without creating duplicates. Empty batches are
published to clear current predictions/plans when no future exams or open weeks
remain. The engine detects missing records, but assumes application users do not
modify result payloads. Restrict write access to engine-owned outputs.

The source can change while a run executes. MySQL reads one repeatable-read source
query; MongoDB's normal cursor is not a point-in-time snapshot across documents.
Upcoming prediction inputs are re-read after training. `source_read_completed_at`
marks the read's completion, not a synchronization guarantee with later writes.
The next run reconciles edits. A strict cross-document snapshot or immediate
update trigger requires an additional source version/snapshot protocol.

The worker holds all selected rows in memory for this implementation. `max_rows`
is a hard guard; exceeding it fails instead of truncating. Split large datasets
into appropriate model cohorts. `batch_size` limits write chunks, not overall
memory. A MongoDB training job taking longer than `lease_seconds` cannot publish;
size that interval for the dataset, and keep host clocks synchronized.

Do not add TTL indexes or delete current batches. No automatic retention cleanup
is included. If you add retention, preserve all active run IDs and allow time for
readers that pinned an older run. Stop writers and coordinate readers for simple
manual cleanup. Keep durable backups of state and output history as needed.

## Model state and automatic runs

`state_dir/state.json` holds the current model and last training attempt.
`models/<version>.json` retains accepted model versions. `last_run.json` records
the latest local report. Writes are atomic; the state directory is locked against
overlap on the same host. A database lock/lease provides the separate publication
guard. This version is intended for a single scheduled worker per pipeline with
durable local state. Another host with empty state can safely publish, but will
retrain independently and have different model version IDs.

The bundled systemd templates assume `/opt/student_ai_engine`, a pre-created
`studentengine` account, a virtual environment at `.venv`, and credentials in
`.env` readable only by that service account. Create/chown the `var` directory
for state. Install code read-only for the worker. Example deployment commands,
after reviewing paths and setting up that account/environment:

```bash
sudo cp deploy/student-ai@.service deploy/student-ai@.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now student-ai@mysql.predict.timer
sudo systemctl enable --now student-ai@mysql.recommend.timer
```

For MongoDB use `mongodb.predict` / `mongodb.recommend` instances. Each instance
loads `config.<instance>.json`. Timers run hourly; check exit status and journal:

```bash
systemctl status student-ai@mysql.predict.service
journalctl -u student-ai@mysql.predict.service
```

Scheduler examples are supplied, not installed. `run-once` is also suitable for
cron or a school application's background worker. Alert on nonzero exits,
rejected retraining, stale current results and infeasible plans. A planner run
can finish successfully while some student plans are `infeasible`; inspect its
report and each plan status before showing allocations.

No universal prediction accuracy or study improvement is promised. Pilot with
representative historical outcomes and teacher review. A linear association
between study time and score does not establish a causal intervention. Changes
to courses, assessments or feature definitions require a new compatible model.

## References

- PyMongo: https://www.mongodb.com/docs/languages/python/pymongo-driver/current/
- MongoDB atomicity: https://www.mongodb.com/docs/manual/core/write-operations-atomicity/
- MySQL transactions: https://dev.mysql.com/doc/refman/8.4/en/commit.html
- MySQL named locks: https://dev.mysql.com/doc/refman/8.4/en/locking-functions.html
- MySQL upserts: https://dev.mysql.com/doc/refman/8.4/en/insert-on-duplicate.html
