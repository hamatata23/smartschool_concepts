# Validation record

Verified on 2026-10-14 using synthetic data only. No real student database was
connected, migrated or modified.

## Results

51 automated tests passed with zero skips when both live servers were enabled.
The normal offline run passes 47 tests and skips four opt-in live database tests.

| Environment | Version |
| --- | --- |
| Python | 3.12.14 |
| NumPy | 2.3.5 |
| PyMongo | 4.18.3 |
| PyMySQL | 1.2.3 |
| mongomock | 4.3.0 |
| MySQL test server | 8.4.5 |
| MongoDB test server | 8.0.16 |

Server versions above identify the temporary test environment; they are not a
recommendation to deploy those exact patch releases. Use maintained server
releases and your normal patch policy. Dependency ranges are in requirements;
pin the exact resolved environment for a repeatable production deployment.

The suite covers:

- Regression coefficients, ridge solvers, preprocessing, clipping, missing inputs
  and model serialization.
- Temporal validation, late-label exclusion, accepted/rejected retraining,
  corrections/deletions, incompatible feature changes, and unchanged-input reuse.
- Recommendation budgets, caps, rounded minimums, infeasible plans, missing
  scores, duplicate subjects, deterministic ordering and 100 randomized budgets.
- Database ID typing, SQL parameter binding, local overlap prevention, MongoDB
  lease ownership/expiry and current-batch contract checks.
- Live MySQL/MongoDB equality of recommendation payloads and input hashes.
- Live equality of regression model contents and prediction values; random
  model-version UUIDs and storage/run metadata are deliberately excluded.
- Live interrupted second-chunk writes: MySQL rollback removes staged rows;
  MongoDB can retain orphans, while both readers retain the prior complete batch.
  The interruption is injected at the driver call; it is not a server crash test.
- Live MySQL exclusion of a second worker on an independent connection.

Also completed seed, initialize, validate, run and read-current CLI smoke checks
for all four combinations: MySQL prediction, MySQL recommendation, MongoDB
prediction and MongoDB recommendation.

These checks verify implementation behavior, not real-school prediction accuracy.
TLS, authentication/role restrictions, replica-set failover, host crashes, huge
datasets, proxy behavior and native Windows were not covered by the live suite.

## Reproduce

```bash
python -m pip install -r requirements-dev.txt
python -m unittest discover -s tests -v
```

For live integration tests, start your own disposable servers, create the MySQL
database `student_engine_test`, and export both sets of connection environment
variables. Use accounts allowed to create and drop test tables/collections. These
tests create uniquely suffixed objects and drop those objects during cleanup.
They refuse database names not ending in `_engine_test`.

```bash
export TEST_DATABASE=student_engine_test
export RUN_DATABASE_INTEGRATION=1
# Export MYSQL_HOST, MYSQL_PORT, MYSQL_USER, MYSQL_PASSWORD and MONGODB_URI.
# Set MYSQL_SSL_CA when using a remote MySQL test server.
python -m unittest discover -s tests -v
```

The unittest runner reads exported variables; it does not load `.env` itself.
Supply disposable database credentials, never production credentials, for live
tests. `seed_demo.py` is separate and requires a database ending in `_engine_demo`.
