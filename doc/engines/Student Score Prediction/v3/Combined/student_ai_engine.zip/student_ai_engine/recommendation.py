"""Shared, explainable allocation of a weekly time budget across subjects.

These rules do not estimate a causal score gain from additional study hours.
"""
from collections import defaultdict
from datetime import time, timedelta
import math

from learning import digest, timestamp, utcnow

ALGORITHM_VERSION = "weekly-priority-blocks-v1"


def number(value, name, lower, upper, nullable=False, integer=False):
    if value is None and nullable:
        return None
    if isinstance(value, bool):
        raise ValueError(f"{name} must be numeric")
    try:
        value = float(value)
    except (ValueError, TypeError) as exc:
        raise ValueError(f"Invalid {name}") from exc
    if not math.isfinite(value) or not lower <= value <= upper or integer and value != int(value):
        raise ValueError(f"{name} outside allowed range or wrong numeric type")
    return int(value) if integer else value


def day(value, name, nullable=False):
    if value is None and nullable:
        return None
    result = timestamp(value, name)
    if result.time() != time():
        raise ValueError(f"{name} must be a date or midnight UTC")
    return result.date()


def recommend(rows, c, now=None):
    """Pure function: canonical rows in, deterministic recommendation records out."""
    now = now or utcnow()
    cols, rules = c["columns"], c["recommendation"]
    groups, seen, skipped = defaultdict(list), set(), 0
    for raw in rows:
        r = {key: raw[value] for key, value in cols.items()}
        if r["row_id"] in seen:
            raise ValueError("Duplicate source IDs")
        seen.add(r["row_id"])
        subject = r["subject"]
        if not isinstance(subject, str) or not subject.strip() or subject != subject.strip() or len(subject) > 128:
            raise ValueError("Subject must be an unpadded nonempty string <=128 characters")
        week = day(r["week_start"], "week_start")
        if week.weekday() != 0:
            raise ValueError("week_start must be a Monday")
        if week+timedelta(days=7) <= now.date():
            skipped += 1
            continue
        planning_date = max(week, now.date())
        exam = day(r["exam_date"], "exam_date", nullable=True)
        r["score"] = number(r["score"], "score", c["score_min"], c["score_max"], nullable=True)
        r["target_score"] = number(r["target_score"], "target_score", c["score_min"], c["score_max"])
        for name in ("available_minutes", "min_minutes"):
            r[name] = number(r[name], name, 0, 10080, integer=True)
        r["max_minutes"] = number(r["max_minutes"], "max_minutes", 0, 10080, integer=True, nullable=True)
        if r["max_minutes"] is None:
            r["max_minutes"] = r["available_minutes"]
        r["teacher_priority"] = number(r["teacher_priority"], "teacher_priority", .1, 10)
        gap = 0 if r["score"] is None else max(0, r["target_score"]-r["score"])
        days = None if exam is None else (exam-planning_date).days
        urgency = 0 if days is None or days < 0 else 1/(1+days/7)
        weight = r["teacher_priority"]*(1+rules["gap_weight"]*gap/(c["score_max"]-c["score_min"])+rules["urgency_weight"]*urgency)
        reasons = []
        if r["score"] is None:
            reasons.append("missing_score_teacher_review")
        elif gap > 0:
            reasons.append("below_target_score")
        else:
            reasons.append("maintain_current_progress")
        if days is not None and 0 <= days <= 7:
            reasons.append("exam_within_seven_days")
        r.update(week_start=week.isoformat(), exam_date=exam.isoformat() if exam else None,
                 planning_date=planning_date.isoformat(), score_gap=gap, days_until_exam=days,
                 weight=weight, reasons=reasons)
        groups[(r["student_id"], r["week_start"])].append(r)
    output, infeasible = [], 0
    block = rules["block_minutes"]
    for (student, week), subjects in sorted(groups.items()):
        subjects.sort(key=lambda r: (r["subject"].casefold(), r["row_id"]))
        if len({r["subject"].casefold() for r in subjects}) != len(subjects):
            raise ValueError("Duplicate subject within a student/week")
        budgets = {r["available_minutes"] for r in subjects}
        if len(budgets) != 1:
            raise ValueError("All subjects for a student/week must use the same remaining available_minutes")
        budget = budgets.pop()
        lower = [math.ceil(r["min_minutes"]/block) for r in subjects]
        upper = [math.floor(r["max_minutes"]/block) for r in subjects]
        capacity = budget//block
        feasible = all(a <= b for a, b in zip(lower, upper)) and sum(lower) <= capacity
        allocated = lower[:]
        if feasible:
            for _ in range(capacity-sum(allocated)):
                eligible = [i for i in range(len(subjects)) if allocated[i] < upper[i]]
                if not eligible:
                    break
                # Diminishing priority distributes remaining blocks; alphabetical
                # subject/source ordering resolves exact ties deterministically.
                best = max(eligible, key=lambda i: subjects[i]["weight"]/(allocated[i]-lower[i]+1))
                allocated[best] += 1
        else:
            infeasible += 1
        total = sum(allocated)*block if feasible else 0
        group_input = digest({"rules": rules, "algorithm": ALGORITHM_VERSION, "subjects": subjects})
        for i, r in enumerate(subjects):
            minutes = allocated[i]*block if feasible else None
            payload = {"status": "ready" if feasible else "infeasible", "subject": r["subject"],
                "week_start": week, "planning_date": r["planning_date"], "score": r["score"],
                "score_basis": rules["score_basis"], "target_score": r["target_score"],
                "score_gap": r["score_gap"], "priority_weight": r["weight"],
                "days_until_exam": r["days_until_exam"], "allocated_minutes": minutes,
                "allocated_hours": None if minutes is None else minutes/60,
                "available_minutes": budget, "group_allocated_minutes": total if feasible else None,
                "unallocated_minutes": budget-total if feasible else budget,
                "min_minutes": r["min_minutes"], "max_minutes": r["max_minutes"],
                "reason_codes": r["reasons"] if feasible else ["minimums_or_caps_infeasible"],
                "algorithm_version": ALGORITHM_VERSION}
            output.append({"source_key": r["row_id"], "student_id": student,
                "input_hash": digest([group_input, r["row_id"]]), "result": payload})
    return output, {"student_weeks": len(groups), "infeasible_student_weeks": infeasible,
                    "past_requests_skipped": skipped, "algorithm_version": ALGORITHM_VERSION}
