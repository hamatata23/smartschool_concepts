"""Configuration shared by both backends. Database code cannot select algorithms."""
import copy
import json
import math
import os
from pathlib import Path
import re


def identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,63}", value):
        raise ValueError("Names must be simple identifiers of at most 64 characters")
    return value


def load_env(path):
    if path is None:
        return
    for n, line in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), 1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, sep, value = line.partition("=")
        if not sep or not re.fullmatch(r"[A-Z][A-Z0-9_]*", key):
            raise ValueError(f"Invalid .env entry on line {n}")
        os.environ.setdefault(key, value)


def finite(value):
    return not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value)


def validate(config):
    c = copy.deepcopy(config)
    keys = {"backend", "task", "database", "pipeline_name", "state_dir", "source", "output", "control",
            "columns", "features", "feature_ranges", "filter_equals", "score_min", "score_max",
            "max_rows", "batch_size", "lease_seconds", "training", "recommendation"}
    if set(c) != keys:
        raise ValueError("Config keys differ from the example configs")
    if c["backend"] not in ("mysql", "mongodb") or c["task"] not in ("predict", "recommend"):
        raise ValueError("backend must be mysql/mongodb and task must be predict/recommend")
    for k in ("database", "pipeline_name", "source", "output", "control"):
        identifier(c[k])
    if len({c[k].lower() for k in ("source", "output", "control")}) != 3:
        raise ValueError("Source, output and control names must differ")
    if not isinstance(c["state_dir"], str) or not c["state_dir"].strip():
        raise ValueError("Provide a state_dir")
    for k, lower, upper in (("max_rows", 2, 10000000), ("batch_size", 1, 1000), ("lease_seconds", 30, 86400)):
        if type(c[k]) is not int or not lower <= c[k] <= upper:
            raise ValueError(f"Invalid {k}")
    if not all(finite(c[k]) for k in ("score_min", "score_max")) or c["score_min"] >= c["score_max"]:
        raise ValueError("Invalid score scale")
    expected = ({"row_id", "student_id", "target_date", "features_as_of", "label_available_at", "target"}
                if c["task"] == "predict" else {"row_id", "student_id", "subject", "week_start", "score", "target_score",
                    "available_minutes", "min_minutes", "max_minutes", "exam_date", "teacher_priority"})
    if not isinstance(c["columns"], dict) or set(c["columns"]) != expected:
        raise ValueError("Wrong column mapping for this task")
    for name in c["columns"].values():
        identifier(name)
    if len({n.lower() for n in c["columns"].values()}) != len(expected):
        raise ValueError("Mapped fields must be distinct")
    if c["backend"] == "mongodb" and c["columns"]["row_id"] != "_id":
        raise ValueError("MongoDB row_id must map to _id")
    if not isinstance(c["filter_equals"], dict):
        raise ValueError("filter_equals must be an object")
    for name, value in c["filter_equals"].items():
        identifier(name)
        if isinstance(value, (dict, list)) or isinstance(value, float) and not math.isfinite(value):
            raise ValueError("Filter values must be finite scalars")
    if not isinstance(c["features"], list) or len(set(c["features"])) != len(c["features"]):
        raise ValueError("Features must be a unique list")
    reserved = {"row_id", "student_id", "target_date", "features_as_of", "label_available_at", "actual_score"}
    for feature in c["features"]:
        identifier(feature)
        if feature.lower() in {x.lower() for x in c["columns"].values()} | reserved:
            raise ValueError("IDs, dates and target must not be features")
    if not isinstance(c["feature_ranges"], dict) or set(c["feature_ranges"]) - set(c["features"]):
        raise ValueError("Invalid feature_ranges")
    for bounds in c["feature_ranges"].values():
        if not isinstance(bounds, list) or len(bounds) != 2 or not all(finite(x) for x in bounds) or bounds[0] > bounds[1]:
            raise ValueError("Invalid feature bounds")
    if c["task"] == "predict":
        if not c["features"] or c["recommendation"] is not None:
            raise ValueError("Prediction needs features and recommendation=null")
        t = c["training"]
        if not isinstance(t, dict) or set(t) != {"validation_fraction", "min_training_rows", "min_validation_rows",
                "max_validation_mae", "require_better_than_mean_baseline", "l2", "solver", "learning_rate", "max_iterations", "tolerance"}:
            raise ValueError("Invalid training settings")
        for k in ("min_training_rows", "min_validation_rows", "max_iterations"):
            if type(t[k]) is not int or t[k] < 2:
                raise ValueError(f"Invalid {k}")
        for k in ("validation_fraction", "max_validation_mae", "l2", "learning_rate", "tolerance"):
            if not finite(t[k]):
                raise ValueError(f"Invalid {k}")
        if not 0 < t["validation_fraction"] < 1 or min(t["l2"], t["max_validation_mae"]) < 0:
            raise ValueError("Invalid validation or penalty settings")
        if min(t["learning_rate"], t["tolerance"]) <= 0 or t["solver"] not in ("lstsq", "gd"):
            raise ValueError("Invalid solver settings")
        if type(t["require_better_than_mean_baseline"]) is not bool:
            raise ValueError("Baseline gate must be boolean")
    else:
        if c["features"] or c["feature_ranges"] or c["training"] is not None:
            raise ValueError("Recommendation uses mapped subject inputs, no regression features/training settings")
        r = c["recommendation"]
        if not isinstance(r, dict) or set(r) != {"block_minutes", "gap_weight", "urgency_weight", "score_basis"}:
            raise ValueError("Invalid recommendation settings")
        if type(r["block_minutes"]) is not int or not 1 <= r["block_minutes"] <= 120:
            raise ValueError("block_minutes must be 1..120")
        if not all(finite(r[k]) and r[k] >= 0 for k in ("gap_weight", "urgency_weight")):
            raise ValueError("Priority weights must be finite and nonnegative")
        if r["score_basis"] not in ("recorded_average", "model_prediction"):
            raise ValueError("Specify the source of recommendation scores")
    return c


def load_config(path):
    path = Path(path).resolve()
    c = validate(json.loads(path.read_text(encoding="utf-8")))
    c["state_dir"] = str((path.parent/c["state_dir"]).resolve())
    return c
