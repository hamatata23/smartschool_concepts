# Student AI engine — MySQL and MongoDB

One Python engine with interchangeable database adapters and shared algorithms.
Select a backend and task in JSON; the learning and recommendation code is the
same for both databases. Includes `self_study_hours` (hours per day).

| Task | Reads | Writes | How it works |
| --- | --- | --- | --- |
| `predict` | `tbl_student_score` | `tbl_student_prediction_score` | Learns from actual scores, validates on later exams, predicts upcoming scores |
| `recommend` | `tbl_student_study_request` | `tbl_student_study_recommendation` | Divides a student's remaining weekly study budget across subjects using score gaps, exam dates and teacher priorities |

Names are configurable. In MongoDB these are collections; in MySQL they are
tables. Both use `tbl_student_engine_runs` to identify the current complete batch.
The engine reads source records and writes only its output/control tables or
collections. It does not synchronize the two databases or migrate existing data.

## 1. Install

Use Python 3.11+ on Linux, macOS, or WSL. The local process lock uses `fcntl`;
native Windows is not supported. MySQL must support native JSON and InnoDB
(tested on MySQL 8.4). MongoDB can be standalone or a replica set (tested on 8.0).

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
cp .env.example .env
chmod 600 .env
```

Edit `.env` with your credentials. Values are literal, without quotes, `export`,
or shell expansion. Already-exported environment variables take precedence.
MySQL uses `MYSQL_HOST`, `MYSQL_PORT`, `MYSQL_USER`, `MYSQL_PASSWORD`; the database
name comes from JSON. MongoDB uses `MONGODB_URI`; its URI `authSource` controls
authentication, while the JSON database is the data destination. Percent-encode
reserved characters in MongoDB URI credentials. Keep credentials out of JSON/git.
For remote MySQL set `MYSQL_SSL_CA`; use TLS for remote MongoDB connections.

## 2. Choose a configuration

| Backend | Prediction | Study recommendation |
| --- | --- | --- |
| MySQL | `config.mysql.predict.json` | `config.mysql.recommend.json` |
| MongoDB | `config.mongodb.predict.json` | `config.mongodb.recommend.json` |

Edit `database`, `source`, `output`, `control`, `pipeline_name`, and mappings for
your schema. Prediction defaults filter mathematics, grade 8. Change or remove
`filter_equals` for your cohort. Each subject/grade prediction model should have
its own pipeline name and state directory. Use a separate state directory for
every backend/task/pipeline. A configuration selects one backend per run; invoke
separate configurations if both databases need processing.

MySQL source DDL examples are in `examples/`. Create the database and source
schema/import your data before initializing outputs. MongoDB source collections
must exist and contain the configured fields. This engine does not create or
alter your real source schema automatically.

**Upgrading from the earlier editions:** the unified output schema is new. Use
fresh output and control names if the old tables/collections already exist, or
review a schema migration with backups. `init-output` does not convert legacy
results. Use fresh model state directories. Student IDs must now be strings.

## 3. Run

Example for MySQL prediction:

```bash
python app.py init-output --config config.mysql.predict.json --env-file .env
python app.py check --config config.mysql.predict.json --env-file .env
python app.py run-once --config config.mysql.predict.json --env-file .env
python app.py show-current --config config.mysql.predict.json --env-file .env
```

For MongoDB recommendation, use the same commands with
`--config config.mongodb.recommend.json`. `init-output` creates the new output
and control schema/indexes. `check` validates source data without publishing.
`run-once` reads, computes, and publishes. `show-current` reads only the current
complete batch; it returns JSON with `active` metadata and `results`.

An unchanged successful run reuses its batch. Prediction runs retrain when actual
labeled records or training settings change, including corrections and deletions.
Use `--force-retrain` with `run-once` to retry deliberately. Upcoming input changes
refresh predictions without retraining the model. Run hourly with the included
systemd templates, or your existing scheduler, to make this automatic. No scheduler
has been installed or connected to your real database by this package.

## Prediction data

One row/document represents one student exam attempt with a stable unique ID.

| Field | Meaning |
| --- | --- |
| `id` / `_id` | Unique source key; MongoDB supports ObjectId, integer, or string |
| `student_id` | Nonempty string, e.g. `STUDENT-001` |
| `subject`, `grade_level` | Example cohort filters |
| `exam_date` | Date of the exam being predicted |
| `features_as_of` | When the input snapshot was available, strictly before the exam |
| `study_hours_per_week` | Study hours per week, consistently defined |
| `attendance_percent` | 0–100 attendance percentage |
| `previous_score` | Score from an earlier assessment on the same scale |
| `sleep_hours_per_night` | Average hours per night |
| `assignments_completed_percent` | Percentage completed before the snapshot |
| `self_study_hours` | Self-study hours per day, 0–24 |
| `final_score` | Actual exam result; NULL/null until known; zero is a real score |
| `score_recorded_at` | When the actual result became available; NULL/null while unknown |

Use SQL DATE/DATETIME in UTC or MongoDB BSON dates in UTC. Date-only fields must
be midnight UTC; ISO date/timestamp strings are also accepted in MongoDB. Every
mapped metadata field must exist, including explicit nulls. Missing numeric
features are imputed with training medians; rows with all features missing fail.
An entirely missing feature in training prevents fitting that model.

To keep existing names such as `study_hours`, `attendance`, `sleep_hours`, and
`assignments`, edit the `features` list and matching `feature_ranges` keys. To use
`exam_score` as the actual result, set `columns.target` to `exam_score`; **do not
also put that same exam's score in the feature list**. Establish units and score
scales consistently before combining datasets. Snapshot historical inputs as they
were before each exam; final attendance or assignments measured after the exam
would leak information into training.

The model uses regularized multiple linear regression. The latest 20% of distinct
historical exam dates form validation by default. Earlier rows whose labels were
not available by the validation snapshot are excluded from the training split.
The candidate must meet the configured MAE limit and beat a training-mean
baseline. An accepted model is then refit on all available labeled history.
If a new candidate fails, the last compatible accepted model remains active.
Without an accepted model, the run fails and publishes no new predictions.

The bundled demo uses 400 historical results across five exam dates. Production
minimums default to 50 training and 20 validation rows. These are configuration
limits, not a guarantee that a dataset is representative. Inspect validation MAE,
missing-input and out-of-range warnings before using results. Current validation
checks generalization to later exams, not a separate unseen-student holdout.

### Add a parameter

`self_study_hours` is already included. For another numeric feature:

1. Add the field to the MySQL source schema and/or MongoDB source documents.
2. Populate truthful historical snapshots and upcoming records in consistent units.
3. Add its name to `features` and optional bounds to `feature_ranges` in each
   prediction configuration that should use it.
4. Run `check`, then `run-once`. The changed feature contract requires a newly
   validated model; incompatible old models are not reused.

The algorithms need no code changes. New features can help or hurt accuracy;
the validation gate decides whether the new model is accepted. Overlapping
study-hour definitions can create collinearity, so document whether self-study
is included in total study hours.

## Shared study recommendation algorithm

Input is one record per student, subject, and Monday-starting week. It contains
`average_score` (nullable), `target_score`, `available_minutes`, `min_minutes`,
`max_minutes` (nullable), `exam_date` (nullable), and `teacher_priority` (0.1–10).
Repeat the same total `available_minutes` on every subject for that student/week.
This is the **remaining self-study budget after classes, sleep, and other
commitments**, not the sum of independently available hours for each subject.
Update that budget as the week progresses; the engine does not track spent time.

For each subject:

```text
gap = max(target_score - score, 0)
urgency = 1 / (1 + days_until_exam / 7)   # zero for no exam or past exam
weight = teacher_priority * (1 + gap_weight * gap / score_span
                              + urgency_weight * urgency)
```

The planner first reserves minimum study blocks. It assigns remaining blocks by
diminishing priority, `weight / (extra_blocks + 1)`, until the budget or caps are
reached. Default blocks are 30 minutes. Exact ties use subject/source ordering.
Minimums round up and caps round down to blocks. Unusable remainder is reported
as `unallocated_minutes`. If rounded minimums exceed the budget or a cap, the
whole student/week has `status: infeasible` and null allocations. Missing scores
use zero gap and a `missing_score_teacher_review` flag. Completed weeks are skipped.

Results include allocated minutes/hours, score gaps, priority weights, constraints,
and reason codes. These are explainable planning rules, not a learned treatment
effect or a promise of score improvement. They allocate weekly subject totals;
they do not generate calendar time slots or resolve timetable conflicts.

By default the planner uses recorded averages. To use this engine's predictions,
have your application copy the appropriate current subject prediction into the
request's mapped `score` field and set `recommendation.score_basis` to
`model_prediction`. Check the prediction's model/run and freshness first. The
package intentionally has no implicit join across unrelated subjects or exam
attempts. It never trains on its own predictions as if they were actual outcomes.

## Try synthetic data

Copy your chosen example config to `config.local.demo.json`, change `database` to
`school_engine_demo` and `state_dir` to a new demo directory. Create that database
in MySQL first; MongoDB creates it on the first insert. Configure demo credentials.

```bash
python seed_demo.py --config config.local.demo.json --env-file .env
python app.py init-output --config config.local.demo.json --env-file .env
python app.py check --config config.local.demo.json --env-file .env
python app.py run-once --config config.local.demo.json --env-file .env
python app.py show-current --config config.local.demo.json --env-file .env
```

The seeder requires a database ending in `_engine_demo` and an empty source. It
creates 405 prediction records or five subject requests, using current dates.
It works with the supplied source names and field mappings.

## Project files and tests

`app.py` is the CLI. `pipeline.py` coordinates reads, learning/planning and writes.
`learning.py` and `regression.py` implement supervised prediction.
`recommendation.py` implements the shared planner. `adapters/` contains only
database concerns. `identity.py` and `storage_common.py` define shared contracts.

```bash
python -m pip install -r requirements-dev.txt
python -m unittest discover -s tests -v
```

Live tests require disposable MySQL and MongoDB databases; see
`docs/VALIDATION.md`. Operational details, result consumption and scheduling are
in `docs/OPERATIONS.md`. Regression mathematics is in `docs/REGRESSION.md`.
