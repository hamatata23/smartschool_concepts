"""Opt-in integration tests; use disposable *_engine_test databases only.

Set RUN_DATABASE_INTEGRATION=1, TEST_DATABASE=student_engine_test, MONGODB_URI,
MYSQL_HOST/PORT/USER/PASSWORD. Both servers must already be running.
"""
import copy
from datetime import datetime
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import uuid

from adapters import connect
from adapters.mysql import q
from demo_data import source_rows
from pipeline import run_once
from settings import load_config

ROOT = Path(__file__).resolve().parents[1]
NOW = datetime(2026, 10, 14, 12)


@unittest.skipUnless(os.environ.get("RUN_DATABASE_INTEGRATION") == "1", "live database tests are opt-in")
class LiveBackendsTests(unittest.TestCase):
    def setUp(self):
        self.database = os.environ.get("TEST_DATABASE", "student_engine_test")
        if not self.database.endswith("_engine_test"):
            raise ValueError("Tests require a disposable *_engine_test database")
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.stores = []
        self.addCleanup(self.cleanup_stores)

    def cleanup_stores(self):
        for store, c in self.stores:
            try:
                for name in (c["source"], c["output"], c["control"]):
                    if c["backend"] == "mongodb":
                        store.db.drop_collection(name)
                    else:
                        with store.conn.cursor() as cur:
                            cur.execute(f"DROP TABLE IF EXISTS {q(name)}")
                if c["backend"] == "mysql":
                    store.conn.commit()
            finally:
                store.close()

    def make_store(self, backend, task):
        c = load_config(ROOT/f"config.{backend}.{task}.json")
        c["database"] = self.database
        c["state_dir"] = str(Path(self.temp.name)/f"{backend}_{task}")
        suffix = uuid.uuid4().hex[:10]
        original_source = c["source"]
        for key in ("source", "output", "control"):
            c[key] = c[key]+"_"+suffix
        c["batch_size"] = 2
        store = connect(c)
        self.stores.append((store, c))
        rows = source_rows(c, NOW)
        if backend == "mongodb":
            store.db[c["source"]].insert_many(rows)
        else:
            example = "mysql_prediction_source.sql" if task == "predict" else "mysql_recommendation_source.sql"
            sql = (ROOT/"examples"/example).read_text().replace(original_source, c["source"])
            with store.conn.cursor() as cur:
                cur.execute(sql)
                fields = list(rows[0])
                cur.executemany(f"INSERT INTO {q(c['source'])} ({','.join(q(f) for f in fields)}) VALUES ({','.join(['%s']*len(fields))})",
                                [tuple(r[f] for f in fields) for r in rows])
            store.conn.commit()
        store.init_output()
        return store, c

    def test_recommendation_exact_parity_and_no_duplicate_runs(self):
        all_results = []
        for backend in ("mysql", "mongodb"):
            store, c = self.make_store(backend, "recommend")
            first = run_once(store, c, now=NOW)
            second = run_once(store, c, now=NOW)
            self.assertFalse(second["new_batch"])
            self.assertEqual(first["active_run_id"], second["active_run_id"])
            all_results.append([{k: r[k] for k in ("source_key", "student_id", "input_hash", "result")}
                                for r in store.read_current()["results"]])
        self.assertEqual(all_results[0], all_results[1])

    def test_prediction_and_coefficients_exact_parity(self):
        all_results, all_models = [], []
        for backend in ("mysql", "mongodb"):
            store, c = self.make_store(backend, "predict")
            run_once(store, c, now=NOW)
            self.assertFalse(run_once(store, c, now=NOW)["new_batch"])
            results = store.read_current()["results"]
            values = []
            for row in results:
                payload = dict(row["result"])
                payload.pop("model_version")
                values.append((row["source_key"], row["student_id"], row["input_hash"], payload))
            all_results.append(values)
            state = json.loads((Path(c["state_dir"])/"state.json").read_text())
            all_models.append(state["active"]["model"])
        self.assertEqual(all_results[0], all_results[1])
        self.assertEqual(all_models[0], all_models[1])

    def test_interrupted_batches_keep_previous_current_in_both_databases(self):
        for backend in ("mysql", "mongodb"):
            store, c = self.make_store(backend, "recommend")
            run_once(store, c, now=NOW)
            before = store.read_current()
            if backend == "mysql":
                with store.conn.cursor() as cur:
                    cur.execute(f"UPDATE {q(c['source'])} SET teacher_priority=2 WHERE id=1")
                store.conn.commit()
                import pymysql.cursors
                target, method = pymysql.cursors.DictCursor, "executemany"
                original = target.executemany
            else:
                store.db[c["source"]].update_one({"_id": 1}, {"$set": {"teacher_priority": 2}})
                target, method = type(store.db[c["output"]]), "insert_many"
                original = target.insert_many
            calls = []
            def fail_second(instance, *args, **kwargs):
                calls.append(1)
                if len(calls) == 2:
                    raise RuntimeError("injected write interruption")
                return original(instance, *args, **kwargs)
            with patch.object(target, method, fail_second), self.assertRaises(RuntimeError):
                run_once(store, c, now=NOW)
            self.assertEqual(before, store.read_current())
            if backend == "mysql":
                with store.conn.cursor() as cur:
                    cur.execute(f"SELECT COUNT(*) AS n FROM {q(c['output'])}")
                    self.assertEqual(cur.fetchone()["n"], 5)
                store.conn.commit()
            else:
                self.assertEqual(store.db[c["output"]].count_documents({}), 7)
            self.assertTrue(run_once(store, c, now=NOW)["new_batch"])

    def test_mysql_separate_worker_lock_is_exclusive(self):
        store, c = self.make_store("mysql", "recommend")
        other = connect(c)
        try:
            with store.lease():
                with self.assertRaises(RuntimeError):
                    with other.lease():
                        pass
            with other.lease() as lease:
                lease.renew()
        finally:
            other.close()
