import copy
from datetime import datetime, timedelta
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from bson import ObjectId
import mongomock

from adapters.mongodb import MongoStore, Lease
from adapters.mysql import MySQLStore
from demo_data import source_rows
from identity import encode_id
from pipeline import local_lock, run_once
from settings import load_config

NOW = datetime(2026, 10, 14, 12)
ROOT = Path(__file__).resolve().parents[1]


class MongoPipelineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        options = patch.object(mongomock.collection.Collection, "options", return_value={}, create=True)
        options.start()
        self.addCleanup(options.stop)
        self.db = mongomock.MongoClient()["test"]

    def setup_task(self, task):
        self.c = load_config(ROOT/f"config.mongodb.{task}.json")
        self.c["state_dir"] = self.temp.name
        self.c["batch_size"] = 2
        self.db[self.c["source"]].insert_many(source_rows(self.c, NOW))
        self.store = MongoStore(self.c, self.db)
        self.store.init_output()

    def test_prediction_reuses_batch_and_refreshes_pending(self):
        self.setup_task("predict")
        first = run_once(self.store, self.c, now=NOW)
        second = run_once(self.store, self.c, now=NOW)
        self.assertFalse(second["new_batch"])
        self.assertEqual(first["active_run_id"], second["active_run_id"])
        self.db[self.c["source"]].update_one({"_id": 401}, {"$set": {"previous_score": 95}})
        third = run_once(self.store, self.c, now=NOW)
        self.assertTrue(third["new_batch"])
        self.assertEqual(third["active_model_version"], first["active_model_version"])
        self.assertEqual(len(self.store.read_current()["results"]), 5)

    def test_recommendations_replace_finished_weeks_with_empty_batch(self):
        self.setup_task("recommend")
        self.assertEqual(run_once(self.store, self.c, now=NOW)["result_count"], 5)
        self.assertEqual(run_once(self.store, self.c, now=NOW+timedelta(days=7))["result_count"], 0)
        self.assertEqual(self.store.read_current()["results"], [])

    def test_partial_stage_never_becomes_current(self):
        self.setup_task("recommend")
        run_once(self.store, self.c, now=NOW)
        before = self.store.read_current()
        self.db[self.c["source"]].update_one({"_id": 1}, {"$set": {"teacher_priority": 2}})
        collection = self.db[self.c["output"]]
        real_insert = collection.insert_many
        calls = []
        def flaky(*args, **kwargs):
            calls.append(1)
            if len(calls) == 2:
                raise RuntimeError("injected interrupted write")
            return real_insert(*args, **kwargs)
        with patch.object(collection, "insert_many", side_effect=flaky), self.assertRaises(RuntimeError):
            run_once(self.store, self.c, now=NOW)
        self.assertEqual(self.store.read_current(), before)
        self.assertEqual(collection.count_documents({}), 7)
        self.assertTrue(run_once(self.store, self.c, now=NOW)["new_batch"])

    def test_expired_owner_cannot_publish_or_release_successor(self):
        self.setup_task("recommend")
        clock = [NOW]
        first = Lease(self.db, self.c, lambda: clock[0]).acquire()
        with self.assertRaises(RuntimeError):
            Lease(self.db, self.c, lambda: clock[0]).acquire()
        clock[0] += timedelta(seconds=self.c["lease_seconds"]+1)
        second = Lease(self.db, self.c, lambda: clock[0]).acquire()
        with self.assertRaises(RuntimeError):
            first.publish({})
        first.release()
        second.renew()
        second.release()

    def test_changed_contract_is_not_mislabeled_current(self):
        self.setup_task("recommend")
        run_once(self.store, self.c, now=NOW)
        self.c["recommendation"]["gap_weight"] = 4
        with self.assertRaises(ValueError):
            self.store.read_current()
        run_once(self.store, self.c, now=NOW)
        self.assertEqual(len(self.store.read_current()["results"]), 5)

    def test_max_rows_refuses_truncation(self):
        self.setup_task("predict")
        self.c["max_rows"] = 100
        with self.assertRaises(ValueError):
            run_once(self.store, self.c, now=NOW)
        self.assertIsNone(self.store.read_current()["active"])


class ContractTests(unittest.TestCase):
    def test_typed_ids_do_not_collide(self):
        values = [1, "1", ObjectId("000000000000000000000001")]
        self.assertEqual(len({encode_id(v) for v in values}), 3)
        for value in (True, 1.5, " padded "):
            with self.assertRaises(ValueError):
                encode_id(value)

    def test_sql_values_are_bound(self):
        c = load_config(ROOT/"config.mysql.predict.json")
        literal = "x' OR 1=1 --"
        c["filter_equals"] = {"subject": literal, "grade_level": None}
        store = MySQLStore(c, connection=object())
        sql, values = store.source_query(pending_only=True)
        self.assertNotIn(literal, sql)
        self.assertIn(literal, values)
        self.assertIn("`grade_level` IS NULL", sql)

    def test_local_state_lock_excludes_overlap(self):
        with tempfile.TemporaryDirectory() as directory, local_lock(directory):
            with self.assertRaises(RuntimeError):
                with local_lock(directory):
                    pass
