import copy
from datetime import datetime, timedelta
from pathlib import Path
import random
import unittest

from demo_data import study_rows
from identity import prepare_rows
from recommendation import recommend
from settings import load_config, validate

NOW = datetime(2026, 10, 14, 12)
ROOT = Path(__file__).resolve().parents[1]


class RecommendationTests(unittest.TestCase):
    def setUp(self):
        self.c = load_config(ROOT/"config.mongodb.recommend.json")
        self.rows = prepare_rows(study_rows(NOW), self.c)

    def results(self):
        return recommend(self.rows, self.c, NOW)[0]

    def test_budget_and_caps(self):
        results = self.results()
        self.assertEqual(sum(r["result"]["allocated_minutes"] for r in results), 600)
        self.assertTrue(all(30 <= r["result"]["allocated_minutes"] <= 240 for r in results))
        by_subject = {r["result"]["subject"]: r["result"]["allocated_minutes"] for r in results}
        self.assertGreater(by_subject["mathematics"], by_subject["history"])

    def test_permutation_does_not_change_results(self):
        before = self.results()
        self.rows.reverse()
        self.assertEqual(self.results(), before)

    def test_infeasible_minimums_have_no_allocations(self):
        for row in self.rows:
            row["available_minutes"] = 60
        results, report = recommend(self.rows, self.c, NOW)
        self.assertEqual(report["infeasible_student_weeks"], 1)
        self.assertTrue(all(r["result"]["allocated_minutes"] is None for r in results))

    def test_cap_below_rounded_min_is_infeasible(self):
        self.rows[0].update(min_minutes=31, max_minutes=59)
        self.assertEqual(self.results()[0]["result"]["status"], "infeasible")

    def test_caps_leave_unallocated_time(self):
        for r in self.rows:
            r["max_minutes"] = 30
        self.assertTrue(all(r["result"]["unallocated_minutes"] == 450 for r in self.results()))

    def test_partial_block_is_not_overspent(self):
        for r in self.rows:
            r["available_minutes"] = 619
        self.assertEqual(sum(r["result"]["allocated_minutes"] for r in self.results()), 600)

    def test_missing_score_is_flagged(self):
        self.rows[0]["average_score"] = None
        item = next(r for r in self.results() if r["source_key"] == "int:1")
        self.assertIn("missing_score_teacher_review", item["result"]["reason_codes"])

    def test_conflicting_budgets_and_duplicate_subject_rejected(self):
        original = copy.deepcopy(self.rows)
        for mutation in (dict(available_minutes=500), dict(subject="ENGLISH"), dict(average_score=101), dict(teacher_priority=0)):
            self.rows = copy.deepcopy(original)
            self.rows[0].update(mutation)
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                self.results()

    def test_completed_week_removed(self):
        results, report = recommend(self.rows, self.c, NOW+timedelta(days=7))
        self.assertEqual(results, [])
        self.assertEqual(report["past_requests_skipped"], 5)

    def test_random_budgets_never_overspend(self):
        rng = random.Random(8)
        for _ in range(100):
            budget = rng.randint(0, 1000)
            for row in self.rows:
                row.update(available_minutes=budget, min_minutes=rng.randint(0, 60), max_minutes=rng.randint(100, 400))
            results = self.results()
            if results[0]["result"]["status"] == "ready":
                self.assertLessEqual(sum(r["result"]["allocated_minutes"] for r in results), budget)
                for r in results:
                    p = r["result"]
                    self.assertTrue(p["min_minutes"] <= p["allocated_minutes"] <= p["max_minutes"])

    def test_add_feature_only_changes_prediction_config(self):
        c = load_config(ROOT/"config.mysql.predict.json")
        c["features"].append("quiz_average")
        c["feature_ranges"]["quiz_average"] = [0, 100]
        self.assertIn("quiz_average", validate(c)["features"])
        c["features"].append("final_score")
        with self.assertRaises(ValueError):
            validate(c)
