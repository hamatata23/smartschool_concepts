-- Apply to your selected database. Review before adapting an existing schema.
CREATE TABLE IF NOT EXISTS tbl_student_score (
  id BIGINT NOT NULL PRIMARY KEY,
  student_id VARCHAR(128) NOT NULL,
  subject VARCHAR(128) NOT NULL,
  grade_level INT NOT NULL,
  exam_date DATE NOT NULL,
  features_as_of DATETIME(6) NOT NULL,
  study_hours_per_week DOUBLE NULL,
  attendance_percent DOUBLE NULL,
  previous_score DOUBLE NULL,
  sleep_hours_per_night DOUBLE NULL,
  assignments_completed_percent DOUBLE NULL,
  self_study_hours DOUBLE NULL,
  final_score DOUBLE NULL,
  score_recorded_at DATETIME(6) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
