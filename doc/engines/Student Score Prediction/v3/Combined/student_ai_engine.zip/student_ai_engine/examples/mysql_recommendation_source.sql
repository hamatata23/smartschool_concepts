CREATE TABLE IF NOT EXISTS tbl_student_study_request (
  id BIGINT NOT NULL PRIMARY KEY,
  student_id VARCHAR(128) NOT NULL,
  subject VARCHAR(128) NOT NULL,
  week_start DATE NOT NULL,
  average_score DOUBLE NULL,
  target_score DOUBLE NOT NULL,
  available_minutes INT NOT NULL,
  min_minutes INT NOT NULL,
  max_minutes INT NULL,
  exam_date DATE NULL,
  teacher_priority DOUBLE NOT NULL,
  UNIQUE KEY student_week_subject (student_id, week_start, subject)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
