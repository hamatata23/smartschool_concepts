"""Shared persistence contract, independent of MySQL and MongoDB."""
from datetime import datetime
from learning import digest, utcnow

FORMAT = 1


def contract_hash(c):
    return digest({k: c[k] for k in ("backend", "task", "database", "pipeline_name", "source", "output", "columns",
                  "features", "feature_ranges", "filter_equals", "score_min", "score_max", "recommendation")})


def fingerprint(records, metadata):
    return digest({"records": records, "metadata": metadata})


def manifest(c, run_id, count, signature, metadata, captured_at, now=None):
    now = now or utcnow()
    return {"format_version": FORMAT, "run_id": run_id, "task": c["task"], "output": c["output"],
            "contract_hash": contract_hash(c), "result_count": count, "fingerprint": signature,
            "published_at": now.isoformat(), "last_checked_at": now.isoformat(),
            "source_read_completed_at": captured_at.isoformat(), "metadata": metadata}


def validate_current(active, c):
    if active["contract_hash"] != contract_hash(c) or active["output"] != c["output"]:
        raise ValueError("Published results belong to a previous configuration; run the updated task successfully first")


def result_document(c, run_id, record, captured_at):
    return {"engine_format": FORMAT, "pipeline_name": c["pipeline_name"], "run_id": run_id,
            "source_key": record["source_key"], "student_id": record["student_id"],
            "task": c["task"], "input_hash": record["input_hash"], "result": record["result"],
            "created_at": captured_at.isoformat()}
