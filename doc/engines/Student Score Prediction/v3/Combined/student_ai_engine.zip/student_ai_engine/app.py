"""Run the shared student AI engine against MySQL or MongoDB."""
import argparse
import json
import sys

import pymysql
from pymongo.errors import PyMongoError

from adapters import connect
from pipeline import check_data, run_once
from settings import load_config, load_env


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["init-output", "check", "run-once", "show-current"])
    parser.add_argument("--config", required=True)
    parser.add_argument("--env-file")
    parser.add_argument("--force-retrain", action="store_true")
    args = parser.parse_args(argv)
    store = None
    try:
        load_env(args.env_file)
        c = load_config(args.config)
        store = connect(c)
        if args.command == "init-output":
            store.init_output()
            result = {"status": "ok", "backend": c["backend"], "output": c["output"]}
        elif args.command == "check":
            result = check_data(store, c)
        elif args.command == "show-current":
            store.check()
            result = store.read_current()
        else:
            result = run_once(store, c, args.force_retrain)
        print(json.dumps(result, indent=2, allow_nan=False))
        return 0
    except (PyMongoError, pymysql.MySQLError) as exc:
        # Driver messages can include connection strings and student values.
        code = getattr(exc, "code", None)
        if code is None and exc.args and isinstance(exc.args[0], int):
            code = exc.args[0]
        print(f"ERROR: {type(exc).__name__}, code={code}; check connectivity, permissions and schema", file=sys.stderr)
        return 1
    except (ValueError, RuntimeError, OSError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    finally:
        if store is not None:
            store.close()


if __name__ == "__main__":
    raise SystemExit(main())
