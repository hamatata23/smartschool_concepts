"""Database-independent ID encoding avoids string/integer/ObjectId collisions."""
from bson import ObjectId


def encode_id(value):
    if isinstance(value, ObjectId):
        return "oid:"+str(value)
    if isinstance(value, int) and not isinstance(value, bool) and -(2**63) <= value < 2**64:
        return "int:"+str(value)
    if isinstance(value, str) and value and value == value.strip() and len(value) <= 124:
        return "str:"+value
    raise ValueError("Source IDs must be integers, ObjectId, or unpadded strings <=124 characters")


def prepare_rows(rows, c):
    from bson.decimal128 import Decimal128
    required = set(c["columns"].values())
    out = []
    for original in rows:
        row = dict(original)
        if required - row.keys():
            raise ValueError("Source record lacks a configured field")
        row[c["columns"]["row_id"]] = encode_id(row[c["columns"]["row_id"]])
        student = row[c["columns"]["student_id"]]
        if not isinstance(student, str) or not student or student != student.strip() or len(student) > 128:
            raise ValueError("student_id must be an unpadded nonempty string <=128 characters")
        for key, value in row.items():
            if isinstance(value, Decimal128):
                row[key] = value.to_decimal()
        for feature in c["features"]:
            row.setdefault(feature, None)
        out.append(row)
    return out
