"""Seed an EMPTY source in a disposable database ending in _engine_demo."""
import argparse
from pathlib import Path

from adapters import connect
from adapters.mysql import q
from demo_data import source_rows
from settings import load_config, load_env


def seed(store, c, rows):
    if c["backend"] == "mongodb":
        collection = store.db[c["source"]]
        if collection.find_one({}) is not None:
            raise ValueError("Refusing to seed nonempty source")
        collection.insert_many(rows)
    else:
        if c["source"] not in ("tbl_student_score", "tbl_student_study_request"):
            raise ValueError("Demo requires the supplied source name")
        example = "mysql_prediction_source.sql" if c["task"] == "predict" else "mysql_recommendation_source.sql"
        sql = (Path(__file__).parent/"examples"/example).read_text(encoding="utf-8")
        with store.conn.cursor() as cur:
            cur.execute(sql)
            cur.execute(f"SELECT COUNT(*) AS n FROM {q(c['source'])}")
            if cur.fetchone()["n"]:
                raise ValueError("Refusing to seed nonempty source")
            fields = list(rows[0])
            cur.executemany(f"INSERT INTO {q(c['source'])} ({','.join(q(f) for f in fields)}) VALUES ({','.join(['%s']*len(fields))})",
                            [tuple(r[f] for f in fields) for r in rows])
        store.conn.commit()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    parser.add_argument("--env-file")
    args = parser.parse_args()
    load_env(args.env_file)
    c = load_config(args.config)
    if not c["database"].endswith("_engine_demo"):
        raise SystemExit("Demo database must end in _engine_demo")
    store = connect(c)
    try:
        rows = source_rows(c)
        seed(store, c, rows)
        print(f"Inserted {len(rows)} synthetic records")
    finally:
        store.close()


if __name__ == "__main__":
    main()
