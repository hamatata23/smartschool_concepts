"""Only database plumbing lives here; all algorithms are shared."""


def connect(c):
    if c["backend"] == "mysql":
        from .mysql import MySQLStore
        return MySQLStore(c)
    if c["backend"] == "mongodb":
        from .mongodb import MongoStore
        return MongoStore(c)
    raise ValueError("Unknown backend")
