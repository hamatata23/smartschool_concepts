from contextlib import contextmanager
from datetime import timedelta
import os
import uuid

from pymongo import MongoClient, ReadPreference
from pymongo.errors import DuplicateKeyError
from pymongo.read_concern import ReadConcern
from pymongo.write_concern import WriteConcern

from identity import prepare_rows
from learning import digest, utcnow
from storage_common import FORMAT, contract_hash, fingerprint, manifest, result_document, validate_current

KEY = [("pipeline_name", 1), ("run_id", 1), ("source_key", 1)]


class Lease:
    def __init__(self, db, c, clock):
        self.collection = db[c["control"]]
        self.key, self.owner, self.seconds, self.clock = c["pipeline_name"], str(uuid.uuid4()), c["lease_seconds"], clock

    def acquire(self):
        now = self.clock()
        query = {"_id": self.key, "$or": [{"lease_until": {"$lte": now}}, {"lease_until": {"$exists": False}}]}
        try:
            self.collection.update_one(query, {"$set": {"engine_format": FORMAT, "lease_owner": self.owner,
                "lease_until": now+timedelta(seconds=self.seconds)}}, upsert=True)
        except DuplicateKeyError as exc:
            raise RuntimeError("Another worker holds this pipeline lease") from exc
        return self

    def active_filter(self):
        return {"_id": self.key, "lease_owner": self.owner, "lease_until": {"$gt": self.clock()}}

    def renew(self):
        result = self.collection.update_one(self.active_filter(), {"$set": {"lease_until": self.clock()+timedelta(seconds=self.seconds)}})
        if result.matched_count != 1:
            raise RuntimeError("Pipeline lease expired or changed owner")

    def publish(self, active):
        if self.collection.update_one(self.active_filter(), {"$set": {"active": active}}).matched_count != 1:
            raise RuntimeError("Lost lease before publication; staged batch is not current")

    def release(self):
        self.collection.update_one({"_id": self.key, "lease_owner": self.owner},
            {"$set": {"lease_until": self.clock()}, "$unset": {"lease_owner": ""}})


class MongoStore:
    def __init__(self, c, db=None):
        self.c, self.client = c, None
        if db is not None:
            self.db = db
            return
        uri = os.environ.get("MONGODB_URI")
        if not uri:
            raise ValueError("Set MONGODB_URI")
        options = dict(serverSelectionTimeoutMS=10000, connectTimeoutMS=10000, socketTimeoutMS=120000,
                       tz_aware=False, appname="student-ai-engine")
        if os.environ.get("MONGODB_TLS_CA_FILE"):
            options.update(tls=True, tlsCAFile=os.environ["MONGODB_TLS_CA_FILE"])
        self.client = MongoClient(uri, **options)
        try:
            self.client.admin.command("ping")
            self.db = self.client.get_database(c["database"], read_preference=ReadPreference.PRIMARY,
                read_concern=ReadConcern("majority"), write_concern=WriteConcern(w="majority", wtimeout=10000))
        except Exception:
            self.client.close()
            raise

    def close(self):
        if self.client is not None:
            self.client.close()

    def init_output(self):
        for name in (self.c["output"], self.c["control"]):
            if name not in self.db.list_collection_names():
                self.db.create_collection(name)
        self.db[self.c["output"]].create_index(KEY, unique=True, name="unique_run_source")
        self.db[self.c["output"]].create_index([("pipeline_name", 1), ("run_id", 1), ("student_id", 1)], name="student_lookup")
        self.check()

    def check(self):
        c = self.c
        existing = set(self.db.list_collection_names())
        for name in (c["source"], c["output"], c["control"]):
            if name not in existing:
                raise ValueError(f"Missing collection {name}; import source data and initialize output")
        for name in (c["output"], c["control"]):
            col = self.db[name]
            if col.options().get("collation", {}).get("locale", "simple") != "simple":
                raise ValueError("Engine collections require simple collation")
            if col.find_one({"engine_format": {"$ne": FORMAT}}, {"_id": 1}) is not None:
                raise ValueError("Engine collection contains an incompatible document format")
            indexes = list(col.list_indexes())
            if name == c["output"] and not any(list(i["key"].items()) == KEY and i.get("unique")
                    and not i.get("sparse") and not i.get("partialFilterExpression")
                    and i.get("collation", {}).get("locale", "simple") == "simple" for i in indexes):
                raise ValueError("Missing full unique run/source index")
            for idx in indexes:
                if "expireAfterSeconds" in idx:
                    raise ValueError("TTL indexes can delete active results and are not supported")
                if idx["name"] != "_id_" and idx.get("unique") and not (name == c["output"] and list(idx["key"].items()) == KEY):
                    raise ValueError("Unexpected unique index")

    def fetch_source(self, pending_only=False):
        c = self.c
        clauses = [{k: {"$eq": v}} for k, v in c["filter_equals"].items()]
        if pending_only:
            clauses.append({c["columns"]["target"]: {"$eq": None, "$exists": True}})
        query = {"$and": clauses} if clauses else {}
        projection = {name: 1 for name in {*c["columns"].values(), *c["features"]}}
        cursor = self.db[c["source"]].find(query, projection).sort("_id", 1).limit(c["max_rows"]+1)
        try:
            rows = list(cursor)
        finally:
            cursor.close()
        if len(rows) > c["max_rows"]:
            raise ValueError("Source exceeds max_rows; refusing to silently truncate")
        return prepare_rows(rows, c)

    @contextmanager
    def lease(self, clock=utcnow):
        lease = Lease(self.db, self.c, clock).acquire()
        try:
            yield lease
        finally:
            try:
                lease.release()
            except Exception:
                pass

    def publish(self, records, metadata, lease, captured_at):
        c, col = self.c, self.db[self.c["output"]]
        signature = fingerprint(records, metadata)
        control = self.db[c["control"]].find_one({"_id": c["pipeline_name"]}) or {}
        current = control.get("active")
        if current and current.get("fingerprint") == signature and current["contract_hash"] == contract_hash(c):
            if col.count_documents({"pipeline_name": c["pipeline_name"], "run_id": current["run_id"]}) != current["result_count"]:
                raise RuntimeError("Published batch is missing records")
            current = {**current, "last_checked_at": lease.clock().isoformat(), "source_read_completed_at": captured_at.isoformat()}
            lease.renew()
            lease.publish(current)
            return current, False
        run_id = str(uuid.uuid4())
        batch = []
        for record in records:
            doc = result_document(c, run_id, record, captured_at)
            doc["_id"] = digest([c["pipeline_name"], run_id, record["source_key"]])
            batch.append(doc)
            if len(batch) >= c["batch_size"]:
                lease.renew()
                col.insert_many(batch, ordered=True)
                batch = []
        if batch:
            lease.renew()
            col.insert_many(batch, ordered=True)
        lease.renew()
        if col.count_documents({"pipeline_name": c["pipeline_name"], "run_id": run_id}) != len(records):
            raise RuntimeError("Staged batch count mismatch")
        active = manifest(c, run_id, len(records), signature, metadata, captured_at, lease.clock())
        lease.publish(active)
        return active, True

    def read_current(self):
        c = self.c
        control = self.db[c["control"]].find_one({"_id": c["pipeline_name"]}) or {}
        active = control.get("active")
        if not active:
            return {"active": None, "results": []}
        validate_current(active, c)
        rows = list(self.db[c["output"]].find({"pipeline_name": c["pipeline_name"], "run_id": active["run_id"]}, {"_id": 0}).sort("source_key", 1))
        if len(rows) != active["result_count"]:
            raise RuntimeError("Published batch incomplete")
        return {"active": active, "results": rows}
