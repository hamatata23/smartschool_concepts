from contextlib import contextmanager
import hashlib
import json
import os
import uuid

import pymysql

from identity import prepare_rows
from learning import utcnow
from settings import identifier
from storage_common import FORMAT, contract_hash, fingerprint, manifest, result_document, validate_current


def q(value):
    return "`"+identifier(value)+"`"


def output_ddl(c):
    return f"""CREATE TABLE IF NOT EXISTS {q(c['output'])} (
      pipeline_name VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
      run_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
      source_key VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
      student_id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
      task VARCHAR(16) CHARACTER SET ascii NOT NULL,
      input_hash CHAR(64) CHARACTER SET ascii NOT NULL,
      engine_format INT NOT NULL,
      result_json JSON NOT NULL,
      created_at DATETIME(6) NOT NULL,
      PRIMARY KEY (pipeline_name, run_id, source_key),
      KEY student_lookup (pipeline_name, run_id, student_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin"""


def control_ddl(c):
    return f"""CREATE TABLE IF NOT EXISTS {q(c['control'])} (
      pipeline_name VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL PRIMARY KEY,
      engine_format INT NOT NULL,
      active_json JSON NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin"""


class MySQLLease:
    def __init__(self, connection, name, clock):
        self.conn, self.name, self.clock = connection, name, clock

    def renew(self):
        with self.conn.cursor() as cur:
            cur.execute("SELECT IS_USED_LOCK(%s) = CONNECTION_ID() AS owns_lock", (self.name,))
            if cur.fetchone()["owns_lock"] != 1:
                raise RuntimeError("MySQL pipeline lock has been lost")


class MySQLStore:
    def __init__(self, c, connection=None):
        self.c = c
        if connection is not None:
            self.conn = connection
            return
        if not os.environ.get("MYSQL_USER") or "MYSQL_PASSWORD" not in os.environ:
            raise ValueError("Set MYSQL_USER and MYSQL_PASSWORD")
        options = dict(host=os.environ.get("MYSQL_HOST", "127.0.0.1"), port=int(os.environ.get("MYSQL_PORT", "3306")),
            user=os.environ["MYSQL_USER"], password=os.environ["MYSQL_PASSWORD"], database=c["database"],
            charset="utf8mb4", cursorclass=pymysql.cursors.DictCursor, autocommit=False,
            connect_timeout=10, read_timeout=120, write_timeout=120, local_infile=False)
        if os.environ.get("MYSQL_UNIX_SOCKET"):
            options["unix_socket"] = os.environ["MYSQL_UNIX_SOCKET"]
        if os.environ.get("MYSQL_SSL_CA"):
            options.update(ssl_ca=os.environ["MYSQL_SSL_CA"], ssl_verify_cert=True, ssl_verify_identity=True)
        elif options["host"] not in ("localhost", "127.0.0.1", "::1") and not options.get("unix_socket"):
            raise ValueError("Set MYSQL_SSL_CA for a remote MySQL connection")
        self.conn = pymysql.connect(**options)
        try:
            with self.conn.cursor() as cur:
                cur.execute("SET time_zone = '+00:00'")
                cur.execute("SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ")
                cur.execute("SET SESSION sql_mode='STRICT_ALL_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'")
            self.conn.commit()
        except Exception:
            self.conn.close()
            raise

    def close(self):
        self.conn.close()

    def init_output(self):
        with self.conn.cursor() as cur:
            cur.execute(output_ddl(self.c))
            cur.execute(control_ddl(self.c))
        self.conn.commit()
        self.check()

    def check(self):
        c = self.c
        with self.conn.cursor() as cur:
            tables = {}
            for name in (c["source"], c["output"], c["control"]):
                cur.execute("SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=%s", (name,))
                found = cur.fetchone()
                if not found or found["ENGINE"] != "InnoDB":
                    raise ValueError(f"{name} must exist and use InnoDB")
                cur.execute(f"SHOW FULL COLUMNS FROM {q(name)}")
                tables[name] = {r["Field"]: r for r in cur.fetchall()}
            required = {*c["columns"].values(), *c["features"], *c["filter_equals"]}
            if required - tables[c["source"]].keys():
                raise ValueError("Source table lacks configured fields")
            cur.execute(f"SHOW INDEX FROM {q(c['source'])}")
            unique = {}
            for idx in cur.fetchall():
                if not idx["Non_unique"]:
                    unique.setdefault(idx["Key_name"], []).append((idx["Seq_in_index"], idx["Column_name"], idx["Sub_part"]))
            if not any(v == [(1, c["columns"]["row_id"], None)] for v in unique.values()):
                raise ValueError("Source row_id requires a full-column unique index")
            expected = {c["output"]: {
                "pipeline_name": "varchar(64)", "run_id": "char(36)", "source_key": "varchar(128)",
                "student_id": "varchar(128)", "task": "varchar(16)", "input_hash": "char(64)",
                "engine_format": "int", "result_json": "json", "created_at": "datetime(6)"},
                c["control"]: {"pipeline_name": "varchar(64)", "engine_format": "int", "active_json": "json"}}
            for name, fields in expected.items():
                for field, kind in fields.items():
                    meta = tables[name].get(field)
                    if not meta or meta["Type"].lower() != kind or (field != "active_json" and meta["Null"] != "NO"):
                        raise ValueError(f"Incompatible engine table {name}: check column {field}")
                key_fields = ["pipeline_name", "run_id", "source_key"] if name == c["output"] else ["pipeline_name"]
                for field in key_fields:
                    collation = "utf8mb4_bin" if field == "source_key" else "ascii_bin"
                    if tables[name][field]["Collation"] != collation:
                        raise ValueError("Engine key collation differs from supplied DDL")
                cur.execute(f"SHOW INDEX FROM {q(name)}")
                indexes = cur.fetchall()
                primary = sorted((i["Seq_in_index"], i["Column_name"], i["Sub_part"]) for i in indexes if i["Key_name"] == "PRIMARY")
                if primary != [(i+1, f, None) for i, f in enumerate(key_fields)]:
                    raise ValueError("Engine primary key differs from supplied DDL")
                if any(not i["Non_unique"] and i["Key_name"] != "PRIMARY" for i in indexes):
                    raise ValueError("Unexpected unique index on engine table")
                cur.execute(f"SELECT 1 AS bad FROM {q(name)} WHERE engine_format <> %s LIMIT 1", (FORMAT,))
                if cur.fetchone():
                    raise ValueError("Engine table contains an incompatible format")
        self.conn.commit()

    def source_query(self, pending_only=False):
        c = self.c
        fields = list(dict.fromkeys([*c["columns"].values(), *c["features"]]))
        clauses, args = [], []
        for name, value in c["filter_equals"].items():
            if value is None:
                clauses.append(f"{q(name)} IS NULL")
            else:
                clauses.append(f"{q(name)} = %s")
                args.append(value)
        if pending_only:
            clauses.append(f"{q(c['columns']['target'])} IS NULL")
        sql = f"SELECT {', '.join(q(f) for f in fields)} FROM {q(c['source'])}"
        if clauses:
            sql += " WHERE "+" AND ".join(clauses)
        sql += f" ORDER BY {q(c['columns']['row_id'])} LIMIT %s"
        return sql, tuple(args+[c["max_rows"]+1])

    def fetch_source(self, pending_only=False):
        try:
            with self.conn.cursor() as cur:
                cur.execute(*self.source_query(pending_only))
                rows = cur.fetchall()
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        if len(rows) > self.c["max_rows"]:
            raise ValueError("Source exceeds max_rows; refusing to silently truncate")
        return prepare_rows(rows, self.c)

    @contextmanager
    def lease(self, clock=utcnow):
        name = "student-ai:"+hashlib.sha256((self.c["database"]+":"+self.c["control"]+":"+self.c["pipeline_name"]).encode()).hexdigest()[:52]
        with self.conn.cursor() as cur:
            cur.execute("SELECT GET_LOCK(%s, 0) AS acquired", (name,))
            if cur.fetchone()["acquired"] != 1:
                raise RuntimeError("Another worker holds this MySQL pipeline lock")
        try:
            yield MySQLLease(self.conn, name, clock)
        finally:
            try:
                self.conn.rollback()
                with self.conn.cursor() as cur:
                    cur.execute("SELECT RELEASE_LOCK(%s)", (name,))
            except Exception:
                pass

    def _active(self, cur):
        cur.execute(f"SELECT active_json FROM {q(self.c['control'])} WHERE pipeline_name=%s", (self.c["pipeline_name"],))
        row = cur.fetchone()
        return json.loads(row["active_json"]) if row and row["active_json"] is not None else None

    def _set_active(self, cur, active):
        payload = json.dumps(active, allow_nan=False)
        cur.execute(f"INSERT INTO {q(self.c['control'])} (pipeline_name,engine_format,active_json) VALUES (%s,%s,%s) "
                    "ON DUPLICATE KEY UPDATE engine_format=%s, active_json=%s",
                    (self.c["pipeline_name"], FORMAT, payload, FORMAT, payload))

    def publish(self, records, metadata, lease, captured_at):
        c = self.c
        signature = fingerprint(records, metadata)
        try:
            lease.renew()
            with self.conn.cursor() as cur:
                current = self._active(cur)
                if current and current["fingerprint"] == signature and current["contract_hash"] == contract_hash(c):
                    cur.execute(f"SELECT COUNT(*) AS n FROM {q(c['output'])} WHERE pipeline_name=%s AND run_id=%s", (c["pipeline_name"], current["run_id"]))
                    if cur.fetchone()["n"] != current["result_count"]:
                        raise RuntimeError("Published batch incomplete")
                    current = {**current, "last_checked_at": lease.clock().isoformat(), "source_read_completed_at": captured_at.isoformat()}
                    self._set_active(cur, current)
                    self.conn.commit()
                    return current, False
                run_id = str(uuid.uuid4())
                sql = f"INSERT INTO {q(c['output'])} (pipeline_name,run_id,source_key,student_id,task,input_hash,engine_format,result_json,created_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                for start in range(0, len(records), c["batch_size"]):
                    lease.renew()
                    values = [(c["pipeline_name"], run_id, r["source_key"], r["student_id"], c["task"], r["input_hash"], FORMAT,
                               json.dumps(r["result"], allow_nan=False), captured_at) for r in records[start:start+c["batch_size"]]]
                    cur.executemany(sql, values)
                active = manifest(c, run_id, len(records), signature, metadata, captured_at, lease.clock())
                self._set_active(cur, active)
            self.conn.commit()
            return active, True
        except Exception:
            self.conn.rollback()
            raise

    def read_current(self):
        try:
            with self.conn.cursor() as cur:
                active = self._active(cur)
                if not active:
                    self.conn.commit()
                    return {"active": None, "results": []}
                validate_current(active, self.c)
                cur.execute(f"SELECT * FROM {q(self.c['output'])} WHERE pipeline_name=%s AND run_id=%s ORDER BY source_key",
                            (self.c["pipeline_name"], active["run_id"]))
                rows = cur.fetchall()
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        if len(rows) != active["result_count"]:
            raise RuntimeError("Published batch incomplete")
        for row in rows:
            row["result"] = json.loads(row.pop("result_json"))
            row["created_at"] = row["created_at"].isoformat()
        return {"active": active, "results": rows}
