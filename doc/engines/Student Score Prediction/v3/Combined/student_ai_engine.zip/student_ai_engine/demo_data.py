"""Synthetic, reproducible fixtures; never use as real student history."""
from datetime import datetime, timedelta, timezone

import numpy as np


def demo_rows(now=None):
    now = (now or datetime.now(timezone.utc).replace(tzinfo=None)).replace(hour=0, minute=0, second=0, microsecond=0)
    rng = np.random.default_rng(74)
    rows = []
    for year in range(5):
        exam = now - timedelta(days=365*(5-year))
        for student in range(80):
            h, a, p, s, hw, sh = map(float, rng.uniform([1, 45, 20, 4, 30, 0], [30, 100, 95, 9, 100, 5]))
            score = float(np.clip(3+.30*h+.14*a+.45*p+1.2*s+.10*hw+1.8*sh+rng.normal(0,2),0,100))
            rows.append(dict(_id=len(rows)+1, student_id=f"DEMO-{year}-{student}", subject="mathematics",
                grade_level=8, exam_date=exam, features_as_of=exam-timedelta(days=60),
                study_hours_per_week=h, attendance_percent=a, previous_score=p,
                sleep_hours_per_night=s, assignments_completed_percent=hw, self_study_hours=sh,
                final_score=score, score_recorded_at=exam+timedelta(days=1)))
    for student in range(5):
        rows.append(dict(_id=len(rows)+1, student_id=f"DEMO-FUTURE-{student}", subject="mathematics",
            grade_level=8, exam_date=now+timedelta(days=60), features_as_of=now,
            study_hours_per_week=12+student, attendance_percent=85+student,
            previous_score=65+student, sleep_hours_per_night=7, assignments_completed_percent=80+student,
            self_study_hours=1+student*.25, final_score=None, score_recorded_at=None))
    return rows


def study_rows(now=None):
    now = (now or datetime.now(timezone.utc).replace(tzinfo=None)).replace(hour=0, minute=0, second=0, microsecond=0)
    week = now-timedelta(days=now.weekday())
    subjects = [("mathematics", 55, 85, 3), ("english", 75, 85, 14), ("science", 65, 85, 7),
                ("history", 80, 85, 30), ("geography", 70, 85, 21)]
    return [dict(_id=i+1, student_id="DEMO-001", subject=subject, week_start=week,
                 average_score=score, target_score=target, available_minutes=600,
                 min_minutes=30, max_minutes=240, exam_date=now+timedelta(days=days), teacher_priority=1.0)
            for i, (subject, score, target, days) in enumerate(subjects)]


def source_rows(c, now=None):
    rows = demo_rows(now) if c["task"] == "predict" else study_rows(now)
    if c["backend"] == "mysql":
        for row in rows:
            row["id"] = row.pop("_id")
    return rows
