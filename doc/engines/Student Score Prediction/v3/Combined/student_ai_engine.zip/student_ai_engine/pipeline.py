"""One workflow and two shared algorithms, independent of database drivers."""
from contextlib import contextmanager
import fcntl
import json
import os
from pathlib import Path
import tempfile

from learning import advance_state, normalize, predict_rows, utcnow
from recommendation import recommend, ALGORITHM_VERSION


def atomic_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temporary = tempfile.mkstemp(prefix=".save-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, indent=2, allow_nan=False)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        descriptor = os.open(path.parent, os.O_DIRECTORY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


@contextmanager
def local_lock(directory):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    with open(directory/"run.lock", "a") as stream:
        try:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError("Another process is using this state directory") from exc
        try:
            yield
        finally:
            fcntl.flock(stream, fcntl.LOCK_UN)


def check_data(store, c, now=None):
    store.check()
    rows = store.fetch_source()
    if c["task"] == "recommend":
        records, report = recommend(rows, c, now)
        return {"status": "ok", "recommendation_rows": len(records), **report}
    labeled, pending, skipped = normalize(rows, c, now)
    return {"status": "ok", "labeled_rows": len(labeled), "future_unlabeled_rows": len(pending),
            "past_unlabeled_rows": skipped}


def run_once(store, c, force=False, now=None):
    directory = Path(c["state_dir"])
    clock = (lambda: now) if now is not None else utcnow
    if force and c["task"] != "predict":
        raise ValueError("force-retrain applies only to prediction")
    with local_lock(directory):
        store.check()
        with store.lease(clock) as lease:
            report = {"backend": c["backend"], "task": c["task"], "pipeline_name": c["pipeline_name"],
                      "run_at_utc": clock().isoformat()}
            try:
                rows = store.fetch_source()
                captured_at = clock()
                if c["task"] == "recommend":
                    records, details = recommend(rows, c, captured_at)
                    report.update(details)
                    metadata = {"algorithm_version": ALGORITHM_VERSION, "rules": c["recommendation"]}
                else:
                    labeled, _, skipped = normalize(rows, c, captured_at)
                    state_path = directory/"state.json"
                    previous = json.loads(state_path.read_text(encoding="utf-8")) if state_path.exists() else None
                    state, training = advance_state(previous, labeled, c, force, captured_at)
                    lease.renew()
                    active = state.get("active")
                    if active:
                        version_path = directory/"models"/(active["version"]+".json")
                        if not version_path.exists():
                            atomic_json(version_path, active)
                    atomic_json(state_path, state)
                    report.update(labeled_rows=len(labeled), skipped_past_unlabeled_rows=skipped,
                                  training=training, active_model_version=active["version"] if active else None)
                    if not active:
                        raise RuntimeError("No accepted model; see state_dir/last_run.json for training requirements or validation failures")
                    # Inputs can change during training; refresh the upcoming exams.
                    current = store.fetch_source(pending_only=True)
                    captured_at = clock()
                    _, pending, _ = normalize(current, c, captured_at)
                    records = []
                    for prediction in predict_rows(pending, active, c):
                        prediction = dict(prediction)
                        key = prediction.pop("source_row_id")
                        student = prediction.pop("student_id")
                        input_hash = prediction.pop("input_hash")
                        records.append({"source_key": key, "student_id": student, "input_hash": input_hash,
                            "result": {**prediction, "model_version": active["version"],
                                       "validation_mae": active["validation_mae"]}})
                    metadata = {"algorithm_version": "temporal-ridge-v1", "model_version": active["version"],
                                "training_rows": active["training_rows"], "validation_mae": active["validation_mae"]}
                records.sort(key=lambda r: r["source_key"])
                lease.renew()
                active_run, created = store.publish(records, metadata, lease, captured_at)
                report.update(status="ok", result_count=active_run["result_count"],
                    records_written=len(records) if created else 0, new_batch=created, active_run_id=active_run["run_id"])
            except Exception:
                atomic_json(directory/"last_run.json", {**report, "status": "failed_or_publication_unknown"})
                raise
            atomic_json(directory/"last_run.json", report)
            return report
