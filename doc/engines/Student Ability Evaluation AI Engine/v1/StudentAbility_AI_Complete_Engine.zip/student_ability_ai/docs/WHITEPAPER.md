# StudentAbility AI
## A Bayesian, Adaptive Evaluation Engine for Five School Subjects

**Technical whitepaper | Reference architecture and implementation v1.0 | 14 October 2026**

**Status:** Research and engineering prototype. Not a validated high-stakes educational assessment. Sample question parameters and student records are illustrative.

## Executive summary

This paper proposes StudentAbility AI, a database-independent educational assessment engine for **Maths, Physics, English, Chemistry and Biology**. The engine estimates what students can demonstrate from responses to curriculum-linked questions, while explicitly reporting the limits of the available evidence. Rather than equating a test percentage with intrinsic ability, it uses two-parameter logistic item response theory (2PL IRT) with a Bayesian standard-normal ability prior. The implementation provides per-subject and per-topic estimates, approximate uncertainty bounds, adaptive question selection and conservative offline updating of question parameters.

A single Python/FastAPI service implements the psychometric algorithms. Separate persistence adapters target MySQL (SQLAlchemy/PyMySQL) and MongoDB (PyMongo). Both store student identities, assessment items, responses and materialized ability snapshots. The reference engine includes 60 curated demonstration multiple-choice items and optional synthetic learners. It is suitable for prototyping classroom formative assessments and for building a validated assessment platform with additional psychometric and security controls.

The underlying model builds on standard 2PL IRT formulations [1]. Operational validity and fairness requirements should follow the **Standards for Educational and Psychological Testing**, jointly developed by AERA, APA and NCME [2]. This paper intentionally distinguishes an implemented feature from a future research requirement.

## 1. Objectives and interpretation

The engine addresses four practical questions: (1) What evidence of subject proficiency has a student demonstrated? (2) Which curriculum topics have insufficient coverage or appear challenging? (3) Which question should be asked next to gather useful evidence efficiently? (4) How uncertain is the inference, and when is additional assessment preferable to an ability label?

The five subjects are independent dimensions of proficiency. Maths and English estimates must not be interpreted as interchangeable psychometric units unless scales are linked or equated. A topic score indicates evidence on the specific assessed content, not a judgment about fixed intelligence, innate talent or future performance. The software supports binary-scored multiple-choice assessment; essays, laboratory work, communication skills and other constructed responses require separate rubric-based or trained models. Historical subject averages and exam marks are **not** model inputs: a defensible bridge from grades to IRT ability would require equated tests or an explicitly validated observation model, not simple percentage rescaling.

| Subject | Included example topics | Typical item evidence |
| --- | --- | --- |
| Maths | Algebra; Geometry; Statistics | Symbolic manipulation, spatial reasoning, basic data interpretation |
| Physics | Mechanics; Electricity; Waves | Physical laws, quantitative reasoning and concepts |
| English | Grammar; Vocabulary; Reading | Language rules, lexical knowledge, comprehension |
| Chemistry | Atomic Structure; Stoichiometry; Acids and Bases | Chemical concepts and quantitative reaction reasoning |
| Biology | Cell Biology; Genetics; Ecology | Organisms, cellular processes and systems |

These are demonstration topic partitions. Real deployments must bind questions to the school's learning standards, grade levels, language, accessibility requirements and curriculum versions.

## 2. Mathematical formulation

### 2.1 Two-parameter logistic response model

Let student s have latent ability θₛ for a particular subject or topic. Each question q has discrimination a_q > 0 and difficulty b_q. The observed binary result is y_sq ∈ {0,1}. The 2PL probability of a correct response is:

**Equation (1)**

```text
p_sq(θ) = P(Y_sq = 1 | θ, a_q, b_q)
        = 1 / [1 + exp(-a_q (θ - b_q))]
```

Discrimination controls sensitivity to ability differences; difficulty shifts the midpoint. For instance, at θ=1.0, b=0.5 and a=1.2 the predicted correct-response probability is approximately 0.646. Model probabilities are conditional estimates, not guarantees of performance.

### 2.2 Bayesian maximum-a-posteriori inference

Let a student's observed responses for a subject be D_s = {(a_q,b_q,y_sq)}. Set a standard-normal prior θ ~ N(0,1) to stabilize estimates when few responses are available. Maximize the log posterior:

**Equation (2)**

```text
L(θ) = -θ²/2 + Σ_q [ y_sq · log(p_sq(θ))
                      + (1-y_sq) · log(1-p_sq(θ)) ] + constant

θ_MAP = argmax_θ L(θ)
```

The first and second derivatives are:

**Equation (3)**

```text
L'(θ)  = -θ + Σ_q a_q [y_sq - p_sq(θ)]
-L''(θ) = 1 + Σ_q a_q² p_sq(θ)[1-p_sq(θ)]
```

Since negative curvature is positive, the log posterior is strictly concave under the assumptions used, and Newton iteration is straightforward:

```text
θ_next = clip( θ + L'(θ)/(-L''(θ)), -4, +4 )
```

The engine stops when the update is smaller than a numerical tolerance, or after a bounded number of iterations. The ±4 clamp is a numerical engineering guard, not a validated trait boundary. Real calibration should investigate whether such clipping introduces edge bias.

### 2.3 Uncertainty and the reference index

With a Laplace (local Gaussian) approximation, the conditional posterior standard error is:

**Equation (4)**

```text
SE(θ_MAP) ≈ [ 1 + Σ_q a_q² p_sq(θ_MAP)(1-p_sq(θ_MAP)) ]^(-1/2)
Approximate 95% interval: θ_MAP ± 1.96 · SE(θ_MAP)
```

These intervals omit item-parameter uncertainty and model misfit, so they can be overconfident. The API also exposes an easy-to-plot 0–100 **reference index**:

**Equation (5)**

```text
ReferenceIndex = 100 · sigmoid(θ_MAP)
```

This is the predicted probability, expressed as a percentage, for a **hypothetical reference question** with a=1 and b=0. It must not be called an exam mark, mastery percentage or population percentile. Students without any answers receive null estimates and `unassessed`, rather than an artificial 50-point ability score. The separate `observed_accuracy_pct` field reflects actual correctness on attempted items.

### 2.4 Subject and topic estimates

The engine estimates a subject θ from that subject's entire response set, and separately estimates topic θ from topic-specific responses. These marginal estimates are **not** a fully multidimensional hierarchical IRT model. Because a topic may contain very few questions, topic estimates are exploratory and should be used to identify what to assess next. The software provides evidence-coverage labels:

- `unassessed`: no scored observations; report null proficiency.
- `limited_evidence`: few observations or insufficient subject-topic coverage.
- `exploratory_coverage`: enough observations for the prototype's count-based rule, but **not** a certified reliability threshold.

## 3. Adaptive question selection

For a 2PL item, expected Fisher information at ability θ is:

**Equation (6)**

```text
I_q(θ) = a_q² · p_q(θ) · [1-p_q(θ)]
```

Information is often largest when an item is matched to the student's estimated ability. Pure information maximization can neglect whole curricular domains. This implementation first considers only unseen items, then chooses from the least-assessed available topic, finally selecting the highest-information item in that topic. This is an intentionally simple **content-balanced adaptive policy**.

**Algorithm A — Next-item selection**

```text
Input: student_id, requested subject
1. Load existing responses and all available subject items.
2. Remove every item already attempted by this student.
3. Estimate subject θ_MAP; if unassessed, use θ=0 for selection only.
4. Count answered questions in each remaining item's topic.
5. Restrict candidates to topics having the fewest answers.
6. Among candidates, maximize I_q(θ_MAP).
7. Return the question stem and choices, never the answer key.
8. If no unseen items exist, return 'no_unanswered_items'.
```

More mature computer-adaptive tests should enforce blueprint constraints, exposure control, reading-level suitability, prerequisite dependencies and minimum/maximum test lengths. For high-stakes use, a formal stopping rule should consider target standard error **and** content coverage and item security, rather than just number of correct answers.

## 4. Two learning loops

**Online student updating.** Upon each answer, the platform checks the student's item eligibility, grades the submitted choice against the server-held answer key, persists the response and recalculates subject/topic posteriors. Data is evidence, not a training label supplied by the student. The shared service writes current ability snapshots; reports always recompute from authoritative responses and latest item parameters.

**Offline item calibration.** An administrator may run a conservative parameter-update job on cohorts. In the prototype, each candidate item must have at least 100 eligible responses from independent student/item pairs, with enough other subject items per student to construct a **leave-target-item-out** proxy estimate of θ. The candidate 2PL discrimination and difficulty are fitted through regularized logistic likelihood, anchored to the original expert-assigned parameters. The fitting partition is separated deterministically from a holdout set. A parameter update is accepted only if holdout logistic loss improves by a minimum margin. Bounded changes limit abrupt parameter drift; every accepted update increments an item version.

**Algorithm B — Conservative calibration**

```text
Input: subject and labeled response history
For each item q:
  Keep students with at least four other subject responses.
  Infer proxy θ using their other items, excluding q.
  Require at least 100 eligible observations.
  Split by stable student+item hash (~80% train / ~20% held out).
  Require sufficient train/validation sizes and both answer classes.
  Fit (a_q,b_q) by constrained regularized logistic optimization.
  Compare validation cross-entropy against previous parameters.
  Accept only if validation loss improves; otherwise retain values.
Apply accepted item updates; persist versions and calibration metadata.
```

This is a **pragmatic experimental calibration method**, not full marginal maximum-likelihood estimation (MML), expectation-maximization, Bayesian hierarchical item fitting, scale equating or external validation. Proxy θ is noisy; selection bias, missing-not-at-random adaptive item assignment, item exposure and group differences require additional correction. Production item calibration should use an established psychometric workflow with fixed anchors, cross-validation, DIF analysis, item-fit diagnostics and independent expert review.

## 5. Reference software architecture

```text
Student assessment UI / Teacher dashboard / School API gateway
                              |
                  Authenticated REST requests
                              |
                     FastAPI controller
                              |
        +---------------------+---------------------+
        |                                           |
  Assessment service                          Calibration service
  - correctness scoring                       - cohort filtering
  - MAP IRT + uncertainty                     - leave-item-out ability
  - topic coverage                            - regularized item fitting
  - adaptive next item                        - held-out evaluation
        |                                           |
        +---------------------+---------------------+
                              |
                    Repository interface
                         /           \
              MySQL repository       MongoDB repository
              SQLAlchemy/PyMySQL     PyMongo
                     |                    |
              relational tables      collections/indexes
```

There is one reference application, not two independently maintained psychometric algorithms. Changing `DB_BACKEND=mysql` to `DB_BACKEND=mongodb` changes only the persistence adapter. Running two instances does **not** synchronize them. The data model uses stable UUID strings for students, items and responses, simplifying deliberate export and mapping workflows.

### 5.1 MySQL schema

The application maintains `tbl_students`, `tbl_assessment_items`, `tbl_student_responses` and `tbl_student_ability_scores`. Item metadata includes subject, topic, question/choices, server-held correct index, original and current IRT parameters, calibration version and calibration observation count. Response rows include the student's answer, derived correctness and timestamp, with a uniqueness constraint on (student_id,item_id). Score snapshots key (student_id,subject,topic), with the empty topic representing a subject-level estimate. MySQL foreign keys maintain relationships.

### 5.2 MongoDB schema

The Mongo adapter uses `students`, `items`, `responses` and `scores` collections. Compound indexes support efficient student histories, subject/topic item queries and idempotency protection. A unique student/item index prevents double counting the same item. Documents are intentionally similar to SQL row dictionaries to keep psychometric code shared. Production clusters should use authentication, backup policies, TLS and schema validation rules at the database boundary.

### 5.3 REST surface

| Method | Endpoint | Function |
| --- | --- | --- |
| GET | `/health` | Database readiness |
| GET | `/v1/subjects` | Subject/topic taxonomy |
| POST | `/v1/students` | Register pseudonymous student |
| POST | `/v1/admin/items` | Admin adds validated-form MCQ |
| GET | `/v1/next-item` | Choose next unanswered adaptive question |
| POST | `/v1/responses` | Submit one answer and update estimates |
| GET | `/v1/students/{student_id}/report` | Subject and topic proficiency report |
| POST | `/v1/admin/calibrate/{subject}` | Run conservative batch recalibration |

The API example uses separate service and administrative API keys. **Those credentials are not role-aware user authentication.** A school integration must implement per-student access checks, staff authorization, consent, logging and downstream privacy controls before external exposure.

## 6. Evaluation design, fairness and validity

Software correctness is not the same as psychometric validity. Before deployment beyond an exploratory pilot, validate the following using real, consented students under an approved assessment procedure:

| Evaluation area | Proposed study or metric | Important limitation |
| --- | --- | --- |
| Response-model calibration | Reliability diagrams, calibration error, Brier score/log loss | Stratify by subject, grade and curriculum |
| Item quality | Item-fit residuals, discrimination, distractor analysis | Poorly written items can distort θ |
| Inference uncertainty | 95% coverage under simulation and replicate administrations | Laplace intervals ignore item parameter error |
| Reliability | Conditional reliability, test-retest correlations | Requires independent and sufficient observations |
| Construct validity | Expert blueprint review, alignment with external assessments | Correlation is not proof of validity |
| Fairness | Differential item functioning (DIF), linguistic accessibility, accommodation studies | Avoid simplistic demographic proxies |
| Adaptivity | Precision versus item count, blueprint coverage, exposure audit | Adaptive samples create selection bias |
| Operations | API p95 latency, duplicate prevention, failed requests and audit coverage | Security needs independent review |

The AERA/APA/NCME Standards explicitly emphasize validity, fairness, accessibility and appropriate score interpretations [2]. More recent educational measurement discussion also highlights how careless grouping can impair the interpretation of DIF analyses [3]. Teachers should retain the ability to challenge questionable items, inspect evidence and override any instructional recommendation. Do not use this prototype alone for student tracking, disciplinary placement, promotion, exclusion or other high-stakes decisions.

## 7. Security, privacy and governance

Data minimization is central: prefer pseudonymous student IDs, restrict the mapping to real identities, and store only information necessary for an assessment decision. Keep item answer keys behind administrative data-access paths; student item-fetch endpoints return question text and choices only. Use TLS, distinct DB credentials, separated service/admin secrets, least privilege, authenticated API gateways, role-based authorization, audit trails, backups, encryption at rest where available, and incident response plans. Set jurisdiction-specific consent, retention, deletion and access procedures. Avoid unapproved training or sharing of minors' records and apply relevant education/privacy laws where the institution operates.

Question parameters must be versioned. In this reference build, snapshots are refreshed during response submission and report access; calibration can make previously stored snapshots stale until refreshed. Production systems should trigger a background snapshot rebuild and record the score scale/model version for longitudinal comparisons. Question exposure, retakes, students switching grades, item removal and deleted data require explicit product policy.

## 8. Implementation status and roadmap

**Implemented:** 2PL logistic probabilities; Newton MAP estimates; approximate intervals; reference index; topic-level evidence; content-balanced adaptive selection; API-key-protected FastAPI routes; MySQL SQLAlchemy adapter; MongoDB PyMongo adapter; uniqueness controls; score snapshot storage; opt-in calibration with held-out evaluation; 60 seed questions; five deterministic simulated students; SQL-compatible integration tests.

**Not implemented:** grade-specific psychometric scales, curricular item-authoring QA, constructed-response grading, valid norm tables, equating, real-world DIF studies, multi-factor skill model, full MML/EM calibration, role-aware school SSO, reporting UI, data exchange with an existing SIS/LMS, large-scale load tests, or high-stakes certification.

Suggested phased roadmap:

1. **Curriculum mapping:** Agree subjects, topic tree, learning objectives, grades and languages with teachers; author and independently review the bank.
2. **Instrument pilot:** Recruit a consented, representative sample with planned anchor items and adequate coverage; estimate robust item parameters and check fit.
3. **Validity and fairness:** Audit construct coverage, prediction against meaningful outcomes, subgroup item functioning and accessibility, with remediation for problematic items.
4. **Security and integration:** Add institutional identity management, per-role permissions, SIS/LMS imports, deletion/retention, monitoring and incident controls.
5. **Controlled rollout:** Compare teacher judgment with model evidence, examine false-positive/false-negative instructional flags and monitor changes across terms.

## 9. Limitations and next-generation research

A single-subject latent trait is a useful baseline, but not all questions measure one dimension. Extended models can use multidimensional IRT, hierarchical topic traits, temporal knowledge tracing, item-to-skill Q-matrices, calibrated constructed-response models, or contextual learning features where consented and justified. Temporal decay should not be presumed: proficiency can be forgotten or reinforced, and repeated practice can inflate familiarity. In every case, independent validation is needed before claiming better inference.

The engine should recommend **evidence-gathering and instruction**, not assert that a student is inherently good or bad at a subject. For example, when three attempts are wrong in a narrow chemistry topic, an appropriate action can be to schedule additional differentiated questions and ask a teacher to review misconceptions, not label the student incapable of chemistry.

## References

[1] Pennsylvania State University, *Logistic IRT Models*, 2PL model tutorial. https://quantdev.ssri.psu.edu/sites/qdev/files/IRT_tutorial_FA17_2.html

[2] American Educational Research Association, American Psychological Association, and National Council on Measurement in Education, *Standards for Educational and Psychological Testing* (2014; open access announcement 2021). https://ncme.org/resources/books/testing-standards/

[3] National Council on Measurement in Education, *Educational Measurement*, fifth edition, Chapter 3, discussion of fairness and DIF. https://ncme.org/wp-content/uploads/2026/01/Educational-Measurement-Fifth-Edition-Chapter-03.pdf

[4] SQLAlchemy Project, *MySQL and MariaDB — SQLAlchemy 2.0 Documentation*. https://docs.sqlalchemy.org/en/20/dialects/mysql.html

[5] MongoDB, *PyMongo Driver: Indexes*. https://www.mongodb.com/docs/languages/python/pymongo-driver/current/indexes/

[6] FastAPI Project, official documentation. https://fastapi.tiangolo.com/

---

**Implementation disclaimer.** Whitepaper equations describe the actual reference implementation, except where explicitly noted as future work. Reported example outputs, seeded student responses, initial item parameters and 0–100 reference index are illustrative and should not be presented as validated student achievement results.
