"""Convert the canonical whitepaper Markdown into a professionally formatted DOCX.

Optional build dependency: python-docx. Convert to PDF using LibreOffice or
/home/oai/skills/docx/render_docx.py with --emit_pdf.
"""
from __future__ import annotations
from pathlib import Path
import re
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

HERE = Path(__file__).parent
SOURCE = HERE / "WHITEPAPER.md"
TARGET = HERE / "WHITEPAPER.docx"
NAVY = RGBColor(21, 40, 67)
TEAL = RGBColor(0, 115, 132)
GRAY = RGBColor(82, 93, 112)
LIGHT = "EFF5F7"


def set_background(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tcPr.append(shd)


def cant_split(row):
    trPr = row._tr.get_or_add_trPr()
    trPr.append(OxmlElement("w:cantSplit"))


def set_cell_margin(cell, top=100, start=110, bottom=100, end=110):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    margins = OxmlElement("w:tcMar")
    for name, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        attr = OxmlElement(f"w:{name}")
        attr.set(qn("w:w"), str(value))
        attr.set(qn("w:type"), "dxa")
        margins.append(attr)
    tcPr.append(margins)


def add_inline(paragraph, source):
    # Handle **strong**, `inline code` and regular text without accidental markdown.
    chunks = re.split(r"(\*\*[^*]+\*\*|`[^`]+`|\*[^*]+\*)", source)
    for chunk in chunks:
        if not chunk:
            continue
        run = paragraph.add_run(chunk[2:-2] if chunk.startswith("**") and chunk.endswith("**") else
                                chunk[1:-1] if (chunk.startswith("`") and chunk.endswith("`")) or
                                               (chunk.startswith("*") and chunk.endswith("*")) else chunk)
        if chunk.startswith("**") and chunk.endswith("**"):
            run.bold = True
        if chunk.startswith("*") and chunk.endswith("*") and not chunk.startswith("**"):
            run.italic = True
        if chunk.startswith("`") and chunk.endswith("`"):
            run.font.name = "DejaVu Sans Mono"
            run.font.size = Pt(8.2)
            run.font.color.rgb = TEAL


def make_style(doc, name, font_name, size, bold=False, color= NAVY,
               before=0, after=0, line=1.16, base=None):
    s = doc.styles[name] if name in doc.styles else doc.styles.add_style(name, WD_STYLE_TYPE.PARAGRAPH)
    if base:
        s.base_style = doc.styles[base]
    s.font.name = font_name
    s.font.size = Pt(size)
    s.font.bold = bold
    s.font.color.rgb = color
    pf = s.paragraph_format
    pf.space_before = Pt(before)
    pf.space_after = Pt(after)
    pf.line_spacing = line
    if name.startswith("Heading"):
        pf.keep_with_next = True
    return s


def format_document(doc):
    sec = doc.sections[0]
    sec.page_height = Inches(11.69)
    sec.page_width = Inches(8.27)
    sec.left_margin = Inches(0.86)
    sec.right_margin = Inches(0.82)
    sec.top_margin = Inches(0.82)
    sec.bottom_margin = Inches(0.78)
    sec.header_distance = Inches(0.34)
    sec.footer_distance = Inches(0.39)
    make_style(doc, "Normal", "Aptos", 9.1, color=NAVY, after=6.2, line=1.20)
    make_style(doc, "Title", "Aptos Display", 29, bold=True, before=0, after=15)
    make_style(doc, "Subtitle", "Aptos", 14.2, color=TEAL, after=18)
    make_style(doc, "Heading 1", "Aptos Display", 15.5, bold=True, before=16, after=7)
    make_style(doc, "Heading 2", "Aptos", 11.3, bold=True, color=TEAL, before=11, after=4)
    make_style(doc, "Heading 3", "Aptos", 10, bold=True, before=8, after=3)
    make_style(doc, "CodePara", "DejaVu Sans Mono", 7.6, color=NAVY, before=3, after=3, line=1.1)
    make_style(doc, "SmallInfo", "Aptos", 8.4, color=GRAY, after=6)

    h = sec.header.paragraphs[0]
    h.style = doc.styles["SmallInfo"]
    h.add_run("STUDENTABILITY AI").bold = True
    h.add_run("    /    REFERENCE ARCHITECTURE & TECHNICAL WHITEPAPER")
    h.alignment = WD_ALIGN_PARAGRAPH.RIGHT

    f = sec.footer.paragraphs[0]
    f.style = doc.styles["SmallInfo"]
    f.add_run("14 OCT 2026  •  RESEARCH PROTOTYPE  •  ")
    field = OxmlElement('w:fldSimple')
    field.set(qn('w:instr'), 'PAGE')
    f._p.append(field)
    f.alignment = WD_ALIGN_PARAGRAPH.RIGHT


def create_cover(doc):
    doc.add_paragraph("EDUCATIONAL MEASUREMENT / ENGINEERING", style="SmallInfo")
    for _ in range(3):
        doc.add_paragraph("")
    title = doc.add_paragraph(style="Title")
    title.add_run("StudentAbility AI")
    subtitle = doc.add_paragraph(style="Subtitle")
    subtitle.add_run("A Bayesian, Adaptive Evaluation Engine\nfor Five School Subjects")
    p = doc.add_paragraph(style="SmallInfo")
    p.add_run("TECHNICAL WHITEPAPER  |  14 OCTOBER 2026")
    doc.add_paragraph("")
    table = doc.add_table(rows=3, cols=2)
    table.autofit = False
    table.columns[0].width = Inches(1.32)
    table.columns[1].width = Inches(4.66)
    cover_rows = [
        ("SUBJECTS", "Maths · Physics · English · Chemistry · Biology"),
        ("METHOD", "2PL Item Response Theory · Bayesian MAP · Adaptive Selection"),
        ("PERSISTENCE", "Python/FastAPI · MySQL/PyMySQL · MongoDB/PyMongo"),
    ]
    for row, (label, value) in zip(table.rows, cover_rows):
        for cell in row.cells:
            set_background(cell, LIGHT)
            set_cell_margin(cell, top=130, bottom=130, start=110, end=110)
        run = row.cells[0].paragraphs[0].add_run(label)
        run.bold = True
        run.font.size = Pt(8)
        run.font.color.rgb = TEAL
        run = row.cells[1].paragraphs[0].add_run(value)
        run.font.size = Pt(8.8)
        cant_split(row)
    doc.add_paragraph("")
    status = doc.add_paragraph(style="SmallInfo")
    status.add_run("IMPORTANT  ").bold = True
    status.add_run("Engineering research prototype. Demonstration parameters and student records are unvalidated; not for high-stakes testing.")
    doc.add_page_break()


def add_table(doc, rows):
    if not rows:
        return
    cols = len(rows[0])
    table = doc.add_table(rows=0, cols=cols)
    table.style = "Table Grid"
    table.autofit = True
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, values in enumerate(rows):
        cells = table.add_row().cells
        for j, val in enumerate(values):
            cell = cells[j]
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margin(cell, top=80, bottom=80, start=90, end=90)
            cell.text = ""
            pp = cell.paragraphs[0]
            pp.paragraph_format.space_after = Pt(0)
            add_inline(pp, val)
            for run in pp.runs:
                run.font.size = Pt(8.1 if cols <= 3 else 7.3)
                if i == 0:
                    run.bold = True
                    run.font.color.rgb = RGBColor(255, 255, 255)
            if i == 0:
                set_background(cell, "18364B")
            elif i % 2 == 0:
                set_background(cell, "F3F8FA")
        cant_split(table.rows[-1])
    # Repeat the column labels if a table spans more than one page.
    if table.rows:
        prop = table.rows[0]._tr.get_or_add_trPr()
        header_flag = OxmlElement("w:tblHeader")
        header_flag.set(qn("w:val"), "true")
        prop.append(header_flag)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)


def add_code(doc, lines):
    # Keep each line separate so long blocks may break naturally at page edges.
    for n, line in enumerate(lines):
        p = doc.add_paragraph(style="CodePara")
        p.paragraph_format.left_indent = Inches(0.11)
        p.paragraph_format.right_indent = Inches(0.09)
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0 if n != len(lines) - 1 else 6)
        p.add_run(line if line else " ")
        shade = OxmlElement('w:shd')
        shade.set(qn('w:fill'), 'F1F6F8')
        p._p.get_or_add_pPr().append(shade)


def parse_md(doc, source):
    lines = source.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line:
            i += 1
            continue
        if line == "---":
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(6)
            i += 1
            continue
        if line.startswith("# "):
            # Already represented in cover; skip duplicate title.
            i += 1
            continue
        if line.startswith("## A Bayesian"):
            # Already represented in cover; skip duplicate subtitle.
            i += 1
            continue
        if line.startswith("## "):
            doc.add_paragraph(line[3:], style="Heading 1")
            i += 1
            continue
        if line.startswith("### "):
            doc.add_paragraph(line[4:], style="Heading 2")
            i += 1
            continue
        if line.startswith("``` ") or line == "```" or line.startswith("```text"):
            i += 1
            block = []
            while i < len(lines) and not lines[i].startswith("```"):
                block.append(lines[i].rstrip())
                i += 1
            add_code(doc, block)
            i += 1
            continue
        if line.startswith("|"):
            table_rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                    table_rows.append(cells)
                i += 1
            add_table(doc, table_rows)
            continue
        if line.startswith("- "):
            p = doc.add_paragraph(style="Normal")
            p.style = "List Bullet"
            p.paragraph_format.left_indent = Inches(0.24)
            p.paragraph_format.space_after = Pt(3)
            add_inline(p, line[2:])
            i += 1
            continue
        if re.match(r"^\d+\. ", line):
            p = doc.add_paragraph(style="Normal")
            p.style = "List Number"
            p.paragraph_format.left_indent = Inches(0.26)
            p.paragraph_format.space_after = Pt(4)
            add_inline(p, re.sub(r"^\d+\. ", "", line))
            i += 1
            continue
        # Consecutive non-structure lines form a flowing paragraph.
        para = [line]
        i += 1
        while i < len(lines) and lines[i].strip() and not (
            lines[i].startswith("#") or lines[i].startswith("|") or
            lines[i].startswith("```") or lines[i].startswith("- ") or
            re.match(r"^\d+\. ", lines[i]) or lines[i].strip() == '---'
        ):
            para.append(lines[i].strip())
            i += 1
        p = doc.add_paragraph(style="Normal")
        add_inline(p, " ".join(para))


def main():
    doc = Document()
    format_document(doc)
    create_cover(doc)
    parse_md(doc, SOURCE.read_text(encoding='utf-8'))
    doc.core_properties.title = "StudentAbility AI - Technical Whitepaper"
    doc.core_properties.subject = "Bayesian IRT assessment engine for MySQL and MongoDB"
    doc.core_properties.keywords = "IRT Bayesian Assessment MySQL MongoDB Adaptive Assessment"
    doc.core_properties.author = "StudentAbility AI reference implementation"
    doc.save(TARGET)
    print(TARGET)

if __name__ == '__main__':
    main()
