// MongoDB indexes also created automatically by app/mongo_store.py.
// Run with: mongosh student_ability schemas/mongodb_indexes.js
// This example intentionally omits real student records and answer data.
db.students.createIndex({student_id: 1}, {unique: true});
db.students.createIndex({external_ref: 1}, {sparse: true});
db.items.createIndex({item_id: 1}, {unique: true});
db.items.createIndex({subject: 1, topic: 1});
db.responses.createIndex({response_id: 1}, {unique: true});
db.responses.createIndex({student_id: 1, item_id: 1}, {unique: true});
db.responses.createIndex({student_id: 1, answered_at: 1});
db.scores.createIndex({student_id: 1, subject: 1, topic: 1}, {unique: true});
