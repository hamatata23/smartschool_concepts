-- StudentAbility AI v1.0 - MySQL 8.x reference DDL
-- The SQLAlchemy repository creates equivalent tables automatically.
-- All timestamps are UTC ISO-8601 VARCHAR strings in the reference implementation.
CREATE DATABASE IF NOT EXISTS student_ability CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE student_ability;

CREATE TABLE IF NOT EXISTS tbl_students (
  student_id VARCHAR(36) PRIMARY KEY,
  external_ref VARCHAR(128) NULL,
  grade_level INT NULL,
  created_at VARCHAR(35) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tbl_assessment_items (
  item_id VARCHAR(36) PRIMARY KEY,
  subject VARCHAR(24) NOT NULL,
  topic VARCHAR(100) NOT NULL,
  question_text TEXT NOT NULL,
  choices JSON NOT NULL,
  correct_index INT NOT NULL,
  difficulty FLOAT NOT NULL,
  discrimination FLOAT NOT NULL,
  initial_difficulty FLOAT NOT NULL,
  initial_discrimination FLOAT NOT NULL,
  parameter_version INT NOT NULL DEFAULT 0,
  calibration_n INT NOT NULL DEFAULT 0,
  calibrated_at VARCHAR(35) NULL,
  created_at VARCHAR(35) NOT NULL,
  INDEX ix_items_subject_topic (subject,topic)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tbl_student_responses (
  response_id VARCHAR(36) PRIMARY KEY,
  student_id VARCHAR(36) NOT NULL,
  item_id VARCHAR(36) NOT NULL,
  selected_index INT NOT NULL,
  is_correct BOOLEAN NOT NULL,
  answered_at VARCHAR(35) NOT NULL,
  UNIQUE KEY uq_student_item (student_id,item_id),
  INDEX ix_responses_student_time (student_id,answered_at),
  INDEX ix_responses_item (item_id),
  CONSTRAINT fk_response_student FOREIGN KEY (student_id)
    REFERENCES tbl_students(student_id) ON DELETE CASCADE,
  CONSTRAINT fk_response_item FOREIGN KEY (item_id)
    REFERENCES tbl_assessment_items(item_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tbl_student_ability_scores (
  student_id VARCHAR(36) NOT NULL,
  subject VARCHAR(24) NOT NULL,
  topic VARCHAR(100) NOT NULL,
  theta FLOAT NULL,
  standard_error FLOAT NULL,
  ability_index_pct FLOAT NULL,
  response_count INT NOT NULL,
  evidence_status VARCHAR(30) NOT NULL,
  model_version VARCHAR(30) NOT NULL,
  updated_at VARCHAR(35) NOT NULL,
  PRIMARY KEY (student_id,subject,topic),
  CONSTRAINT fk_score_student FOREIGN KEY (student_id)
    REFERENCES tbl_students(student_id) ON DELETE CASCADE
) ENGINE=InnoDB;
