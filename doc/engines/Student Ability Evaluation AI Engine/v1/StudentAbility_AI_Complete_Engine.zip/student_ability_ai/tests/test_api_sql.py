import os
import pytest
from fastapi.testclient import TestClient
from app.api import create_app
from app.mysql_store import MySQLRepository
from app.schemas import Subject
from app.seed import seed_items, seed_demo_students

@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("API_KEY", "dev-student-key-for-tests")
    monkeypatch.setenv("ADMIN_API_KEY", "dev-admin-key-for-tests")
    repo = MySQLRepository(f"sqlite:///{tmp_path}/ability.db")
    with TestClient(create_app(repo)) as http:
        yield http, repo


def test_full_assessment_with_sql_backend(client):
    http, repo = client
    assert http.get("/health").status_code == 200
    assert http.get("/v1/subjects").status_code == 401
    headers = {"X-API-Key": "dev-student-key-for-tests"}
    admin = {"X-Admin-Key": "dev-admin-key-for-tests"}
    assert len(http.get("/v1/subjects", headers=headers).json()) == 5

    student = http.post("/v1/students", json={"external_ref": "mock-class-42", "grade_level": 10}, headers=headers)
    assert student.status_code == 201, student.text
    student_id = student.json()["student_id"]

    new_item = http.post("/v1/admin/items", headers=admin, json={
        "subject": "Maths", "topic": "Algebra", "question_text": "What is 2 plus 2?",
        "choices": ["2", "3", "4", "5"], "correct_index": 2,
        "difficulty": 0.1, "discrimination": 1.0,
    })
    assert new_item.status_code == 201, new_item.text
    item_id = new_item.json()["item_id"]
    assert http.post("/v1/admin/items", headers=headers, json={
        "subject": "Maths", "topic": "Algebra", "question_text": "What is 3 plus 3?",
        "choices": ["3", "6"], "correct_index": 1,
    }).status_code == 401

    nxt = http.get("/v1/next-item", params={"student_id": student_id, "subject": "Maths"}, headers=headers)
    assert nxt.status_code == 200, nxt.text
    assert nxt.json()["item"]["item_id"] == item_id
    assert "correct_index" not in nxt.json()["item"]
    assert "difficulty" not in nxt.json()["item"]

    submitted = http.post("/v1/responses", json={"student_id": student_id, "item_id": item_id,
                                                    "selected_index": 2}, headers=headers)
    assert submitted.status_code == 201, submitted.text
    assert submitted.json()["is_correct"] is True
    assert submitted.json()["subject_ability_index_pct"] > 50

    duplicate = http.post("/v1/responses", json={"student_id": student_id, "item_id": item_id,
                                                    "selected_index": 2}, headers=headers)
    assert duplicate.status_code == 409

    report = http.get(f"/v1/students/{student_id}/report", headers=headers)
    assert report.status_code == 200, report.text
    data = report.json()
    assert len(data["subjects"]) == 5
    maths = next(r for r in data["subjects"] if r["subject"] == "Maths")
    assert maths["response_count"] == 1 and maths["correct_count"] == 1
    assert maths["evidence_status"] == "limited_evidence"
    english = next(r for r in data["subjects"] if r["subject"] == "English")
    assert english["theta"] is None and english["evidence_status"] == "unassessed"
    assert len(repo.list_scores(student_id)) == 20  # 5 subjects + 3 topics each

    no_more = http.get("/v1/next-item", params={"student_id": student_id, "subject": "Maths"}, headers=headers)
    assert no_more.json()["status"] == "no_unanswered_items"


def test_question_validation_and_calibration_safety(client):
    http, repo = client
    admin = {"X-Admin-Key": "dev-admin-key-for-tests"}
    invalid = http.post("/v1/admin/items", json={
        "subject": "Maths", "topic": "Invalid Topic", "question_text": "Test question?",
        "choices": ["Yes", "No"], "correct_index": 0,
    }, headers=admin)
    assert invalid.status_code == 422
    seed_items(repo)
    summary = http.post("/v1/admin/calibrate/Maths", headers=admin)
    assert summary.status_code == 200, summary.text
    assert summary.json()["items_updated"] == 0
    assert summary.json()["items_examined"] == 12


def test_demo_seed_and_adaptive_balance(client):
    http, repo = client
    seed_items(repo)
    demos = seed_demo_students(repo)
    assert len(demos) == 5
    for demo in demos:
        report = http.get(f"/v1/students/{demo['student_id']}/report",
                          headers={"X-API-Key": "dev-student-key-for-tests"})
        assert report.status_code == 200
        for subject in report.json()["subjects"]:
            assert subject["response_count"] == 12
            assert subject["evidence_status"] == "exploratory_coverage"
