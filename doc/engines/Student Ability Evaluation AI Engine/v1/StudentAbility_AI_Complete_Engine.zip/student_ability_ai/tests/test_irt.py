from app.irt import estimate_ability, response_probability, item_information


def test_ability_increases_with_more_correct_answers():
    lower = estimate_ability([(1.0, 0, 0)] * 8)
    higher = estimate_ability([(1.0, 0, 1)] * 8)
    assert lower["theta"] < 0 < higher["theta"]
    assert lower["ability_index_pct"] < 50 < higher["ability_index_pct"]


def test_difficult_questions_add_more_evidence_for_ability():
    easy = estimate_ability([(1.0, -1.0, 1)] * 8)
    hard = estimate_ability([(1.0, 1.0, 1)] * 8)
    assert hard["theta"] > easy["theta"]


def test_uncertainty_shrinks_with_more_evidence():
    few = estimate_ability([(1.0, 0, 1), (1.0, 0, 0)])
    many = estimate_ability([(1.0, 0, 1), (1.0, 0, 0)] * 12)
    assert many["standard_error"] < few["standard_error"]
    assert many["response_count"] == 24


def test_unassessed_remains_null():
    empty = estimate_ability([])
    assert empty["theta"] is None
    assert empty["ability_index_pct"] is None
    assert empty["response_count"] == 0


def test_information_peaks_near_item_difficulty():
    assert item_information(0, 1.0, 0) > item_information(4, 1.0, 0)
    assert abs(response_probability(0, 1, 0) - 0.5) < 1e-10
