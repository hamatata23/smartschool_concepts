"""Mongo adapter contract tests; enabled when dev extras are installed."""
import pytest

pymongo = pytest.importorskip("pymongo", reason="pip install -r requirements-dev.txt")
mongomock = pytest.importorskip("mongomock", reason="pip install -r requirements-dev.txt")

from fastapi.testclient import TestClient
from app.mongo_store import MongoRepository
from app.api import create_app
from app.seed import seed_items


def test_mongo_adapter_and_api(monkeypatch):
    monkeypatch.setenv("API_KEY", "mongo-test-api-key")
    monkeypatch.setenv("ADMIN_API_KEY", "mongo-test-admin-key")
    repo = MongoRepository(client=mongomock.MongoClient(), db_name="test_ability")
    assert sum(seed_items(repo).values()) == 60
    assert sum(seed_items(repo).values()) == 0   # seed idempotent
    with TestClient(create_app(repo)) as http:
        h = {"X-API-Key": "mongo-test-api-key"}
        student_resp = http.post("/v1/students", headers=h, json={"external_ref": "mongo-pupil"})
        assert student_resp.status_code == 201
        student_id = student_resp.json()["student_id"]
        nxt = http.get("/v1/next-item", headers=h,
                       params={"student_id": student_id, "subject": "Physics"})
        assert nxt.status_code == 200
        q = nxt.json()["item"]
        assert "correct_index" not in q
        response = http.post("/v1/responses", headers=h, json={
            "student_id": student_id, "item_id": q["item_id"], "selected_index": 0,
        })
        assert response.status_code == 201, response.text
        again = http.post("/v1/responses", headers=h, json={
            "student_id": student_id, "item_id": q["item_id"], "selected_index": 0,
        })
        assert again.status_code == 409
        summary = http.get(f"/v1/students/{student_id}/report", headers=h)
        assert summary.status_code == 200
        assert len(repo.list_scores(student_id)) == 20
