"""Synthetic mathematical smoke test, NOT an empirical validity study."""
from random import Random
from uuid import uuid4
from app.mysql_store import MySQLRepository
from app.schemas import ItemCreate
from app.services import new_item_record, new_student_record, new_response_record
from app.irt import response_probability
from app.calibration import calibrate_subject


def test_calibration_can_update_an_obviously_miscalibrated_item(tmp_path):
    rng = Random(6810)
    repo = MySQLRepository(f"sqlite:///{tmp_path}/training.db")
    anchors = []
    for k, b in enumerate([-1.5, -0.8, -0.2, 0.4, 1.0, 1.5]):
        item = new_item_record(ItemCreate(
            subject="Maths", topic="Algebra", question_text=f"Calibrated anchor question {k}?",
            choices=["No", "Yes"], correct_index=1,
            difficulty=b, discrimination=1.2,
        ).model_dump())
        repo.create_item(item)
        anchors.append(item)
    target = new_item_record(ItemCreate(
        subject="Maths", topic="Algebra", question_text="Miscalibrated target question?",
        choices=["No", "Yes"], correct_index=1,
        difficulty=1.5, discrimination=1.0,
    ).model_dump())
    repo.create_item(target)

    for i in range(240):
        student = new_student_record(external_ref=f"synth-{i}")
        repo.create_student(student)
        theta = rng.gauss(0, 1)
        for item in anchors + [target]:
            true_b = -0.8 if item["item_id"] == target["item_id"] else item["difficulty"]
            correct = rng.random() < response_probability(theta, item["discrimination"], true_b)
            chosen = 1 if correct else 0
            repo.create_response(new_response_record(student["student_id"], item, chosen))

    summary = calibrate_subject(repo, "Maths")
    assert summary["items_examined"] == 7
    assert summary["items_updated"] >= 1
    trained_target = repo.get_item(target["item_id"])
    assert trained_target["difficulty"] < target["difficulty"]
    assert trained_target["parameter_version"] >= 1
