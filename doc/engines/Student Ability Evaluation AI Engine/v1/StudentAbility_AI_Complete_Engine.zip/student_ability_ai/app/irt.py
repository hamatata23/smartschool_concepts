"""2PL IRT probability and Bayesian MAP ability estimate.

The 0-100 reference index is probability of a correct response to a hypothetical
standard item (difficulty 0, discrimination 1); it is NOT a grade or percentile.
"""
from __future__ import annotations
from math import exp, sqrt
from collections.abc import Sequence


def logistic(x: float) -> float:
    if x >= 0:
        return 1 / (1 + exp(-x))
    ex = exp(x)
    return ex / (1 + ex)


def response_probability(theta: float, discrimination: float, difficulty: float) -> float:
    return logistic(discrimination * (theta - difficulty))


def item_information(theta: float, discrimination: float, difficulty: float) -> float:
    p = response_probability(theta, discrimination, difficulty)
    return (discrimination**2) * p * (1 - p)


def estimate_ability(evidence: Sequence[tuple[float, float, int]]) -> dict:
    """Estimate from tuples (discrimination, difficulty, correctness).

    Standard normal prior, bounded Newton MAP, observed-information/Laplace CI.
    No evidence yields missing estimates rather than a misleading 'average' score.
    """
    n = len(evidence)
    if n == 0:
        return {
            "theta": None, "standard_error": None,
            "ci95_theta": None, "ability_index_pct": None,
            "ci95_index_pct": None, "response_count": 0,
            "correct_count": 0, "observed_accuracy_pct": None,
        }
    theta = 0.0
    for _ in range(80):
        gradient = -theta  # N(0,1) prior log-density derivative
        precision = 1.0
        for discrimination, difficulty, y in evidence:
            if y not in (0, 1) or discrimination <= 0:
                raise ValueError("Invalid psychometric evidence")
            p = response_probability(theta, discrimination, difficulty)
            gradient += discrimination * (y - p)
            precision += discrimination**2 * p * (1 - p)
        updated = max(-4.0, min(4.0, theta + gradient / precision))
        if abs(updated - theta) < 1e-9:
            theta = updated
            break
        theta = updated

    precision = 1 + sum(
        a**2 * response_probability(theta, a, b)
        * (1 - response_probability(theta, a, b))
        for a, b, _ in evidence
    )
    se = 1 / sqrt(precision)
    lo, hi = theta - 1.96 * se, theta + 1.96 * se
    pct = lambda t: round(100 * logistic(t), 2)
    correct = sum(y for _, _, y in evidence)
    return {
        "theta": round(theta, 4),
        "standard_error": round(se, 4),
        "ci95_theta": [round(lo, 4), round(hi, 4)],
        "ability_index_pct": pct(theta),
        "ci95_index_pct": [pct(lo), pct(hi)],
        "response_count": n,
        "correct_count": correct,
        "observed_accuracy_pct": round(100 * correct / n, 2),
    }


def evidence_status(response_count: int, covered_topics: int) -> str:
    """Coverage warnings are design heuristics, not validated reliability cutoffs."""
    if response_count == 0:
        return "unassessed"
    if response_count < 10 or covered_topics < 2:
        return "limited_evidence"
    return "exploratory_coverage"
