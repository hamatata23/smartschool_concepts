"""SQLAlchemy Core repository for MySQL 8+. SQLite URL is supported ONLY for tests.

The mysql+pymysql://... URI is the production connection type.
"""
from __future__ import annotations
from sqlalchemy import (
    create_engine, MetaData, Table, Column, String, Integer, Float,
    Boolean, JSON, Text, ForeignKey, UniqueConstraint, Index,
    insert, select, update, and_, text,
)
from sqlalchemy.exc import IntegrityError

class StorageConflict(Exception):
    pass

metadata = MetaData()

students = Table(
    "tbl_students", metadata,
    Column("student_id", String(36), primary_key=True),
    Column("external_ref", String(128), nullable=True),
    Column("grade_level", Integer, nullable=True),
    Column("created_at", String(35), nullable=False),
)

items = Table(
    "tbl_assessment_items", metadata,
    Column("item_id", String(36), primary_key=True),
    Column("subject", String(24), nullable=False),
    Column("topic", String(100), nullable=False),
    Column("question_text", Text, nullable=False),
    Column("choices", JSON, nullable=False),
    Column("correct_index", Integer, nullable=False),
    Column("difficulty", Float, nullable=False),
    Column("discrimination", Float, nullable=False),
    Column("initial_difficulty", Float, nullable=False),
    Column("initial_discrimination", Float, nullable=False),
    Column("parameter_version", Integer, nullable=False, default=0),
    Column("calibration_n", Integer, nullable=False, default=0),
    Column("calibrated_at", String(35), nullable=True),
    Column("created_at", String(35), nullable=False),
    Index("ix_items_subject_topic", "subject", "topic"),
)

responses = Table(
    "tbl_student_responses", metadata,
    Column("response_id", String(36), primary_key=True),
    Column("student_id", String(36), ForeignKey("tbl_students.student_id", ondelete="CASCADE"), nullable=False),
    Column("item_id", String(36), ForeignKey("tbl_assessment_items.item_id"), nullable=False),
    Column("selected_index", Integer, nullable=False),
    Column("is_correct", Boolean, nullable=False),
    Column("answered_at", String(35), nullable=False),
    UniqueConstraint("student_id", "item_id", name="uq_student_item"),
    Index("ix_responses_student_time", "student_id", "answered_at"),
    Index("ix_responses_item", "item_id"),
)

scores = Table(
    "tbl_student_ability_scores", metadata,
    Column("student_id", String(36), ForeignKey("tbl_students.student_id", ondelete="CASCADE"), primary_key=True),
    Column("subject", String(24), primary_key=True),
    Column("topic", String(100), primary_key=True),  # empty string denotes subject-wide
    Column("theta", Float),
    Column("standard_error", Float),
    Column("ability_index_pct", Float),
    Column("response_count", Integer, nullable=False),
    Column("evidence_status", String(30), nullable=False),
    Column("model_version", String(30), nullable=False),
    Column("updated_at", String(35), nullable=False),
)


class MySQLRepository:
    def __init__(self, uri: str):
        self.engine = create_engine(uri, pool_pre_ping=True, pool_recycle=3600)
        metadata.create_all(self.engine)

    def health(self):
        with self.engine.connect() as conn:
            conn.execute(text("SELECT 1"))

    def create_student(self, data: dict) -> dict:
        with self.engine.begin() as conn:
            try:
                conn.execute(insert(students).values(**data))
            except IntegrityError as e:
                raise StorageConflict("Student already exists") from e
        return data

    def get_student(self, student_id: str) -> dict | None:
        with self.engine.connect() as conn:
            row = conn.execute(select(students).where(students.c.student_id == student_id)).mappings().first()
        return dict(row) if row else None

    def create_item(self, data: dict) -> dict:
        with self.engine.begin() as conn:
            try:
                conn.execute(insert(items).values(**data))
            except IntegrityError as e:
                raise StorageConflict("Item already exists") from e
        return data

    def get_item(self, item_id: str) -> dict | None:
        with self.engine.connect() as conn:
            row = conn.execute(select(items).where(items.c.item_id == item_id)).mappings().first()
        return dict(row) if row else None

    def list_items(self, subject: str | None = None) -> list[dict]:
        q = select(items)
        if subject:
            q = q.where(items.c.subject == subject)
        with self.engine.connect() as conn:
            return [dict(x) for x in conn.execute(q).mappings().all()]

    def list_items_by_ids(self, item_ids: list[str]) -> list[dict]:
        if not item_ids:
            return []
        with self.engine.connect() as conn:
            return [dict(x) for x in conn.execute(select(items).where(items.c.item_id.in_(item_ids))).mappings().all()]

    def create_response(self, data: dict) -> dict:
        with self.engine.begin() as conn:
            try:
                conn.execute(insert(responses).values(**data))
            except IntegrityError as e:
                raise StorageConflict("Response already exists for this student and item") from e
        return data

    def list_student_responses(self, student_id: str) -> list[dict]:
        q = select(responses).where(responses.c.student_id == student_id).order_by(responses.c.answered_at)
        with self.engine.connect() as conn:
            return [dict(x) for x in conn.execute(q).mappings().all()]

    def list_responses_for_subject(self, subject: str) -> list[dict]:
        q = select(responses).select_from(responses.join(items)).where(items.c.subject == subject)
        with self.engine.connect() as conn:
            return [dict(x) for x in conn.execute(q).mappings().all()]

    def update_item_parameters(self, item_id: str, a: float, b: float, n: int, now: str):
        with self.engine.begin() as conn:
            conn.execute(
                update(items).where(items.c.item_id == item_id).values(
                    discrimination=a, difficulty=b, calibration_n=n,
                    calibrated_at=now, parameter_version=items.c.parameter_version + 1,
                )
            )

    def upsert_scores(self, snapshots: list[dict]):
        with self.engine.begin() as conn:
            for data in snapshots:
                key = and_(
                    scores.c.student_id == data["student_id"],
                    scores.c.subject == data["subject"],
                    scores.c.topic == data["topic"],
                )
                result = conn.execute(update(scores).where(key).values(**data))
                if result.rowcount == 0:
                    try:
                        conn.execute(insert(scores).values(**data))
                    except IntegrityError:
                        # Another worker inserted concurrently. Last writer recomputes on read.
                        conn.execute(update(scores).where(key).values(**data))

    def list_scores(self, student_id: str) -> list[dict]:
        with self.engine.connect() as conn:
            return [dict(x) for x in conn.execute(
                select(scores).where(scores.c.student_id == student_id)
            ).mappings().all()]
