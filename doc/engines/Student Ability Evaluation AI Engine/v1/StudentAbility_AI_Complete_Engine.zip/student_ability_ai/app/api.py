"""Backend-agnostic FastAPI application.

IMPORTANT: X-API-Key is a service-to-service demo credential, not student login.
For production: authorization per student/teacher, TLS, audit logging, rate limits.
"""
from __future__ import annotations
from functools import lru_cache
from hmac import compare_digest
import os
from fastapi import FastAPI, HTTPException, Header, Depends, Query
from app.config import make_repository
from app.schemas import Subject, SUBJECT_TOPICS, StudentCreate, ItemCreate, StudentResponseCreate
from app.services import (
    new_student_record, new_item_record, new_response_record,
    public_item, select_next_item, assessment_report,
)
from app.calibration import calibrate_subject


@lru_cache(maxsize=1)
def default_repository():
    return make_repository()


def api_auth(x_api_key: str | None = Header(default=None, alias="X-API-Key")):
    expected = os.environ.get("API_KEY", "")
    if not expected:
        raise HTTPException(503, "API_KEY is not configured")
    if not x_api_key or not compare_digest(x_api_key, expected):
        raise HTTPException(401, "Invalid API key")


def admin_auth(x_admin_key: str | None = Header(default=None, alias="X-Admin-Key")):
    expected = os.environ.get("ADMIN_API_KEY", "")
    if not expected:
        raise HTTPException(503, "ADMIN_API_KEY is not configured")
    if not x_admin_key or not compare_digest(x_admin_key, expected):
        raise HTTPException(401, "Invalid admin key")


def create_app(repository=None) -> FastAPI:
    app = FastAPI(
        title="StudentAbility AI", version="1.0.0",
        description="Bayesian 2PL IRT student proficiency assessment for five subjects.",
    )

    def repo():
        return repository if repository is not None else default_repository()

    @app.get("/health")
    def health():
        try:
            repo().health()
            return {"status": "ok"}
        except Exception:
            raise HTTPException(status_code=503, detail="Database unavailable")

    @app.get("/v1/subjects", dependencies=[Depends(api_auth)])
    def subjects():
        return [{"subject": subject.value, "topics": list(SUBJECT_TOPICS[subject])} for subject in Subject]

    @app.post("/v1/students", status_code=201, dependencies=[Depends(api_auth)])
    def create_student(payload: StudentCreate):
        record = new_student_record(**payload.model_dump())
        try:
            return repo().create_student(record)
        except Exception as exc:
            if exc.__class__.__name__ == "StorageConflict":
                raise HTTPException(409, str(exc)) from exc
            raise

    @app.post("/v1/admin/items", status_code=201, dependencies=[Depends(admin_auth)])
    def create_item(payload: ItemCreate):
        record = new_item_record(payload.model_dump())
        try:
            repo().create_item(record)
        except Exception as exc:
            if exc.__class__.__name__ == "StorageConflict":
                raise HTTPException(409, str(exc)) from exc
            raise
        return {"item_id": record["item_id"], "subject": record["subject"],
                "topic": record["topic"], "parameter_status": "expert_provisional"}

    @app.get("/v1/next-item", dependencies=[Depends(api_auth)])
    def next_item(student_id: str = Query(min_length=1), subject: Subject = Query(...)):
        database = repo()
        if database.get_student(student_id) is None:
            raise HTTPException(404, "Student not found")
        item = select_next_item(database, student_id, subject.value)
        if item is None:
            return {"status": "no_unanswered_items", "subject": subject.value, "item": None}
        return {"status": "ready", "subject": subject.value, "item": item}

    @app.post("/v1/responses", status_code=201, dependencies=[Depends(api_auth)])
    def submit_response(payload: StudentResponseCreate):
        database = repo()
        if database.get_student(payload.student_id) is None:
            raise HTTPException(404, "Student not found")
        item = database.get_item(payload.item_id)
        if item is None:
            raise HTTPException(404, "Assessment item not found")
        if payload.selected_index >= len(item["choices"]):
            raise HTTPException(422, "selected_index outside available options")
        data = new_response_record(payload.student_id, item, payload.selected_index)
        try:
            database.create_response(data)
        except Exception as exc:
            if exc.__class__.__name__ == "StorageConflict":
                raise HTTPException(409, "Item was already answered by this student") from exc
            raise
        report = assessment_report(database, payload.student_id, persist=True)
        subject_data = next(r for r in report["subjects"] if r["subject"] == item["subject"])
        return {
            "response_id": data["response_id"], "item_id": payload.item_id,
            "student_id": payload.student_id, "is_correct": data["is_correct"],
            "subject": item["subject"],
            "subject_ability_index_pct": subject_data["ability_index_pct"],
            "subject_evidence_status": subject_data["evidence_status"],
            "message": "Score is provisional and should not be used for high-stakes placement.",
        }

    @app.get("/v1/students/{student_id}/report", dependencies=[Depends(api_auth)])
    def student_report(student_id: str):
        database = repo()
        if database.get_student(student_id) is None:
            raise HTTPException(404, "Student not found")
        return assessment_report(database, student_id, persist=True)

    @app.post("/v1/admin/calibrate/{subject}", dependencies=[Depends(admin_auth)])
    def recalibrate(subject: Subject):
        return calibrate_subject(repo(), subject.value)

    return app


app = create_app()
