"""PyMongo repository. Stable UUID strings are used in both database flavors."""
from __future__ import annotations
from typing import Any

class StorageConflict(Exception):
    pass

class MongoRepository:
    def __init__(self, uri: str | None = None, db_name: str = "student_ability", client: Any = None):
        if client is None:
            from pymongo import MongoClient
            if not uri:
                raise ValueError("MongoDB URI is required")
            client = MongoClient(uri, serverSelectionTimeoutMS=5000)
        self.client = client
        self.db = self.client[db_name]
        self.db.students.create_index("student_id", unique=True)
        self.db.students.create_index("external_ref", sparse=True)
        self.db.items.create_index("item_id", unique=True)
        self.db.items.create_index([("subject", 1), ("topic", 1)])
        self.db.responses.create_index("response_id", unique=True)
        self.db.responses.create_index([("student_id", 1), ("item_id", 1)], unique=True)
        self.db.responses.create_index([("student_id", 1), ("answered_at", 1)])
        self.db.scores.create_index([("student_id", 1), ("subject", 1), ("topic", 1)], unique=True)

    @staticmethod
    def clean(doc):
        if doc is None:
            return None
        result = dict(doc)
        result.pop("_id", None)
        return result

    def health(self):
        self.db.command("ping")

    def create_student(self, data: dict) -> dict:
        from pymongo.errors import DuplicateKeyError
        try:
            self.db.students.insert_one(dict(data))
        except DuplicateKeyError as e:
            raise StorageConflict("Student already exists") from e
        return data

    def get_student(self, student_id: str) -> dict | None:
        return self.clean(self.db.students.find_one({"student_id": student_id}))

    def create_item(self, data: dict) -> dict:
        from pymongo.errors import DuplicateKeyError
        try:
            self.db.items.insert_one(dict(data))
        except DuplicateKeyError as e:
            raise StorageConflict("Item already exists") from e
        return data

    def get_item(self, item_id: str) -> dict | None:
        return self.clean(self.db.items.find_one({"item_id": item_id}))

    def list_items(self, subject: str | None = None) -> list[dict]:
        return [self.clean(d) for d in self.db.items.find({"subject": subject} if subject else {})]

    def list_items_by_ids(self, item_ids: list[str]) -> list[dict]:
        return [self.clean(d) for d in self.db.items.find({"item_id": {"$in": item_ids}})]

    def create_response(self, data: dict) -> dict:
        from pymongo.errors import DuplicateKeyError
        try:
            self.db.responses.insert_one(dict(data))
        except DuplicateKeyError as e:
            raise StorageConflict("Response already exists for this student and item") from e
        return data

    def list_student_responses(self, student_id: str) -> list[dict]:
        return [self.clean(d) for d in self.db.responses.find({"student_id": student_id}).sort("answered_at", 1)]

    def list_responses_for_subject(self, subject: str) -> list[dict]:
        ids = [d["item_id"] for d in self.db.items.find({"subject": subject}, {"item_id": 1, "_id": 0})]
        if not ids:
            return []
        return [self.clean(d) for d in self.db.responses.find({"item_id": {"$in": ids}})]

    def update_item_parameters(self, item_id: str, a: float, b: float, n: int, now: str):
        self.db.items.update_one({"item_id": item_id}, {
            "$set": {"discrimination": a, "difficulty": b, "calibration_n": n, "calibrated_at": now},
            "$inc": {"parameter_version": 1},
        })

    def upsert_scores(self, snapshots: list[dict]):
        for data in snapshots:
            self.db.scores.update_one(
                {"student_id": data["student_id"], "subject": data["subject"], "topic": data["topic"]},
                {"$set": dict(data)}, upsert=True,
            )

    def list_scores(self, student_id: str) -> list[dict]:
        return [self.clean(d) for d in self.db.scores.find({"student_id": student_id})]
