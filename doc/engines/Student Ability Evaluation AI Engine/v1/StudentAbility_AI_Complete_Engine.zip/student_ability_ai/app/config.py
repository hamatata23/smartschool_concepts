"""Runtime environment configuration. No hard-coded secret is used by the API."""
import os
from dotenv import load_dotenv
load_dotenv()


def make_repository():
    backend = os.environ.get("DB_BACKEND", "mysql").strip().lower()
    if backend == "mysql":
        from app.mysql_store import MySQLRepository
        uri = os.environ.get("MYSQL_URL")
        if not uri:
            raise RuntimeError("MYSQL_URL is required when DB_BACKEND=mysql")
        return MySQLRepository(uri)
    if backend == "mongodb":
        from app.mongo_store import MongoRepository
        uri = os.environ.get("MONGO_URI")
        db = os.environ.get("MONGO_DB", "student_ability")
        if not uri:
            raise RuntimeError("MONGO_URI is required when DB_BACKEND=mongodb")
        return MongoRepository(uri=uri, db_name=db)
    raise RuntimeError("DB_BACKEND must be 'mysql' or 'mongodb'")
