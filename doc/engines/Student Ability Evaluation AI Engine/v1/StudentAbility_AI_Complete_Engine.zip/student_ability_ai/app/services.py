"""Reusable assessment service, independent of the chosen database."""
from __future__ import annotations
from collections import Counter
from datetime import datetime, timezone
from uuid import uuid4
from app.irt import estimate_ability, evidence_status, item_information
from app.schemas import Subject, SUBJECT_TOPICS

MODEL_VERSION = "2PL-MAP-v1"


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def new_student_record(external_ref=None, grade_level=None):
    return {
        "student_id": str(uuid4()), "external_ref": external_ref,
        "grade_level": grade_level, "created_at": now_utc(),
    }


def new_item_record(payload: dict, item_id: str | None = None):
    subject = payload["subject"]
    if isinstance(subject, Subject):
        subject = subject.value
    return {
        "item_id": item_id or str(uuid4()),
        "subject": subject,
        "topic": payload["topic"],
        "question_text": payload["question_text"],
        "choices": list(payload["choices"]),
        "correct_index": payload["correct_index"],
        "difficulty": float(payload["difficulty"]),
        "discrimination": float(payload["discrimination"]),
        "initial_difficulty": float(payload["difficulty"]),
        "initial_discrimination": float(payload["discrimination"]),
        "parameter_version": 0,
        "calibration_n": 0,
        "calibrated_at": None,
        "created_at": now_utc(),
    }


def public_item(item: dict) -> dict:
    """Never expose answer keys or IRT item parameters to the student client."""
    return {
        "item_id": item["item_id"], "subject": item["subject"],
        "topic": item["topic"], "question_text": item["question_text"],
        "choices": list(item["choices"]),
    }


def new_response_record(student_id: str, item: dict, selected_index: int) -> dict:
    return {
        "response_id": str(uuid4()), "student_id": student_id,
        "item_id": item["item_id"], "selected_index": selected_index,
        "is_correct": selected_index == item["correct_index"],
        "answered_at": now_utc(),
    }


def _evidence(records: list[dict], item_by_id: dict[str, dict]):
    return [(
        float(item_by_id[r["item_id"]]["discrimination"]),
        float(item_by_id[r["item_id"]]["difficulty"]),
        int(r["is_correct"]),
    ) for r in records if r["item_id"] in item_by_id]


def _topic_result(topic: str, subject: str, records: list[dict], item_by_id: dict):
    values = _evidence(records, item_by_id)
    result = estimate_ability(values)
    result.update({
        "topic": topic,
        "evidence_status": evidence_status(len(values), 1) if len(values) < 10 else "exploratory_topic",
        "provisional_item_count": sum(item_by_id[r["item_id"]]["parameter_version"] == 0
                                       for r in records if r["item_id"] in item_by_id),
    })
    # Unlike subject-wide coverage, a topic is inherently a single domain.
    if 0 < len(values) < 5:
        result["evidence_status"] = "limited_evidence"
    elif len(values) >= 5:
        result["evidence_status"] = "exploratory_topic"
    return result


def build_subject_report(subject: str, student_records: list[dict], item_by_id: dict) -> dict:
    records = [r for r in student_records if r["item_id"] in item_by_id
               and item_by_id[r["item_id"]]["subject"] == subject]
    evidence = _evidence(records, item_by_id)
    counts = Counter(item_by_id[r["item_id"]]["topic"] for r in records)
    result = estimate_ability(evidence)
    result.update({
        "subject": subject,
        "evidence_status": evidence_status(len(evidence), sum(v > 0 for v in counts.values())),
        "provisional_item_count": sum(item_by_id[r["item_id"]]["parameter_version"] == 0
                                       for r in records),
        "topics": [
            _topic_result(topic, subject, [r for r in records if item_by_id[r["item_id"]]["topic"] == topic], item_by_id)
            for topic in SUBJECT_TOPICS[Subject(subject)]
        ],
    })
    # Unassessed topics come first; only topics with data are ranked by the reference index.
    result["recommended_topics_to_assess"] = [t["topic"] for t in sorted(
        result["topics"],
        key=lambda t: (t["response_count"] >= 3, t["ability_index_pct"] if t["ability_index_pct"] is not None else -1,
                       t["response_count"], t["topic"]),
    )]
    return result


def assessment_report(repo, student_id: str, persist: bool = True) -> dict:
    student_records = repo.list_student_responses(student_id)
    item_by_id = {i["item_id"]: i for i in repo.list_items_by_ids(
        list({r["item_id"] for r in student_records})
    )}
    subject_reports = [build_subject_report(subject.value, student_records, item_by_id)
                       for subject in Subject]
    result = {
        "student_id": student_id, "model_version": MODEL_VERSION,
        "index_definition": "100 * sigmoid(theta), for a reference item with a=1 and b=0; not an exam grade or percentile",
        "uncertainty": "Approximate 95% Laplace posterior intervals; subject/item calibration not externally validated",
        "subjects": subject_reports,
    }
    if persist:
        snapshots = []
        timestamp = now_utc()
        for report in subject_reports:
            for t in [report] + report["topics"]:
                snapshots.append({
                    "student_id": student_id, "subject": report["subject"],
                    "topic": t.get("topic", ""), "theta": t["theta"],
                    "standard_error": t["standard_error"],
                    "ability_index_pct": t["ability_index_pct"],
                    "response_count": t["response_count"],
                    "evidence_status": t["evidence_status"],
                    "model_version": MODEL_VERSION, "updated_at": timestamp,
                })
        repo.upsert_scores(snapshots)
    return result


def select_next_item(repo, student_id: str, subject: str) -> dict | None:
    all_items = repo.list_items(subject)
    responses = repo.list_student_responses(student_id)
    taken = {r["item_id"] for r in responses}
    unseen = [item for item in all_items if item["item_id"] not in taken]
    if not unseen:
        return None
    already = repo.list_items_by_ids([r["item_id"] for r in responses])
    item_by_id = {i["item_id"]: i for i in already}
    subject_responses = [r for r in responses if r["item_id"] in item_by_id
                         and item_by_id[r["item_id"]]["subject"] == subject]
    theta = estimate_ability(_evidence(subject_responses, item_by_id))["theta"] or 0.0
    counts = Counter(item_by_id[r["item_id"]]["topic"] for r in subject_responses)
    minimum = min(counts.get(item["topic"], 0) for item in unseen)
    candidates = [item for item in unseen if counts.get(item["topic"], 0) == minimum]
    chosen = sorted(candidates, key=lambda item: (
        -item_information(theta, item["discrimination"], item["difficulty"]),
        item["item_id"],
    ))[0]
    return public_item(chosen)
