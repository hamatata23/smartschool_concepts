"""Public request schemas and the v1 subject-topic taxonomy."""
from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field, model_validator

class Subject(str, Enum):
    MATHS = "Maths"
    PHYSICS = "Physics"
    ENGLISH = "English"
    CHEMISTRY = "Chemistry"
    BIOLOGY = "Biology"

SUBJECT_TOPICS = {
    Subject.MATHS: ("Algebra", "Geometry", "Statistics"),
    Subject.PHYSICS: ("Mechanics", "Electricity", "Waves"),
    Subject.ENGLISH: ("Grammar", "Vocabulary", "Reading"),
    Subject.CHEMISTRY: ("Atomic Structure", "Stoichiometry", "Acids and Bases"),
    Subject.BIOLOGY: ("Cell Biology", "Genetics", "Ecology"),
}

class StudentCreate(BaseModel):
    external_ref: Optional[str] = Field(default=None, min_length=1, max_length=128)
    grade_level: Optional[int] = Field(default=None, ge=1, le=13)

class ItemCreate(BaseModel):
    subject: Subject
    topic: str = Field(min_length=2, max_length=100)
    question_text: str = Field(min_length=5, max_length=3000)
    choices: list[str] = Field(min_length=2, max_length=6)
    correct_index: int = Field(ge=0)
    difficulty: float = Field(default=0.0, ge=-2.5, le=2.5)
    discrimination: float = Field(default=1.0, ge=0.4, le=2.5)

    @model_validator(mode="after")
    def validate_question(self):
        if self.topic not in SUBJECT_TOPICS[self.subject]:
            raise ValueError(f"Topic must be one of {SUBJECT_TOPICS[self.subject]}")
        if self.correct_index >= len(self.choices):
            raise ValueError("correct_index is outside the choices list")
        if any(not choice.strip() for choice in self.choices):
            raise ValueError("All answer choices must be nonempty")
        if len(set(x.strip() for x in self.choices)) != len(self.choices):
            raise ValueError("Answer choices must be distinct")
        return self

class StudentResponseCreate(BaseModel):
    student_id: str = Field(min_length=1, max_length=64)
    item_id: str = Field(min_length=1, max_length=64)
    selected_index: int = Field(ge=0)
