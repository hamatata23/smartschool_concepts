"""60 hand-authored MCQs and optional synthetic students for development only.

Run: python -m app.seed          # question bank
     python -m app.seed --demo   # plus five simulated students and answers
"""
from __future__ import annotations
import argparse
import random
from collections import Counter
from uuid import uuid5, NAMESPACE_DNS
from app.config import make_repository
from app.schemas import ItemCreate, Subject
from app.services import new_item_record, new_response_record, now_utc
from app.irt import response_probability

# Entry structure: question text, list of answer choices, index of answer.
BANK = {
    "Maths": {
        "Algebra": [
            ("Solve 2x + 3 = 11.", ["2", "3", "4", "5"], 2),
            ("Factor x^2 - 9.", ["(x-3)(x+3)", "(x-9)(x+1)", "(x-3)^2", "(x+9)(x-1)"], 0),
            ("What is the slope between (1,2) and (3,6)?", ["1", "2", "3", "4"], 1),
            ("If f(x) = 3x - 4, find f(5).", ["9", "11", "13", "15"], 1),
        ],
        "Geometry": [
            ("A triangle has two angles of 50 and 60 degrees. Find the third.", ["60", "65", "70", "80"], 2),
            ("Find the area of a rectangle 6 cm long and 4 cm wide.", ["10 cm^2", "20 cm^2", "24 cm^2", "28 cm^2"], 2),
            ("Find the circumference of a circle with radius 3 cm.", ["3 pi cm", "6 pi cm", "9 pi cm", "12 pi cm"], 1),
            ("A right triangle has legs 5 cm and 12 cm. Find the hypotenuse.", ["12 cm", "13 cm", "14 cm", "17 cm"], 1),
        ],
        "Statistics": [
            ("Find the mean of 2, 4, 6, 8.", ["4", "5", "6", "7"], 1),
            ("Find the median of 2, 7, 9.", ["2", "5", "7", "9"], 2),
            ("What is the probability of heads on a fair coin toss?", ["1/4", "1/2", "2/3", "1"], 1),
            ("Find the mode of 1, 2, 2, 3.", ["1", "2", "2.5", "3"], 1),
        ],
    },
    "Physics": {
        "Mechanics": [
            ("A 3 kg body accelerates at 4 m/s^2. Find net force.", ["7 N", "9 N", "12 N", "15 N"], 2),
            ("An object covers 100 m in 20 s at constant speed. Find speed.", ["2 m/s", "4 m/s", "5 m/s", "10 m/s"], 2),
            ("Find kinetic energy of a 2 kg object moving at 3 m/s.", ["3 J", "6 J", "9 J", "18 J"], 2),
            ("Velocity rises from 2 to 10 m/s in 4 s. Find acceleration.", ["1 m/s^2", "2 m/s^2", "3 m/s^2", "4 m/s^2"], 1),
        ],
        "Electricity": [
            ("A 4-ohm resistor carries 2 A. Find voltage.", ["2 V", "6 V", "8 V", "12 V"], 2),
            ("Which quantity is the same through ideal components in series?", ["Voltage", "Current", "Resistance", "Power"], 1),
            ("What current flows through 3 ohms connected across 6 V?", ["1 A", "2 A", "3 A", "18 A"], 1),
            ("An appliance operates at 12 V and 2 A. Find power.", ["6 W", "12 W", "14 W", "24 W"], 3),
        ],
        "Waves": [
            ("A wave has a period of 0.02 s. Find its frequency.", ["20 Hz", "40 Hz", "50 Hz", "100 Hz"], 2),
            ("Sound waves require which of the following to propagate?", ["A material medium", "A vacuum only", "Light", "A magnetic pole"], 0),
            ("Wave speed is 300 m/s and frequency is 100 Hz. Find wavelength.", ["1 m", "2 m", "3 m", "30 m"], 2),
            ("Which wave property relates most directly to sound loudness?", ["Frequency", "Wavelength", "Amplitude", "Period"], 2),
        ],
    },
    "English": {
        "Grammar": [
            ("Choose the grammatically correct sentence.", ["She go to school every day.", "She goes to school every day.", "She going to school every day.", "She gone to school every day."], 1),
            ("Complete: They ___ playing yesterday afternoon.", ["was", "is", "were", "be"], 2),
            ("Choose the correct sentence for standard written English.", ["He and me went home.", "Him and I went home.", "Me and him went home.", "He and I went home."], 3),
            ("Complete: If I ___ more time, I would read more.", ["have", "had", "has", "having"], 1),
        ],
        "Vocabulary": [
            ("Which word most closely means 'benevolent'?", ["Kind", "Cruel", "Careless", "Hostile"], 0),
            ("What does 'scarce' mean?", ["Very noisy", "Limited in supply", "Easily broken", "Extremely large"], 1),
            ("Which word is closest in meaning to 'reluctant'?", ["Eager", "Unwilling", "Proud", "Rapid"], 1),
            ("What does 'accurate' mean?", ["Exact or correct", "Difficult to see", "Very expensive", "Quick to change"], 0),
        ],
        "Reading": [
            ("Maya planted seeds on Monday. By Friday, small leaves appeared. What appeared on Friday?", ["Flowers", "Roots", "Small leaves", "Fruit"], 2),
            ("The library closed early because the storm intensified. Why did it close early?", ["A holiday", "The worsening storm", "A scheduled meeting", "A broken clock"], 1),
            ("After studying the map, Leo chose the shortest route. What route did Leo choose?", ["The longest route", "The coastal route", "No route", "The shortest route"], 3),
            ("Although it rained, the match continued. What happened?", ["The match continued despite rain", "The match was cancelled", "It did not rain", "No match was planned"], 0),
        ],
    },
    "Chemistry": {
        "Atomic Structure": [
            ("What is the electric charge of a proton?", ["Negative", "Positive", "Neutral", "Variable"], 1),
            ("An element's atomic number equals its number of what?", ["Neutrons", "Electrons plus neutrons", "Protons", "Molecules"], 2),
            ("How many protons are in a carbon atom (atomic number 6)?", ["4", "6", "8", "12"], 1),
            ("An atom becomes a negative ion when it does what?", ["Gains electrons", "Loses electrons", "Gains protons", "Loses neutrons"], 0),
        ],
        "Stoichiometry": [
            ("What is the approximate molar mass of water (H2O)?", ["16 g/mol", "17 g/mol", "18 g/mol", "20 g/mol"], 2),
            ("In 2 H2 + O2 -> 2 H2O, what is the coefficient of O2?", ["1", "2", "3", "4"], 0),
            ("One mole contains approximately how many entities?", ["6.02 x 10^6", "6.02 x 10^12", "6.02 x 10^23", "6.02 x 10^30"], 2),
            ("What is the mass of 0.5 mol of CO2 (44 g/mol)?", ["11 g", "22 g", "44 g", "88 g"], 1),
        ],
        "Acids and Bases": [
            ("At 25 C, which pH is acidic in an aqueous solution?", ["3", "7", "9", "12"], 0),
            ("A typical acid-base neutralization produces what?", ["Only oxygen", "Salt and water", "Only carbon dioxide", "Only hydrogen"], 1),
            ("What happens to blue litmus paper in an acidic solution?", ["It turns red", "It turns green", "It turns yellow", "It remains blue"], 0),
            ("How many times greater is [H+] at pH 3 than at pH 5?", ["2 times", "10 times", "20 times", "100 times"], 3),
        ],
    },
    "Biology": {
        "Cell Biology": [
            ("Which organelle is a major site of ATP production in eukaryotic cells?", ["Ribosome", "Mitochondrion", "Golgi apparatus", "Nucleolus"], 1),
            ("Which organelle is the main site of photosynthesis in plant cells?", ["Chloroplast", "Mitochondrion", "Lysosome", "Centrosome"], 0),
            ("What primarily regulates substance movement into and out of a cell?", ["Cell membrane", "Chromosome", "Nucleolus", "Ribosome"], 0),
            ("Where is most genomic DNA found in a typical eukaryotic cell?", ["Ribosomes", "Golgi bodies", "Nucleus", "Cell wall"], 2),
        ],
        "Genetics": [
            ("Which genotype is heterozygous?", ["AA", "Aa", "aa", "AA or aa"], 1),
            ("Which base pairs with adenine in DNA?", ["Cytosine", "Guanine", "Thymine", "Uracil"], 2),
            ("Which process generally halves chromosome number to produce gametes?", ["Mitosis", "Translation", "Meiosis", "Binary fission"], 2),
            ("What is an allele?", ["A cell organelle", "A variant of a gene", "A type of tissue", "An energy molecule"], 1),
        ],
        "Ecology": [
            ("Which organism is typically a producer in a terrestrial food chain?", ["Rabbit", "Fox", "Grass", "Fungus"], 2),
            ("Which sequence represents a plausible simple food chain?", ["Grass -> rabbit -> fox", "Fox -> grass -> rabbit", "Rabbit -> sunlight -> grass", "Fox -> sunlight -> rabbit"], 0),
            ("Which organism is commonly a decomposer?", ["Eagle", "Grass", "Deer", "Fungus"], 3),
            ("In mutualism, what happens to the interacting organisms?", ["Both benefit", "Both are harmed", "One always dies", "Neither is affected"], 0),
        ],
    },
}


def seed_items(repo) -> Counter:
    created = Counter()
    for subject, topics in BANK.items():
        for topic, questions in topics.items():
            for position, (stem, choices, answer) in enumerate(questions):
                identity = str(uuid5(NAMESPACE_DNS, f"studentability-demo-2026:{subject}:{topic}:{position}"))
                if repo.get_item(identity) is not None:
                    continue
                item_in = ItemCreate(
                    subject=Subject(subject), topic=topic, question_text=stem,
                    choices=choices, correct_index=answer,
                    difficulty=[-0.8, -0.25, 0.4, 1.0][position],
                    discrimination=[0.8, 1.0, 1.1, 1.3][position],
                )
                item = new_item_record(item_in.model_dump(), item_id=identity)
                repo.create_item(item)
                created[subject] += 1
    return created


def seed_demo_students(repo):
    """Synthetic responses for API exploration ONLY; never use to validate psychometrics."""
    profiles = [
        ("demo-learner-001", [1.2, 0.7, -0.5, 0.2, 0.1]),
        ("demo-learner-002", [-0.9, -0.4, 1.4, -0.7, 0.5]),
        ("demo-learner-003", [0.1, 0.7, -0.2, 1.1, 1.0]),
        ("demo-learner-004", [0.6, 0.0, 1.1, 0.5, -0.5]),
        ("demo-learner-005", [-0.1, -0.6, 0.2, 1.0, 1.4]),
    ]
    rng = random.Random(20261014)
    all_items = sorted(repo.list_items(), key=lambda x: x["item_id"])
    for learner, abilities in profiles:
        student_id = str(uuid5(NAMESPACE_DNS, f"studentability-demo-2026:{learner}"))
        if repo.get_student(student_id) is None:
            repo.create_student({"student_id": student_id, "external_ref": learner,
                                 "grade_level": 10, "created_at": now_utc()})
        done = {r["item_id"] for r in repo.list_student_responses(student_id)}
        for item in all_items:
            if item["item_id"] in done:
                continue
            theta = abilities[list(BANK.keys()).index(item["subject"])]
            correct = rng.random() < response_probability(theta, item["discrimination"], item["difficulty"])
            if correct:
                chosen = item["correct_index"]
            else:
                chosen = rng.choice([x for x in range(len(item["choices"])) if x != item["correct_index"]])
            repo.create_response(new_response_record(student_id, item, chosen))
    return [{"external_ref": name, "student_id": str(uuid5(NAMESPACE_DNS, f"studentability-demo-2026:{name}"))}
            for name, _ in profiles]


def main():
    parser = argparse.ArgumentParser(description="Initialize sample question bank")
    parser.add_argument("--demo", action="store_true", help="Also generate synthetic learners")
    args = parser.parse_args()
    repo = make_repository()
    print("New question counts:", dict(seed_items(repo)))
    if args.demo:
        print("Synthetic learners:")
        for student in seed_demo_students(repo):
            print(student)
    print("WARNING: example items have unvalidated difficulty and discrimination parameters.")

if __name__ == "__main__":
    main()
