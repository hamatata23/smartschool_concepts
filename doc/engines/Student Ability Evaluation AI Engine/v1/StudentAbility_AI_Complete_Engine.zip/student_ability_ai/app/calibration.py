"""Conservative optional offline calibration for illustration.

Not full IRT MML/EM. Requires independent learners, leave-item-out ability,
a regularization anchor and deterministic held-out validation. Human review and
formal psychometric validation remain necessary before production use.
"""
from __future__ import annotations
from collections import defaultdict
from hashlib import sha256
import numpy as np
from scipy.optimize import minimize
from app.irt import estimate_ability
from app.services import now_utc

MIN_ELIGIBLE = 100
MIN_OTHER_ITEMS = 4


def _mean_logloss(theta, y, a: float, b: float) -> float:
    z = a * (theta - b)
    return float(np.mean(np.logaddexp(0.0, z) - y * z))


def calibrate_subject(repo, subject: str) -> dict:
    items = repo.list_items(subject)
    item_by_id = {x["item_id"]: x for x in items}
    responses = repo.list_responses_for_subject(subject)
    by_student = defaultdict(list)
    by_item = defaultdict(list)
    for response in responses:
        if response["item_id"] not in item_by_id:
            continue
        by_student[response["student_id"]].append(response)
        by_item[response["item_id"]].append(response)

    proposals = []
    outcomes = []
    for item in items:
        item_id = item["item_id"]
        examples = []
        if len(by_item[item_id]) < MIN_ELIGIBLE:
            outcomes.append({"item_id": item_id, "status": "skipped_insufficient_responses",
                             "response_count": len(by_item[item_id])})
            continue
        for response in by_item[item_id]:
            others = [r for r in by_student[response["student_id"]] if r["item_id"] != item_id]
            if len(others) < MIN_OTHER_ITEMS:
                continue
            theta = estimate_ability([
                (item_by_id[r["item_id"]]["discrimination"],
                 item_by_id[r["item_id"]]["difficulty"], int(r["is_correct"]))
                for r in others
            ])["theta"]
            digest = sha256(f"{response['student_id']}:{item_id}".encode()).digest()
            validation = digest[0] % 5 == 0
            examples.append((float(theta), float(response["is_correct"]), validation))

        if len(examples) < MIN_ELIGIBLE:
            outcomes.append({"item_id": item_id, "status": "skipped_insufficient_independent_evidence",
                             "response_count": len(examples)})
            continue
        train = [(t, y) for t, y, validation in examples if not validation]
        valid = [(t, y) for t, y, validation in examples if validation]
        if len(train) < 60 or len(valid) < 15:
            outcomes.append({"item_id": item_id, "status": "skipped_split_too_small"})
            continue
        t_train, y_train = np.array(train, dtype=float).T
        t_valid, y_valid = np.array(valid, dtype=float).T
        if min(sum(y_train), len(y_train) - sum(y_train)) < 10:
            outcomes.append({"item_id": item_id, "status": "skipped_one_sided_answers"})
            continue
        old_a, old_b = float(item["discrimination"]), float(item["difficulty"])
        a0, b0 = float(item["initial_discrimination"]), float(item["initial_difficulty"])

        def objective(x):
            a, b = x
            z = a * (t_train - b)
            nll = np.sum(np.logaddexp(0, z) - y_train * z)
            # Anchored priors reduce changes with poorly identified item parameters.
            penalty = 6.0 * (a - a0) ** 2 + 4.0 * (b - b0) ** 2
            return float(nll + penalty)

        bounds = [(max(0.4, old_a - 0.25), min(2.5, old_a + 0.25)),
                  (max(-2.5, old_b - 0.40), min(2.5, old_b + 0.40))]
        fit = minimize(objective, x0=np.array([old_a, old_b]), method="L-BFGS-B", bounds=bounds)
        if not fit.success:
            outcomes.append({"item_id": item_id, "status": "skipped_optimizer_failed"})
            continue
        new_a, new_b = float(fit.x[0]), float(fit.x[1])
        old_loss = _mean_logloss(t_valid, y_valid, old_a, old_b)
        new_loss = _mean_logloss(t_valid, y_valid, new_a, new_b)
        if new_loss >= old_loss - 0.001:
            outcomes.append({"item_id": item_id, "status": "skipped_no_heldout_gain",
                             "heldout_logloss_before": round(old_loss, 4),
                             "heldout_logloss_after": round(new_loss, 4)})
            continue
        proposals.append((item_id, new_a, new_b, len(examples)))
        outcomes.append({"item_id": item_id, "status": "updated",
                         "eligible_responses": len(examples),
                         "old_discrimination": round(old_a, 4), "new_discrimination": round(new_a, 4),
                         "old_difficulty": round(old_b, 4), "new_difficulty": round(new_b, 4),
                         "heldout_logloss_before": round(old_loss, 4),
                         "heldout_logloss_after": round(new_loss, 4)})
    timestamp = now_utc()
    for item_id, a, b, n in proposals:
        repo.update_item_parameters(item_id, a, b, n, timestamp)
    return {
        "subject": subject, "items_examined": len(items),
        "items_updated": len(proposals), "items": outcomes,
        "warning": "Exploratory calibration only; scores and snapshots must be re-evaluated after parameter updates."
    }


def main():
    from app.config import make_repository
    from app.schemas import Subject
    import argparse
    import json
    parser = argparse.ArgumentParser(description="Offline psychometric item calibration")
    parser.add_argument("--subject", choices=[s.value for s in Subject], default=None)
    args = parser.parse_args()
    repo = make_repository()
    for subj in ([args.subject] if args.subject else [s.value for s in Subject]):
        result = calibrate_subject(repo, subj)
        print(json.dumps({"subject": subj, "items_updated": result["items_updated"],
                          "items_examined": result["items_examined"]}))

if __name__ == "__main__":
    main()
