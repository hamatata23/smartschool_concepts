"""Generate synthetic Extended JSON for a disposable MongoDB database only."""
from datetime import datetime, timedelta, timezone
import argparse
from pathlib import Path

from bson import json_util
import numpy as np


def demo_rows(now=None):
    now = (now or datetime.now(timezone.utc).replace(tzinfo=None)).replace(hour=0, minute=0, second=0, microsecond=0)
    rng = np.random.default_rng(74)
    rows = []
    for year in range(5):
        exam = now - timedelta(days=365*(5-year))
        for student in range(80):
            h, a, p, s, hw, sh = map(float, rng.uniform([1, 45, 20, 4, 30, 0], [30, 100, 95, 9, 100, 5]))
            score = float(np.clip(3+.30*h+.14*a+.45*p+1.2*s+.10*hw+1.8*sh+rng.normal(0,2),0,100))
            rows.append(dict(_id=len(rows)+1, student_id=f"DEMO-{year}-{student}", subject="mathematics",
                grade_level=8, exam_date=exam, features_as_of=exam-timedelta(days=60),
                study_hours_per_week=h, attendance_percent=a, previous_score=p,
                sleep_hours_per_night=s, assignments_completed_percent=hw, self_study_hours=sh,
                final_score=score, score_recorded_at=exam+timedelta(days=1)))
    for student in range(5):
        rows.append(dict(_id=len(rows)+1, student_id=f"DEMO-FUTURE-{student}", subject="mathematics",
            grade_level=8, exam_date=now+timedelta(days=60), features_as_of=now,
            study_hours_per_week=12+student, attendance_percent=85+student,
            previous_score=65+student, sleep_hours_per_night=7, assignments_completed_percent=80+student,
            self_study_hours=1+student*.25, final_score=None, score_recorded_at=None))
    return rows


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="demo_students.json")
    args = parser.parse_args()
    Path(args.output).write_text(json_util.dumps(demo_rows(), indent=2), encoding="utf-8")
    print(f"Created {args.output}: 400 synthetic historical documents and 5 upcoming records")
