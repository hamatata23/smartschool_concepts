# Packaging verification — 2026-10-14

**47 tests passed, with no skipped tests in the full validation run.**

- 12 regression-core tests: coefficients, least squares/gradient descent agreement,
  ridge penalty, missing values, clipping, invalid values and model serialization.
- 15 learning tests: temporal splitting, late-label purging, training-only
  preprocessing, accepted/rejected models, new/corrected/deleted results, changed
  features, missing history and upcoming-record eligibility.
- 17 MongoDB mock tests: complete publication, unchanged-run reuse, input/label
  updates, partial-stage recovery, empty batches, lease fencing, pinned readers,
  BSON IDs/Decimal128, schema checks, source validation and state persistence.
- 3 real standalone MongoDB integration tests: full training/repeat/feedback/
  completion workflow; an injected write failure after a real successful partial
  insert; and lease takeover with stale-owner publication rejected.

Environment: Python 3.12.14, PyMongo 4.18.3, mongomock 4.3.0, and temporary standalone
MongoDB 8.0.16 bound to loopback. The server was used only for verification and is
not included in the download. Install a suitably maintained MongoDB release for
your own deployment. Ordinary test runs skip the three live tests unless enabled.

The offline synthetic example trains the final model on 400 labeled documents and
predicts five upcoming records. Its validation MAE is approximately 1.62 points,
with a first example prediction near 66.19. These are generated-data checks, not
evidence of accuracy for real students.

Real MongoDB command-line smoke checks also passed: synthetic seeding, output
initialization, source checks, training, current-result reads, and unchanged-run
reuse. The temporary demo database and server were cleaned up afterward.

No connection was made to the user's database. Authentication/TLS, replica-set
failover, large datasets and a deployed systemd timer were not exercised here.
The engine's strict-source-snapshot and evaluation limits are documented in
OPERATIONS.md. A mocked driver error verifies application handling, not every
possible network/server failure sequence.
