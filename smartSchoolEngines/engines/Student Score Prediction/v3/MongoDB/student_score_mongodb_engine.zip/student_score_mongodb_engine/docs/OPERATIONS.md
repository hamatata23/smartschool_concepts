# MongoDB operation and limitations

## Prediction publication

The engine deliberately supports standalone MongoDB without multi-document
transactions. Each run writes predictions under a new random run ID, confirms
all documents were acknowledged and counts them, then atomically updates one
pipeline control document to point to that batch. Readers fetch that pointer once
and query only its run ID. Published batch records are immutable.

If insertion fails halfway, the old pointer stays current. Staged records remain
unpublished and must not be shown by your app. A later retry creates a fresh batch.
If the pointer write returns a network timeout, its outcome may be unknown: the
pointer in MongoDB is authoritative and can reference either complete batch. A
retry is safe. A successful write followed by a local report failure does not undo
the MongoDB pointer. There is no transaction spanning local model files and MongoDB.

Identical inputs and active model reuse the current batch, updating only its
last-checked time. Changed inputs or accepted models create a new batch. Completed,
deleted, out-of-scope and past/same-day exams are absent from the next current
batch. Older batches remain historical records. An empty current batch correctly
means zero upcoming forecasts; it does not mean "return all old predictions".

The unique index is `(pipeline_name, run_id, source_key)`. `_id` ObjectId, int64 and
string values are encoded with distinct type prefixes for the source key; the
native source ID is retained in the output's `source_id`. Additional unique indexes
or TTL indexes on engine-owned collections are refused. Collections must use
simple collation. This edition assumes ordinary unsharded collections.

## Concurrency and consistency

The control document also contains a finite lease with an owner token. Acquisition,
renewal and publication compare ownership atomically. A worker whose lease expires
cannot publish after another worker takes ownership. Expired workers can leave
orphan staged records, but cannot make them current. Keep worker clocks synchronized.
Leases renew at checkpoints and before each insert batch, not in a background
thread. Increase `lease_seconds` and the service timeout after measurement if
training cannot finish within the default 30-minute lease.

A local file lock prevents simultaneous use of the same model directory. Run one
scheduler host per pipeline with persistent local model files; this is not a
distributed shared-model service. Use a unique pipeline name/state directory per
database and cohort. URI/cluster changes require a fresh state directory even if
the database name is unchanged.

Source reads are ordinary projected MongoDB reads. They do not lock teachers'
records or provide a cross-document point-in-time snapshot. Inputs are refreshed
after training, but changes during or after the read can be incorporated only on
the next run. Input hashes and timestamps describe what was read. If you require
strict alignment with a single source revision, have your school app create an
immutable versioned source snapshot and train/predict against that snapshot.

The adapter uses primary reads and explicit majority read/write concerns. The
publication design prevents partial batches when used with the current-batch
reader. It is not a claim that all source reads and output writes are one transaction.

## State, freshness and retention

- `var/.../state.json`: active model plus last attempted historical-data hash.
- `var/.../models/<version>.json`: immutable accepted model and validation report.
- `var/.../last_run.json`: most recent run summary when the pipeline reached that
  reporting stage. Errors before then are visible in process/service logs.
- MongoDB control `active.last_checked_at`: latest successful source check for
  the current batch; `active.published_at`: original batch publication time.
- Output `predicted_at`: source-read completion time for that immutable batch.

Model files use JSON, temporary files, fsync and atomic rename. Version files are
saved before a result batch can reference that model. Back up both models and the
database. After a rejected retraining, the previous compatible model remains;
if deleted/corrected data must immediately cease influencing a model, stop the
pipeline and require a fresh accepted model according to your retention policy.

Failed runs leave the last complete batch available. Applications must check
freshness; "current" does not mean "updated despite a failed scheduler". The Python
reader also rejects batches belonging to an incompatible feature/task configuration.
Exit 0 can mean a rejected candidate with a compatible older model still in use;
inspect the JSON training status. Exit 1 means a failed run or no usable model.

Historical and orphan batches are not automatically deleted. Define retention
based on your audit requirements and reader lifetimes. Never delete an active
run, and do not delete a previous batch while a reader can still be holding its
run ID. TTL expiration can silently remove active results and is prohibited. For
manual cleanup, stop the scheduler and readers, retain the active batch, back up
what is required, and remove only reviewed inactive runs. Model versions likewise
accumulate; check referenced versions before removing files.

## Training and interpretation

The same student may occur in both earlier and later exam-date groups: this
evaluates forecasting future exams, including known students. It does not establish
accuracy for new schools or entirely unseen students. Keep an untouched future
cohort for independent audits. Repeated use of validation cohorts can bias results.

The evaluation report measures an earlier-date candidate on later exams. After
acceptance, production refits on all historical labels, including the validation
rows. That report estimates the recipe's generalization, not an independent test
of the exact final refit. There is no incumbent-vs-challenger gate; passing fixed
MAE and mean-baseline checks does not guarantee beating the old model on future
data. Accuracy should be monitored against newly observed actual results.

Training medians/scales come only from the earlier training subset during
validation. Actual labels must have been available before validation feature
snapshots. Honest timestamps and pre-exam measurements are essential; the engine
cannot discover every semantically leaked input or correct a falsely dated record.
Keep forecast horizons, subjects, curricula and score scales comparable.

Coefficients express fitted associations, not causal effects. In particular,
increasing `self_study_hours` in an input does not prove that assigning those hours
will produce the predicted improvement. Predictions support teacher review; they
are not automatically earned grades. No calibrated individual confidence interval
or fairness guarantee is included. This engine does not allocate study timetables.

## Capacity and extensions

The default cap is 200,000 source documents per cohort, loaded into memory. Every
run reads and hashes matching historical data so corrections/deletions are found.
This is full batch retraining, not incremental SGD or change-stream learning. Use
cohort indexes and measure runtime/memory before increasing limits. For millions
of rows, design a snapshot/change-capture pipeline with separate evaluation storage.

Runtime source access is read-only. Limit write privileges to the engine-owned
collections. Keep credentials out of source files and version control. Server
errors are reported by class/code to avoid deliberately printing URIs or row data.

## Troubleshooting

| Problem | Action |
|---|---|
| Missing collection | Create/import source documents, then run `init-output`. |
| Existing output schema rejected | Use empty engine-owned output/control collections, or review a migration. No automatic data rewrite is attempted. |
| No accepted model | Inspect `last_run.json`; ensure enough dated actual scores and historical feature values. |
| New feature always null historically | Collect genuine historical measurements before enabling it. |
| No upcoming forecasts | Check future UTC exam dates, explicit null result and recording time, and cohort filters. |
| Lease held or expired | Inspect workers and clocks. Do not bypass the lease; wait for expiry or completion. |
| Credentials or connection error | Check URI, roles, server availability and verified TLS configuration. |
| Old/extra predictions returned | Read the control pointer and filter by its exact `run_id`, or use the supplied Python reader. |
| Duplicate apparent student IDs | Check whether they refer to different exams/source documents; output preserves source IDs. |
| Batch missing records | Stop external deletion/TTL, restore the batch, and inspect retention policies. |

## Official references used

- Atomic document updates and expected-value conditions:
  https://www.mongodb.com/docs/manual/core/write-operations-atomicity/
- PyMongo transactions and read/write concerns:
  https://www.mongodb.com/docs/languages/python/pymongo-driver/current/crud/transactions/
- PyMongo unique and compound indexes:
  https://www.mongodb.com/docs/languages/python/pymongo-driver/current/indexes/
