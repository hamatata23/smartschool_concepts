// mongosh examples. Read and adapt; not an automatic migration script.
// Choose a disposable database for trying these examples.
const school = db.getSiblingDB("school_engine_demo");

// Historical record: real inputs captured before the exam, actual score afterward.
school.tbl_student_score.insertOne({
  student_id: "student-001",
  subject: "mathematics",
  grade_level: 8,
  exam_date: ISODate("2025-06-15T00:00:00Z"),
  features_as_of: ISODate("2025-04-15T00:00:00Z"),
  study_hours_per_week: 15,
  attendance_percent: 92,
  previous_score: 75,
  sleep_hours_per_night: 7.5,
  assignments_completed_percent: 90,
  self_study_hours: 2.5,
  final_score: 83,
  score_recorded_at: ISODate("2025-06-16T10:00:00Z")
});

// Upcoming record: generate a future UTC exam date when you run this example.
const now = new Date();
const examDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 60));
school.tbl_student_score.insertOne({
  student_id: "student-001",
  subject: "mathematics",
  grade_level: 8,
  exam_date: examDate,
  features_as_of: now,
  study_hours_per_week: 18,
  attendance_percent: 95,
  previous_score: 83,
  sleep_hours_per_night: 8,
  assignments_completed_percent: 93,
  self_study_hours: 3,
  final_score: null,
  score_recorded_at: null
});

// Optional source query index; created by the DB administrator, not the runtime.
school.tbl_student_score.createIndex({subject: 1, grade_level: 1, final_score: 1});

// These two records show the shape only. More dated historical examples are needed.
