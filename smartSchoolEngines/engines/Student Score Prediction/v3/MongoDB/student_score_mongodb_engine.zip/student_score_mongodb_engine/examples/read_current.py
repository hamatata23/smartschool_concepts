"""Read a single complete published prediction batch from an application."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from bson import json_util
from mongo_store import connect, read_current
from settings import load_config, load_env

if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    load_env(root/".env")
    c = load_config(root/"config.json")
    client, db = connect(c)
    try:
        print(json_util.dumps(read_current(db, c), indent=2))
    finally:
        client.close()
