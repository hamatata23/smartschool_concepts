"""Insert synthetic records only into an empty *_engine_demo source collection."""
import argparse

from demo_data import demo_rows
from mongo_store import connect
from settings import load_config, load_env

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    parser.add_argument("--env-file")
    args = parser.parse_args()
    load_env(args.env_file)
    c = load_config(args.config)
    if not c["database"].endswith("_engine_demo"):
        raise SystemExit("Demo database name must end in _engine_demo")
    client, db = connect(c)
    try:
        collection = db[c["source_collection"]]
        if collection.find_one({}) is not None:
            raise SystemExit("Refusing to seed a nonempty source collection")
        collection.insert_many(demo_rows(), ordered=True)
        print("Inserted 405 synthetic records. Do not use this database for real students.")
    finally:
        client.close()
