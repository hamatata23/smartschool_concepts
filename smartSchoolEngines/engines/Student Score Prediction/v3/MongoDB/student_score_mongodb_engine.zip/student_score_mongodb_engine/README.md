# Student score engine — MongoDB edition

Python 3.10+ • MongoDB 8.0+ • Linux • NumPy and PyMongo

Reads student features and actual exam results from **`tbl_student_score`** and
saves predictions in **`tbl_student_prediction_score`**. These names now refer to
MongoDB collections. A third small collection, **`tbl_student_prediction_runs`**,
records the current complete prediction batch and coordinates workers.

Includes configurable numeric features, `self_study_hours`, automatic supervised
retraining, time-based validation, saved model JSON, an hourly Linux schedule,
synthetic examples and tests. After installation it can run without Internet,
using MongoDB on the same server or local network. No external AI API is used.

**Teachers must provide real actual scores.** The engine learns from those
results. It never treats its predictions as training labels, and it cannot promise
that each retraining improves future accuracy.

## 1. Files

| File | Purpose |
|---|---|
| `mongo_engine.py` | Commands to initialize output, check, run and read predictions |
| `mongo_store.py` | MongoDB reads, typed IDs, leases and complete batch publication |
| `engine.py`, `learning.py` | Regression, imputation, validation, retraining decisions |
| `settings.py`, `config.example.json` | Feature list, field mapping, cohort, quality gates |
| `.env.example` | Connection URI and optional TLS CA path |
| `examples/documents.js` | Historical and upcoming MongoDB document examples |
| `examples/read_current.py` | Read the current complete batch in your application |
| `demo_data.py`, `seed_demo.py`, `example_offline.py` | Synthetic demonstration |
| `deploy/` | Hourly systemd service/timer and optional local Docker demo |
| `tests/` | Core, MongoDB mock and opt-in real MongoDB tests |
| `docs/REGRESSION.md`, `docs/OPERATIONS.md` | Theta derivation and operating details |

## 2. Install the Python project

Extract the ZIP, then on Ubuntu/Debian:

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip unzip
cd student_score_mongodb_engine
python3 --version
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
cp config.example.json config.json
cp .env.example .env
chmod 600 .env
```

Use Python 3.10 or newer. A running MongoDB server is also required. This project
supports a standalone server without requiring replica-set transactions. For a
local disposable demo, if Docker is already installed:

```bash
docker compose -f deploy/compose.demo.yaml up -d
```

That demo binds port 27017 to localhost and has no authentication. It is not a
production database configuration. For production use an authenticated deployment
and verified TLS for remote connections. The server installer is not in this ZIP.

## 3. Set your connection and configuration

Edit `.env`:

```text
MONGODB_URI=mongodb://127.0.0.1:27017/
```

Authenticated example:

```text
MONGODB_URI=mongodb://score_engine:YOUR_PASSWORD@localhost:27017/?authSource=school
```

Percent-encode special characters in URI usernames/passwords. `.env` is a literal
KEY=value file: no surrounding quotes, `export`, interpolation or inline comments.
Environment variables already set in the shell take precedence. Keep this file
private. For remote connections configure `tls=true` in the URI, plus
`MONGODB_TLS_CA_FILE` if a private CA is needed; retain certificate/hostname checks.

In `config.json`, set:

```json
"database": "school",
"source_collection": "tbl_student_score",
"prediction_collection": "tbl_student_prediction_score",
"control_collection": "tbl_student_prediction_runs"
```

Edit the existing entries, not the whole file. The default cohort filter is
mathematics, grade 8. Set `filter_equals` to the correct cohort; use `{}` only if
all source documents belong to one compatible prediction task.

`columns` maps your top-level field names. Source IDs always use MongoDB `_id`.
If your actual result field is `exam_score`, change `columns.target` from
`final_score` to `exam_score`; it must not also be a feature.

## 4. Prepare source documents

Each document represents one student, one subject/grade, one exam and one pre-exam
feature snapshot. Use a new document for each exam, retaining historical records.

| Field | Meaning |
|---|---|
| `_id` | ObjectId, int64, or a nonempty string up to 124 characters |
| `student_id` | Student identifier; not a model input |
| `subject`, `grade_level` | Cohort fields used by the default filter |
| `exam_date` | BSON Date at midnight UTC, or `YYYY-MM-DD` string |
| `features_as_of` | Date/time when the feature snapshot was available, before exam day |
| Six configured feature fields | Numeric measurements, consistently defined |
| `final_score` | Actual result; explicit `null` while unknown |
| `score_recorded_at` | When the actual result became available; explicit `null` while unknown |

Default features:

```json
"features": [
  "study_hours_per_week",
  "attendance_percent",
  "previous_score",
  "sleep_hours_per_night",
  "assignments_completed_percent",
  "self_study_hours"
]
```

Define `self_study_hours` as, for example, average daily independent study hours
over the 30 days before `features_as_of`. Use 2.5 for two and a half hours/day.
Record it in historical examples too. Do not populate old values using information
collected after the historical exam. If you have no historical measurements yet,
remove it from both `features` and `feature_ranges` until you collect them.

An omitted or null individual feature is median-imputed. All features missing in
one document, or an entirely missing training feature, is an error. Unknown actual
score is null; 0 is a real score. All six metadata fields must exist, even when
the actual score and its recording time are null.

`examples/documents.js` shows the document shapes. A pair of example documents is
not enough training data. Default minimums are 50 earlier training examples and
20 later validation examples across at least two distinct historical exam dates.

**Quick synthetic demo:** edit `database` to `school_engine_demo` in a separate
`demo_config.json` copied from the example, then run:

```bash
python seed_demo.py --config demo_config.json --env-file .env
python mongo_engine.py init-output --config demo_config.json --env-file .env
python mongo_engine.py check --config demo_config.json --env-file .env
python mongo_engine.py run-once --config demo_config.json --env-file .env
python mongo_engine.py show-current --config demo_config.json --env-file .env
```

`seed_demo.py` refuses nonempty sources and database names without `_engine_demo`.
It creates 400 synthetic historical records and five upcoming records. No real
student accuracy can be inferred from synthetic results.

## 5. Initialize, check and run on your database

Once real source documents exist and configuration is correct:

```bash
python mongo_engine.py init-output --config config.json --env-file .env
python mongo_engine.py check --config config.json --env-file .env
python mongo_engine.py run-once --config config.json --env-file .env
python mongo_engine.py show-current --config config.json --env-file .env
```

`init-output` creates engine-owned collections and required indexes. Run it with
setup privileges. It does not modify source documents or automatically migrate
incompatible existing output collections. `check` checks collections and reads
source data without training or writing predictions. `run-once` exits after work.

Database permissions: runtime needs find on the source; find/insert on predictions;
find/insert/update on control; and listCollections/listIndexes for schema checks.
Setup additionally needs createCollection/createIndex on engine-owned collections.
An administrator can create a custom role with these actions. Source writes are
reserved for your school application or teacher workflow.

## 6. Read current predictions correctly

**Use `show-current` or `mongo_store.read_current`.** The output collection contains
historical and possibly abandoned batches, not just current predictions. Never
use an unfiltered `find()` as the current student forecast list.

The equivalent mongosh read is:

```javascript
const school = db.getSiblingDB("school");
const control = school.tbl_student_prediction_runs.findOne({_id: "school_math_grade8"});
if (control && control.active) {
  const current = control.active;
  const predictions = school.tbl_student_prediction_score.find({
    pipeline_name: "school_math_grade8",
    run_id: current.run_id
  }).toArray();
  printjson({current, predictions});
}
```

The Python helper also verifies configuration compatibility and batch count.
Each output includes source ID, student ID, exam date, bounded/raw scores,
model version, input hash, validation MAE, timestamp and input warnings.
Validation MAE is a model-level statistic, not individual prediction confidence.

The manifest's `last_checked_at` reports when data was last checked successfully.
`published_at` reports when that batch first became current. Unchanged inputs and
model reuse the same batch; no hourly duplicate results are inserted.

## 7. Automatic learning

Every run hashes the historical actual scores, inputs, dates and training settings.
New, corrected and deleted historical records trigger a candidate training attempt.
Only upcoming input changes update predictions without retraining the model.

The newest 20% of distinct historical exam dates form validation. Training labels
must have been available before the earliest validation feature snapshot. The
default gate requires MAE <= 12 score points and improvement over a training-mean
baseline. Accepted recipes are refit on all historical labels. Otherwise the last
compatible accepted model is retained. A changed feature list requires a new
accepted model. There is no guarantee a passing model will beat the old model on
future exams; see `docs/OPERATIONS.md` for evaluation limits.

Your school app records real results after the exam, for example in mongosh:

```javascript
db.tbl_student_score.updateOne(
  {_id: ObjectId("PUT_THE_REAL_SOURCE_OBJECT_ID_HERE")},
  {$set: {final_score: 83, score_recorded_at: new Date()}}
);
```

Use your actual ID type/value. Preserve the pre-exam feature snapshot. The next run
reviews the new actual result for training. Do not copy `predicted_score` here.

## 8. Add more features

Populate another numeric document field with real historical measurements, append
its name to `features`, and add any valid bounds to `feature_ranges`. For example:

```json
"quiz_average": [0, 100]
```

Run `check` and `run-once` after editing. MongoDB requires no SQL ALTER TABLE.
The output schema does not change. IDs, target exam results, and measurements
available only after the exam must not be inputs. Free text and categorical labels
need deliberate preprocessing; they are not automatically encoded.

## 9. Enable hourly execution on Linux

Install at `/opt/student_score_mongodb_engine`. If moving a prepared directory,
recreate the virtual environment at its final path. From the extracted project:

```bash
sudo useradd --system --user-group --no-create-home --shell /usr/sbin/nologin scoreengine
sudo mkdir -p /opt/student_score_mongodb_engine
sudo cp -a . /opt/student_score_mongodb_engine/
cd /opt/student_score_mongodb_engine
sudo python3 -m venv --clear .venv
sudo .venv/bin/python -m pip install -r requirements.txt
sudo mkdir -p var
sudo chown -R root:scoreengine /opt/student_score_mongodb_engine
sudo chmod -R o-rwx /opt/student_score_mongodb_engine
sudo chmod 640 .env
sudo chown -R scoreengine:scoreengine var
sudo cp deploy/student-score-mongo.service deploy/student-score-mongo.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl start student-score-mongo.service
sudo systemctl enable --now student-score-mongo.timer
```

Skip `useradd` if the service account already exists. Verify `config.json`, URI,
roles and a manual run first. Keep `state_dir` under the project's `var` directory,
as allowed by the service sandbox. Make any CA certificate readable to scoreengine.

```bash
systemctl list-timers student-score-mongo.timer
sudo journalctl -u student-score-mongo.service -n 100 --no-pager
```

The timer checks hourly with up to one minute of jitter. No application HTTP port
is required. A scheduler is included; it has not been installed on your own server.

## 10. Tests and offline installation

```bash
python -m pip install -r requirements-dev.txt
python -m unittest discover -s tests -v
python example_offline.py
```

The standard suite uses mongomock for database tests, with collection-option
introspection mocked because mongomock lacks that API. Optional live tests use real
MongoDB, create randomly named test collections and drop those test collections
afterward. Use a disposable database name ending in `_engine_test`:

```bash
MONGODB_URI=mongodb://127.0.0.1:27017/ \
MONGODB_TEST_DATABASE=school_engine_test RUN_MONGODB_INTEGRATION=1 \
python -m unittest discover -s tests -v
```

See `docs/VALIDATION.md` for the actual packaging verification results.

For an offline server, download dependencies on a connected machine with the same
Python version, Linux architecture and compatible OS, then transfer the wheels:

```bash
python -m pip download --only-binary=:all: -r requirements.txt -d wheelhouse
# On the offline server, inside its venv:
python -m pip install --no-index --find-links=wheelhouse -r requirements.txt
```

Provision Python and MongoDB separately with suitable offline installation packages.
Record installed dependency versions after your own deployment checks.

## 11. Moving from the earlier MySQL project

Use this new directory and fresh model state; do not reuse the MySQL `state.json`.
Convert each source row to a document, preserving the unique row ID as `_id`, real
score/null distinction, numeric units, and UTC timestamps. Map field names in
config. Include truthful historical `self_study_hours`, or remove that feature from
both config sections for now. The source IDs may be integers, so ObjectId creation
is not mandatory.

The project conversion does not connect to or migrate your actual MySQL server.
Validate imported records with `check`, then train and read predictions through
the current-batch helper. Prediction records are regenerated from the new engine.
