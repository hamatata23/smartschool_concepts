"""Opt-in live integration. Only creates/drops randomly named test collections."""
from datetime import datetime, timedelta, timezone
import os
from pathlib import Path
import tempfile
import unittest
import uuid
from unittest.mock import patch

from pymongo.errors import AutoReconnect

from demo_data import demo_rows
from mongo_engine import run_once
import mongo_store as store
from settings import load_config

ROOT = Path(__file__).resolve().parents[1]


@unittest.skipUnless(os.environ.get("RUN_MONGODB_INTEGRATION") == "1", "Live MongoDB is opt-in")
class LiveMongoTests(unittest.TestCase):
    def setUp(self):
        self.c = load_config(ROOT/"config.example.json")
        self.c["database"] = os.environ.get("MONGODB_TEST_DATABASE", "school_engine_test")
        if not self.c["database"].endswith("_engine_test"):
            raise ValueError("Live integration requires a disposable database ending in _engine_test")
        suffix = uuid.uuid4().hex[:12]
        self.c.update(source_collection="test_scores_"+suffix,
                      prediction_collection="test_predictions_"+suffix, control_collection="test_runs_"+suffix)
        self.temp = tempfile.TemporaryDirectory()
        self.c["state_dir"] = self.temp.name
        self.client, self.db = store.connect(self.c)
        self.now = datetime.now(timezone.utc).replace(tzinfo=None, hour=12, minute=0, second=0, microsecond=0)
        self.db[self.c["source_collection"]].insert_many(demo_rows(self.now))
        store.init_output(self.db, self.c)

    def tearDown(self):
        for key in ("source_collection", "prediction_collection", "control_collection"):
            self.db.drop_collection(self.c[key])
        self.client.close()
        self.temp.cleanup()

    def test_train_repeat_feedback_completion(self):
        first = run_once(self.db, self.c, now=self.now)
        second = run_once(self.db, self.c, now=self.now)
        self.assertEqual(first["current_predictions"], 5)
        self.assertEqual(second["predictions_written"], 0)
        self.assertEqual(first["active_run_id"], second["active_run_id"])
        self.db[self.c["source_collection"]].update_one({"_id": 1}, {"$inc": {"final_score": 1}})
        third = run_once(self.db, self.c, now=self.now)
        self.assertNotEqual(first["active_model_version"], third["active_model_version"])
        self.db[self.c["source_collection"]].update_one({"_id": 401}, {
            "$set": {"final_score": 70, "score_recorded_at": self.now+timedelta(days=61)}})
        fourth = run_once(self.db, self.c, now=self.now+timedelta(days=62))
        self.assertEqual(fourth["current_predictions"], 0)
        self.assertEqual(store.read_current(self.db, self.c)["predictions"], [])

    def test_partial_write_does_not_publish(self):
        first = run_once(self.db, self.c, now=self.now)
        self.c["batch_size"] = 2
        self.db[self.c["source_collection"]].update_one({"_id": 401}, {"$set": {"self_study_hours": 4}})
        original = self.db[self.c["prediction_collection"]].__class__.insert_many
        calls = []
        def flaky(collection, documents, **kwargs):
            if collection.name == self.c["prediction_collection"]:
                calls.append(len(documents))
                if len(calls) == 2:
                    raise AutoReconnect("injected after successful first batch")
            return original(collection, documents, **kwargs)
        with patch.object(self.db[self.c["prediction_collection"]].__class__, "insert_many", new=flaky):
            with self.assertRaises(AutoReconnect): run_once(self.db, self.c, now=self.now)
        self.assertEqual(store.read_current(self.db, self.c)["active"]["run_id"], first["active_run_id"])
        recovered = run_once(self.db, self.c, now=self.now)
        self.assertNotEqual(recovered["active_run_id"], first["active_run_id"])

    def test_lease_takeover_fences_old_owner(self):
        clock = [self.now]
        a = store.Lease(self.db, self.c, lambda: clock[0]).acquire()
        with self.assertRaises(RuntimeError): store.Lease(self.db, self.c, lambda: clock[0]).acquire()
        clock[0] += timedelta(seconds=self.c["lease_seconds"]+1)
        b = store.Lease(self.db, self.c, lambda: clock[0]).acquire()
        with self.assertRaises(RuntimeError): a.publish({"run_id": "stale"})
        b.publish({"run_id": "current"})
        a.release()
        b.renew()
        b.release()
