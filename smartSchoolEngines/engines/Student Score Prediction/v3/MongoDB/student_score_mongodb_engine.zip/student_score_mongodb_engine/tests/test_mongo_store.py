import copy
from datetime import datetime, timedelta
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from bson import ObjectId
from bson.decimal128 import Decimal128
import mongomock
from pymongo.errors import AutoReconnect, DuplicateKeyError

from demo_data import demo_rows
from learning import advance_state, normalize, predict_rows
from mongo_engine import atomic_json, local_lock, run_once
import mongo_store as store
from settings import load_config, validate

ROOT = Path(__file__).resolve().parents[1]
NOW = datetime(2026, 10, 14, 12)


class MongoStoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.c = load_config(ROOT/"config.example.json")
        self.c["state_dir"] = self.temp.name
        self.db = mongomock.MongoClient()[self.c["database"]]
        self.db[self.c["source_collection"]].insert_many(demo_rows(NOW))
        # mongomock does not expose collection options; emulate simple defaults.
        self.options = patch.object(mongomock.collection.Collection, "options", return_value={}, create=True)
        self.options.start()
        self.addCleanup(self.options.stop)
        store.init_output(self.db, self.c)

    def run_pipeline(self, now=NOW):
        return run_once(self.db, self.c, now=now)

    def test_full_workflow_and_repeat_no_duplicate_batch(self):
        first = self.run_pipeline()
        second = self.run_pipeline()
        self.assertEqual(first["predictions_written"], 5)
        self.assertEqual(second["predictions_written"], 0)
        self.assertEqual(second["training"]["status"], "unchanged")
        self.assertEqual(first["active_run_id"], second["active_run_id"])
        current = store.read_current(self.db, self.c)
        self.assertEqual(len(current["predictions"]), 5)
        self.assertEqual(self.db[self.c["prediction_collection"]].count_documents({}), 5)
        self.assertEqual(current["predictions"][0]["source_id"], 401)
        self.assertEqual(current["predictions"][0]["source_key"], "int:401")

    def test_source_change_updates_prediction_without_retraining(self):
        first = self.run_pipeline()
        old = store.read_current(self.db, self.c)["predictions"][0]["predicted_score"]
        self.db[self.c["source_collection"]].update_one({"_id": 401}, {"$set": {"self_study_hours": 4}})
        second = self.run_pipeline()
        current = store.read_current(self.db, self.c)
        self.assertEqual(first["active_model_version"], second["active_model_version"])
        self.assertNotEqual(first["active_run_id"], second["active_run_id"])
        self.assertGreater(current["predictions"][0]["predicted_score"], old)

    def test_actual_result_correction_retrains(self):
        first = self.run_pipeline()
        self.db[self.c["source_collection"]].update_one({"_id": 1}, {"$inc": {"final_score": 1}})
        second = self.run_pipeline()
        self.assertNotEqual(first["active_model_version"], second["active_model_version"])

    def test_failed_staging_does_not_publish_partial_batch(self):
        first = self.run_pipeline()
        self.c["batch_size"] = 2
        self.db[self.c["source_collection"]].update_one({"_id": 401}, {"$set": {"self_study_hours": 4}})
        collection = self.db[self.c["prediction_collection"]]
        real_insert = collection.insert_many
        calls = []
        def flaky(docs, **kwargs):
            calls.append(len(docs))
            if len(calls) == 2:
                raise AutoReconnect("simulated disconnect")
            return real_insert(docs, **kwargs)
        with patch.object(collection, "insert_many", side_effect=flaky):
            with self.assertRaises(AutoReconnect): self.run_pipeline()
        current = store.read_current(self.db, self.c)
        self.assertEqual(current["active"]["run_id"], first["active_run_id"])
        self.assertEqual(len(current["predictions"]), 5)
        self.assertEqual(collection.count_documents({}), 7)  # Two orphan staged docs.
        recovered = self.run_pipeline()
        self.assertNotEqual(recovered["active_run_id"], first["active_run_id"])
        self.assertEqual(len(store.read_current(self.db, self.c)["predictions"]), 5)

    def test_empty_batch_replaces_old_current_predictions(self):
        self.run_pipeline()
        later = NOW+timedelta(days=62)
        result = self.run_pipeline(later)
        current = store.read_current(self.db, self.c)
        self.assertEqual(result["current_predictions"], 0)
        self.assertEqual(current["predictions"], [])
        self.assertEqual(self.db[self.c["prediction_collection"]].count_documents({}), 5)

    def test_expired_writer_cannot_publish_after_takeover(self):
        clock = [NOW]
        a = store.Lease(self.db, self.c, lambda: clock[0]).acquire()
        with self.assertRaises(RuntimeError):
            store.Lease(self.db, self.c, lambda: clock[0]).acquire()
        clock[0] += timedelta(seconds=self.c["lease_seconds"]+1)
        b = store.Lease(self.db, self.c, lambda: clock[0]).acquire()
        with self.assertRaises(RuntimeError): a.renew()
        with self.assertRaises(RuntimeError): a.publish({"run_id": "stale"})
        a.release()  # Must not release B's lease.
        b.publish({"run_id": "new"})
        self.assertEqual(self.db[self.c["control_collection"]].find_one({"_id": self.c["pipeline_name"]})["active"]["run_id"], "new")
        b.release()

    def test_pinned_reader_sees_one_complete_immutable_run(self):
        first = self.run_pipeline()
        pinned = self.db[self.c["control_collection"]].find_one({"_id": self.c["pipeline_name"]})["active"]
        self.db[self.c["source_collection"]].update_one({"_id": 401}, {"$set": {"self_study_hours": 4}})
        self.run_pipeline()
        rows = list(self.db[self.c["prediction_collection"]].find({"pipeline_name": self.c["pipeline_name"], "run_id": pinned["run_id"]}))
        self.assertEqual(len(rows), 5)
        self.assertTrue(all(r["run_id"] == first["active_run_id"] for r in rows))

    def test_object_id_and_typed_id_roundtrip(self):
        oid = ObjectId()
        for value in (1, "1", oid, str(oid)):
            self.assertEqual(store.decode_id(store.encode_id(value)), value)
        self.assertNotEqual(store.encode_id(1), store.encode_id("1"))
        self.assertNotEqual(store.encode_id(oid), store.encode_id(str(oid)))
        raw = demo_rows(NOW)[-1]
        raw.update(_id=oid, student_id="OBJECTID-STUDENT")
        self.db[self.c["source_collection"]].insert_one(raw)
        self.run_pipeline()
        current = store.read_current(self.db, self.c)
        result = next(r for r in current["predictions"] if r["student_id"] == "OBJECTID-STUDENT")
        self.assertEqual(result["source_id"], oid)

    def test_decimal_and_absent_feature_supported(self):
        self.db[self.c["source_collection"]].update_one({"_id": 401}, {
            "$set": {"self_study_hours": Decimal128("2.50")}, "$unset": {"sleep_hours_per_night": ""}})
        self.run_pipeline()
        first = store.read_current(self.db, self.c)["predictions"][0]
        self.assertEqual(first["warnings"]["imputed_features"], ["sleep_hours_per_night"])

    def test_no_model_no_published_batch(self):
        self.c["training"]["max_validation_mae"] = 0
        with self.assertRaises(RuntimeError): self.run_pipeline()
        self.assertIsNone(store.read_current(self.db, self.c)["active"])
        self.assertEqual(self.db[self.c["prediction_collection"]].count_documents({}), 0)

    def test_new_feature_cannot_use_incompatible_old_model(self):
        self.run_pipeline()
        self.c["features"].append("quiz_average")
        with self.assertRaises(RuntimeError): self.run_pipeline()
        stored = json.loads((Path(self.temp.name)/"state.json").read_text())
        self.assertIsNone(stored["active"])
        with self.assertRaises(ValueError): store.read_current(self.db, self.c)

    def test_invalid_data_fails_without_new_publication(self):
        first = self.run_pipeline()
        self.db[self.c["source_collection"]].update_one({"_id": 1}, {"$set": {"final_score": 500}})
        with self.assertRaises(ValueError): self.run_pipeline()
        self.assertEqual(store.read_current(self.db, self.c)["active"]["run_id"], first["active_run_id"])

    def test_nonengine_documents_are_rejected(self):
        self.db[self.c["prediction_collection"]].insert_one({"student_id": "legacy"})
        with self.assertRaises(ValueError): store.check_collections(self.db, self.c)

    def test_filter_values_cannot_be_query_operators(self):
        c = copy.deepcopy(self.c)
        c["filter_equals"]["subject"] = {"$ne": None}
        with self.assertRaises(ValueError): validate(c)
        c["filter_equals"]["subject"] = "$ne"
        query, projection = store.source_query(c)
        self.assertIn({"subject": {"$eq": "$ne"}}, query["$and"])
        self.assertNotIn("name", projection)

    def test_row_limit_is_not_silent_truncation(self):
        self.c["max_rows"] = 100
        with self.assertRaises(ValueError): store.fetch_source(self.db, self.c)

    def test_published_batch_deletion_is_detected(self):
        self.run_pipeline()
        first = store.read_current(self.db, self.c)["predictions"][0]
        self.db[self.c["prediction_collection"]].delete_one({"_id": first["_id"]})
        with self.assertRaises(RuntimeError): store.read_current(self.db, self.c)
        with self.assertRaises(RuntimeError): self.run_pipeline()

    def test_local_state_atomic_and_overlap_rejected(self):
        path = Path(self.temp.name)/"test.json"
        atomic_json(path, {"x": 1})
        self.assertEqual(json.loads(path.read_text()), {"x": 1})
        self.assertEqual(path.stat().st_mode & 0o777, 0o600)
        with local_lock(self.temp.name):
            with self.assertRaises(RuntimeError), local_lock(self.temp.name): pass


if __name__ == "__main__":
    unittest.main()
