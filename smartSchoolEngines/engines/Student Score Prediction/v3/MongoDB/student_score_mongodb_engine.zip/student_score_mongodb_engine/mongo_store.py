"""MongoDB storage, fenced leases and atomic publication of immutable result batches.

Only the manifest pointer switches atomically. Source reads are ordinary reads,
not a cross-document transaction or a point-in-time training snapshot.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timedelta
import os
import uuid

from bson import ObjectId
from bson.decimal128 import Decimal128
from pymongo import ASCENDING, MongoClient, ReadPreference
from pymongo.errors import DuplicateKeyError
from pymongo.read_concern import ReadConcern
from pymongo.write_concern import WriteConcern

from learning import digest, utcnow

FORMAT = 1
RESULT_KEY = [("pipeline_name", 1), ("run_id", 1), ("source_key", 1)]


def connect(c):
    uri = os.environ.get("MONGODB_URI")
    if not uri:
        raise ValueError("Set MONGODB_URI in the environment or --env-file")
    options = dict(serverSelectionTimeoutMS=10000, connectTimeoutMS=10000,
                   socketTimeoutMS=120000, tz_aware=False, appname="student-score-engine")
    if os.environ.get("MONGODB_TLS_CA_FILE"):
        options.update(tls=True, tlsCAFile=os.environ["MONGODB_TLS_CA_FILE"])
    client = MongoClient(uri, **options)
    try:
        client.admin.command("ping")
        # Explicit acknowledged majority writes; no URI setting may turn writes off.
        db = client.get_database(c["database"], read_preference=ReadPreference.PRIMARY,
             read_concern=ReadConcern("majority"), write_concern=WriteConcern(w="majority", wtimeout=10000))
        return client, db
    except Exception:
        client.close()
        raise


def encode_id(value):
    """Preserve BSON type: integer 1, string '1' and ObjectId are different IDs."""
    if isinstance(value, ObjectId):
        return "oid:" + str(value)
    if isinstance(value, int) and not isinstance(value, bool) and -(2**63) <= value < 2**63:
        return "int:" + str(value)
    if isinstance(value, str) and value and value == value.strip() and len(value) <= 124:
        return "str:" + value
    raise ValueError("Source _id must be ObjectId, int64, or an unpadded nonempty string of at most 124 characters")


def decode_id(key):
    prefix, sep, value = key.partition(":")
    if not sep:
        raise ValueError("Invalid stored source key")
    if prefix == "oid":
        return ObjectId(value)
    if prefix == "int":
        return int(value)
    if prefix == "str":
        return value
    raise ValueError("Invalid stored source key type")


def source_query(c, pending_only=False):
    parts = [{name: {"$eq": value}} for name, value in c["filter_equals"].items()]
    if pending_only:
        # Require an explicit null target; absent target fields are invalid data.
        parts.append({c["columns"]["target"]: {"$eq": None, "$exists": True}})
    query = {"$and": parts} if parts else {}
    names = {*c["columns"].values(), *c["features"]}
    return query, {name: 1 for name in names}


def fetch_source(db, c, pending_only=False):
    query, projection = source_query(c, pending_only)
    cursor = db[c["source_collection"]].find(query, projection).sort("_id", ASCENDING).limit(c["max_rows"]+1)
    try:
        rows = list(cursor)
    finally:
        cursor.close()
    if len(rows) > c["max_rows"]:
        raise ValueError("Source exceeds max_rows; partition the cohort or review the memory limit")
    for row in rows:
        row["_id"] = encode_id(row["_id"])
        for field in [*c["features"], c["columns"]["target"]]:
            if isinstance(row.get(field), Decimal128):
                row[field] = row[field].to_decimal()
        # MongoDB may omit a nullable input field; treat that like explicit null.
        for field in c["features"]:
            row.setdefault(field, None)
    return rows


def init_output(db, c):
    """Initialize engine-owned collections and indexes only; source is read-only."""
    existing = set(db.list_collection_names())
    for name in (c["prediction_collection"], c["control_collection"]):
        if name not in existing:
            db.create_collection(name)
    db[c["prediction_collection"]].create_index(RESULT_KEY, unique=True, name="unique_run_source")
    db[c["prediction_collection"]].create_index(
        [("pipeline_name", 1), ("run_id", 1), ("student_id", 1), ("target_date", 1)], name="student_lookup")
    check_collections(db, c)


def check_collections(db, c):
    existing = set(db.list_collection_names())
    for name in (c["source_collection"], c["prediction_collection"], c["control_collection"]):
        if name not in existing:
            raise ValueError(f"Missing collection {name}; create source data and run init-output")
    # Non-simple collations could merge distinct case-sensitive pipeline/ID values.
    for name in (c["prediction_collection"], c["control_collection"]):
        info = db[name].options()
        if info.get("collation", {}).get("locale", "simple") != "simple":
            raise ValueError("Engine-owned collections must use simple collation")
        if db[name].find_one({"engine_format": {"$ne": FORMAT}}, {"_id": 1}) is not None:
            raise ValueError(f"{name} contains documents from an incompatible schema")
        indexes = list(db[name].list_indexes())
        if name == c["prediction_collection"]:
            valid = [idx for idx in indexes if list(idx["key"].items()) == RESULT_KEY and idx.get("unique")
                     and not idx.get("sparse") and not idx.get("partialFilterExpression")
                     and idx.get("collation", {}).get("locale", "simple") == "simple"]
            if not valid:
                raise ValueError("Missing full unique index on pipeline_name, run_id, source_key; run init-output")
        for idx in indexes:
            if idx["name"] == "_id_":
                continue
            if idx.get("expireAfterSeconds") is not None:
                raise ValueError("TTL indexes are not allowed on engine-owned collections")
            if idx.get("unique") and not (name == c["prediction_collection"] and list(idx["key"].items()) == RESULT_KEY):
                raise ValueError("Unexpected UNIQUE index on an engine-owned collection")


class Lease:
    """Owner token fences late writers. No background renewal; checkpoints renew."""
    def __init__(self, db, c, clock=None):
        self.collection = db[c["control_collection"]]
        self.key = c["pipeline_name"]
        self.seconds = c["lease_seconds"]
        self.owner = str(uuid.uuid4())
        self.clock = clock or utcnow

    def acquire(self):
        now = self.clock()
        query = {"_id": self.key, "$or": [{"lease_until": {"$lte": now}}, {"lease_until": {"$exists": False}}]}
        try:
            result = self.collection.update_one(query, {"$set": {
                "engine_format": FORMAT, "lease_owner": self.owner,
                "lease_until": now+timedelta(seconds=self.seconds)}}, upsert=True)
        except DuplicateKeyError as exc:
            raise RuntimeError("Another worker holds the pipeline lease") from exc
        if not result.acknowledged:
            raise RuntimeError("Lease acquisition was not acknowledged")
        return self

    def active_filter(self, now):
        return {"_id": self.key, "lease_owner": self.owner, "lease_until": {"$gt": now}}

    def renew(self):
        now = self.clock()
        result = self.collection.update_one(self.active_filter(now),
                    {"$set": {"lease_until": now+timedelta(seconds=self.seconds)}})
        if result.matched_count != 1:
            raise RuntimeError("Pipeline lease expired or changed owner; aborting this run")

    def publish(self, active):
        now = self.clock()
        result = self.collection.update_one(self.active_filter(now), {"$set": {"active": active}})
        if result.matched_count != 1:
            raise RuntimeError("Lost pipeline lease before publication; staged batch is not current")

    def release(self):
        self.collection.update_one({"_id": self.key, "lease_owner": self.owner},
                                   {"$set": {"lease_until": self.clock()}, "$unset": {"lease_owner": ""}})


@contextmanager
def pipeline_lease(db, c, clock=None):
    lease = Lease(db, c, clock).acquire()
    try:
        yield lease
    finally:
        # Never mask a previous failure or a successful publication with a failed
        # cleanup; the finite lease expires even if release cannot reach MongoDB.
        try:
            lease.release()
        except Exception:
            pass


def publish_predictions(db, c, predictions, active, lease, captured_at):
    """Stage immutable documents; publish their complete batch with one pointer CAS."""
    fingerprint = digest({"model_version": active["version"], "inputs": [p["input_hash"] for p in predictions]})
    control = db[c["control_collection"]].find_one({"_id": c["pipeline_name"]}) or {}
    current = control.get("active")
    if current and current.get("fingerprint") == fingerprint and current["prediction_collection"] == c["prediction_collection"]:
        if db[c["prediction_collection"]].count_documents({"pipeline_name": c["pipeline_name"], "run_id": current["run_id"]}) != current["prediction_count"]:
            raise RuntimeError("Published batch was changed or deleted; restore it before continuing")
        updated = {**current, "last_checked_at": lease.clock(), "source_read_completed_at": captured_at}
        lease.renew()
        lease.publish(updated)
        return updated, False
    run_id = str(uuid.uuid4())
    collection = db[c["prediction_collection"]]
    batch = []
    for p in predictions:
        batch.append({"_id": digest([c["pipeline_name"], run_id, p["source_row_id"]]),
            "engine_format": FORMAT, "pipeline_name": c["pipeline_name"], "run_id": run_id,
            "source_key": p["source_row_id"], "source_id": decode_id(p["source_row_id"]),
            "student_id": p["student_id"], "target_date": p["target_date"],
            "predicted_score": p["predicted_score"], "raw_score": p["raw_score"],
            "model_version": active["version"], "training_rows": active["training_rows"],
            "validation_mae": active["validation_mae"], "input_hash": p["input_hash"],
            "predicted_at": captured_at,
            "warnings": {k: p[k] for k in ("clipped", "imputed_features", "outside_training_range")}})
        if len(batch) >= c["batch_size"]:
            lease.renew()
            collection.insert_many(batch, ordered=True)
            batch = []
    if batch:
        lease.renew()
        collection.insert_many(batch, ordered=True)
    lease.renew()
    count = collection.count_documents({"pipeline_name": c["pipeline_name"], "run_id": run_id})
    if count != len(predictions):
        raise RuntimeError("Staged prediction count does not match expected count")
    manifest = {"run_id": run_id, "model_version": active["version"],
        "contract_hash": active["contract_hash"],
        "prediction_collection": c["prediction_collection"], "prediction_count": count,
        "published_at": lease.clock(), "source_read_completed_at": captured_at,
        "last_checked_at": lease.clock(), "fingerprint": fingerprint,
        "training_rows": active["training_rows"], "validation_mae": active["validation_mae"]}
    lease.publish(manifest)
    return manifest, True


def read_current(db, c):
    """Pin one pointer read, then fetch its immutable batch, never a mix of runs."""
    control = db[c["control_collection"]].find_one({"_id": c["pipeline_name"]})
    if not control or not control.get("active"):
        return {"active": None, "predictions": []}
    active = control["active"]
    from learning import contract
    if active.get("contract_hash") != digest(contract(c)):
        raise ValueError("Current prediction batch belongs to a previous configuration; require a new accepted model")
    if active["prediction_collection"] != c["prediction_collection"]:
        raise ValueError("Current batch points to a different configured prediction collection")
    query = {"pipeline_name": c["pipeline_name"], "run_id": active["run_id"]}
    cursor = db[c["prediction_collection"]].find(query).sort("source_key", ASCENDING)
    try:
        rows = list(cursor)
    finally:
        cursor.close()
    if len(rows) != active["prediction_count"]:
        raise RuntimeError("Published prediction batch is incomplete; check deletion/retention policies")
    return {"active": active, "predictions": rows}
