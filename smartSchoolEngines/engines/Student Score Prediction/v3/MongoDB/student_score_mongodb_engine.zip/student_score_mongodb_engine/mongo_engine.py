"""Train from MongoDB actual results and publish complete batches of forecasts."""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import fcntl
import json
import os
from pathlib import Path
import sys
import tempfile

from bson import json_util
from pymongo.errors import PyMongoError

import mongo_store
from learning import advance_state, normalize, predict_rows, utcnow
from settings import load_config, load_env


def atomic_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temp = tempfile.mkstemp(prefix=".save-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, indent=2, allow_nan=False)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
        directory = os.open(path.parent, os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


@contextmanager
def local_lock(directory):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    with open(directory / "run.lock", "a") as stream:
        try:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError("Another process is using this state directory") from exc
        try:
            yield
        finally:
            fcntl.flock(stream, fcntl.LOCK_UN)


def run_once(db, c, force=False, now=None):
    directory = Path(c["state_dir"])
    fixed_now = now
    clock = (lambda: fixed_now) if fixed_now is not None else utcnow
    with local_lock(directory):
        mongo_store.check_collections(db, c)
        with mongo_store.pipeline_lease(db, c, clock) as lease:
            raw = mongo_store.fetch_source(db, c)
            now = clock()
            labeled, _, skipped = normalize(raw, c, now)
            path = directory / "state.json"
            previous = json.loads(path.read_text(encoding="utf-8")) if path.exists() else None
            state, report = advance_state(previous, labeled, c, force, now)
            lease.renew()
            active = state.get("active")
            if active:
                version_path = directory / "models" / (active["version"] + ".json")
                if not version_path.exists():
                    atomic_json(version_path, active)
            atomic_json(path, state)
            result = {"run_at_utc": now.isoformat(), "labeled_rows": len(labeled),
                      "skipped_past_unlabeled_rows": skipped, "training": report,
                      "active_model_version": active["version"] if active else None}
            if not active:
                atomic_json(directory / "last_run.json", {**result, "status": "no_accepted_model"})
                raise RuntimeError("No accepted model. Check state_dir/last_run.json for training requirements or validation failures")
            try:
                # Refresh upcoming inputs after training. Teachers remain free to
                # edit source records; a later edit is incorporated on the next run.
                current = mongo_store.fetch_source(db, c, pending_only=True)
                captured_at = clock()
                _, pending, _ = normalize(current, c, captured_at)
                predictions = predict_rows(pending, active, c)
                lease.renew()
                manifest, created = mongo_store.publish_predictions(db, c, predictions, active, lease, captured_at)
            except Exception:
                atomic_json(directory / "last_run.json", {**result, "status": "prediction_publication_failed_or_unknown"})
                raise
            result.update(status="ok", current_predictions=manifest["prediction_count"],
                          predictions_written=len(predictions) if created else 0,
                          new_prediction_batch=created, active_run_id=manifest["run_id"])
            atomic_json(directory / "last_run.json", result)
            return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["init-output", "check", "run-once", "show-current"])
    parser.add_argument("--config", default="config.json")
    parser.add_argument("--env-file", help="Literal KEY=value file; optional when environment is set")
    parser.add_argument("--force-retrain", action="store_true")
    args = parser.parse_args(argv)
    client = None
    try:
        load_env(args.env_file)
        c = load_config(args.config)
        client, db = mongo_store.connect(c)
        if args.command == "init-output":
            mongo_store.init_output(db, c)
            result = {"status": "ok", "prediction_collection": c["prediction_collection"]}
        elif args.command == "check":
            mongo_store.check_collections(db, c)
            labeled, pending, skipped = normalize(mongo_store.fetch_source(db, c), c)
            result = {"status": "ok", "labeled_rows": len(labeled), "future_unlabeled_rows": len(pending), "past_unlabeled_rows": skipped}
        elif args.command == "show-current":
            mongo_store.check_collections(db, c)
            result = mongo_store.read_current(db, c)
        else:
            result = run_once(db, c, args.force_retrain)
        print(json_util.dumps(result, indent=2))
        return 0
    except PyMongoError as exc:
        # URI, credential and row values can appear in driver error messages.
        print(f"ERROR: {type(exc).__name__}, code={getattr(exc, 'code', None)}; check MongoDB connectivity, roles and indexes", file=sys.stderr)
        return 1
    except (ValueError, RuntimeError, OSError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    finally:
        if client is not None:
            client.close()


if __name__ == "__main__":
    raise SystemExit(main())
