"""Create indexes on existing collections; does not delete documents."""
from __future__ import annotations
from asls.storage.mongo_store import MongoStore


def main():
    s = MongoStore()
    d = s.db
    try:
        d.sr_students.create_index('student_id', unique=True)
        d.sr_students.create_index([('class_id', 1), ('active', 1)])
        d.sr_subjects.create_index('subject_id', unique=True)
        d.sr_enrollments.create_index([('student_id', 1), ('subject_id', 1)], unique=True)
        d.sr_scores.create_index([('student_id', 1), ('subject_id', 1), ('recorded_on', 1)])
        d.sr_scores.create_index('recorded_on')
        d.sr_study_logs.create_index([('student_id', 1), ('studied_on', 1)])
        d.sr_study_logs.create_index('studied_on')
        d.sr_availability.create_index('student_id')
        d.sr_class_timetable.create_index([('class_id', 1), ('weekday', 1)])
        d.sr_assessments.create_index([('class_id', 1), ('due_on', 1)])
        d.sr_plans.create_index([('student_id', 1), ('week_start', 1)], unique=True)
        print('MongoDB indexes ready')
    finally:
        s.close()


if __name__ == '__main__':
    main()
