"""Reproducible professional DOCX whitepaper for ASLS 1.0.
Run from project root: python -m scripts.make_whitepaper
"""
from __future__ import annotations
from datetime import date
import json
from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / 'ASLS_Technical_Whitepaper.docx'
DEMO = ROOT / 'demo_output.json'
NAVY = RGBColor(21, 40, 69)
TEAL = RGBColor(6, 114, 132)
SLATE = RGBColor(70, 82, 98)
GRAY = RGBColor(105, 120, 132)
DARK = '152845'
LIGHT = 'EAF0F5'
SOFT = 'F5F8FB'


def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), fill)
    tcPr.append(shd)


def set_cell_border(cell, color='D5DFE8'):
    tcPr = cell._tc.get_or_add_tcPr()
    borders = OxmlElement('w:tcBorders')
    for edge in ['bottom']:
        el = OxmlElement('w:' + edge)
        el.set(qn('w:val'), 'single')
        el.set(qn('w:sz'), '5')
        el.set(qn('w:color'), color)
        borders.append(el)
    tcPr.append(borders)


def set_repeat_header(row):
    trPr = row._tr.get_or_add_trPr()
    elem = OxmlElement('w:tblHeader')
    elem.set(qn('w:val'), 'true')
    trPr.append(elem)


def prevent_split(row):
    trPr = row._tr.get_or_add_trPr()
    el = OxmlElement('w:cantSplit')
    trPr.append(el)


def page_number(p):
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p.add_run('ASLS 1.0   |   ')
    field = OxmlElement('w:fldSimple')
    field.set(qn('w:instr'), 'PAGE')
    p._p.append(field)


def set_styles(doc):
    sec = doc.sections[0]
    sec.top_margin = Cm(2.12)
    sec.bottom_margin = Cm(2.0)
    sec.left_margin = Cm(2.18)
    sec.right_margin = Cm(2.18)
    sec.header_distance = Cm(0.78)
    sec.footer_distance = Cm(0.82)
    styles = doc.styles
    normal = styles['Normal']
    normal.font.name = 'Liberation Sans'
    normal.font.size = Pt(9.6)
    normal.font.color.rgb = NAVY
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.13
    for style_name, size, before, after, color in [
        ('Title', 29, 0, 15, NAVY),
        ('Heading 1', 16, 13, 7, NAVY),
        ('Heading 2', 11.8, 10, 5, TEAL),
        ('Heading 3', 10.3, 8, 4, NAVY),
    ]:
        st = styles[style_name]
        st.font.name = 'Liberation Sans'
        st.font.size = Pt(size)
        st.font.color.rgb = color
        st.font.bold = True
        st.paragraph_format.space_before = Pt(before)
        st.paragraph_format.space_after = Pt(after)
        st.paragraph_format.keep_with_next = True
    formula = styles.add_style('Formula', WD_STYLE_TYPE.PARAGRAPH)
    formula.base_style = normal
    formula.font.name = 'Liberation Mono'
    formula.font.size = Pt(9.5)
    formula.font.color.rgb = NAVY
    formula.paragraph_format.left_indent = Cm(0.4)
    formula.paragraph_format.space_before = Pt(5)
    formula.paragraph_format.space_after = Pt(9)
    formula.paragraph_format.keep_together = True
    small = styles.add_style('SmallNote', WD_STYLE_TYPE.PARAGRAPH)
    small.base_style = normal
    small.font.size = Pt(8.3)
    small.font.color.rgb = GRAY
    small.paragraph_format.space_after = Pt(5)
    doc.core_properties.title = 'ASLS: Adaptive Self-Study Recommendation Engine - Technical Whitepaper'
    doc.core_properties.subject = 'Algorithm, adaptive learning, MySQL and MongoDB deployment'
    doc.core_properties.author = 'Technical Architecture'
    header = sec.header.paragraphs[0]
    header.text = 'ASLS   /   ADAPTIVE STUDENT LEARNING & STUDY SCHEDULING'
    for run in header.runs:
        run.font.size = Pt(7.4)
        run.font.color.rgb = SLATE
        run.font.bold = True
    footer = sec.footer.paragraphs[0]
    page_number(footer)
    for run in footer.runs:
        run.font.size = Pt(7.5)
        run.font.color.rgb = GRAY


def p(doc, text='', style=None, bold_head=None):
    paragraph = doc.add_paragraph(style=style)
    if bold_head and text.startswith(bold_head):
        paragraph.add_run(bold_head).bold = True
        paragraph.add_run(text[len(bold_head):])
    else:
        paragraph.add_run(text)
    return paragraph


def bullet(doc, text):
    line = doc.add_paragraph(style='List Bullet')
    line.add_run(text)
    return line


def heading(doc, title, level=1):
    return doc.add_heading(title, level=level)


def formula(doc, text):
    line = doc.add_paragraph(text, style='Formula')
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), SOFT)
    line._p.get_or_add_pPr().append(shd)
    return line


def table(doc, headers, rows, widths=None, small=False):
    obj = doc.add_table(rows=1, cols=len(headers))
    obj.alignment = WD_TABLE_ALIGNMENT.CENTER
    obj.autofit = False
    if widths:
        for col, width in zip(obj.columns, widths):
            col.width = Cm(width)
    hdr = obj.rows[0]
    set_repeat_header(hdr)
    for j, text in enumerate(headers):
        c = hdr.cells[j]
        shade(c, DARK)
        c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        c.text = str(text)
        for para in c.paragraphs:
            para.paragraph_format.space_after = Pt(0)
            for run in para.runs:
                run.font.color.rgb = RGBColor(255, 255, 255)
                run.font.bold = True
                run.font.size = Pt(8.2 if small else 8.6)
    for i, data in enumerate(rows):
        row = obj.add_row()
        prevent_split(row)
        for j, value in enumerate(data):
            cell = row.cells[j]
            cell.text = str(value)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            if i % 2:
                shade(cell, SOFT)
            set_cell_border(cell)
            for para in cell.paragraphs:
                para.paragraph_format.space_after = Pt(0)
                para.paragraph_format.space_before = Pt(1)
                for run in para.runs:
                    run.font.size = Pt(7.9 if small else 8.4)
                    if j == 0:
                        run.font.bold = True
    doc.add_paragraph().paragraph_format.space_after = Pt(0)
    return obj


def body():
    doc = Document()
    set_styles(doc)
    p(doc, 'TECHNICAL WHITEPAPER   /   VERSION 1.0   /   14 OCTOBER 2026', 'SmallNote')
    doc.add_paragraph().paragraph_format.space_after = Pt(22)
    title = doc.add_paragraph(style='Title')
    title.add_run('Adaptive Self-Study\nRecommendation Engine')
    sub = doc.add_paragraph()
    sub.add_run('A transparent, timetable-aware learning and scheduling system for students and teachers').font.size = Pt(15)
    doc.add_paragraph().paragraph_format.space_after = Pt(11)
    table(doc, ['RECOMMENDATION', 'ADAPTATION', 'IMPLEMENTATION'], [[
        'Mastery + exams + context', 'Prior-smoothed grade / study associations',
        'Python core with MySQL and MongoDB adapters'
    ]], widths=[5.45, 5.45, 5.45], small=True)
    heading(doc, 'Abstract', 2)
    p(doc, 'This paper specifies and implements an adaptive recommendation engine that translates dated subject '
      'scores, school timetables, available study windows and upcoming assessments into personalized '
      'weekly independent-study schedules. It uses an explainable subject-priority function and a constrained '
      'greedy scheduling heuristic, plus a conservatively bounded adaptation layer learned from observed '
      'grade changes paired with actual logged study time. One shared core is backed by interchangeable '
      'MySQL and MongoDB adapters. A synthetic two-student case demonstrates differential allocations, '
      'teacher summaries and timetable conflict avoidance. The implementation is an engineering prototype, '
      'not a clinically or educationally validated prediction of score gains.')
    heading(doc, 'Scope and status', 2)
    p(doc, 'Deliverable: an executable Python 3.10+ project with unit tests, local database schemas, a '
      'command-line interface, a development REST API, and sample data. The model is not a large language '
      'model; its adaptive component is statistical. All student records in the sample are synthetic.')
    p(doc, 'Keywords: personalized learning, spaced practice, scheduling optimization, self-regulated '
      'learning, adaptive prioritization, MySQL, MongoDB.', style='SmallNote')
    doc.add_page_break()

    heading(doc, '1. Executive summary')
    p(doc, 'Students differ in their subject strengths. Equal study time for every subject is often a poor '
      'default, but allocating all spare hours to the weakest subject can also neglect retention, deadlines '
      'and practical availability. ASLS aims to allocate finite self-study time across enrolled subjects '
      'without conflicting with school classes, while giving teachers a clear explanation of each plan.')
    bullet(doc, 'Generate subject priorities from performance gaps, score trends, examination urgency, '
           'classroom exposure and observed gaps in independent practice.')
    bullet(doc, 'Translate priorities into realistic 30-minute appointments, reserve five-minute gaps, '
           'and respect weekly, daily and subject-concentration limits.')
    bullet(doc, 'Update cautious effectiveness estimates when new grades and completed study logs arrive; '
           'cap any learned adjustment to avoid harmful feedback loops.')
    bullet(doc, 'Produce student-facing rationale and teacher-facing aggregated signals, with database-specific '
           'persistence but backend-neutral recommendation logic.')
    p(doc, 'Success is not defined merely by generating a timetable. Operational success requires no '
      'conflicts, usable explanations, feasible workloads and useful teacher decisions; educational success '
      'must be established through prospective measurement rather than inferred from historical correlation.')

    heading(doc, '2. System requirements and assumptions')
    table(doc, ['Actor', 'Typical question', 'Delivered output'], [
        ('Student', 'What should I study after school this week?', 'Personal plan, duration and study method'),
        ('Teacher', 'Which subjects need extra support in my class?', 'Aggregated mastery, time and intervention suggestions'),
        ('Administrator', 'How do I connect the current SIS and run plans?', 'Normalized inputs, adapters, persistence, auditable versions'),
    ], widths=[2.65, 6.35, 7.35])
    p(doc, 'Minimum inputs: a student identifier, class identifier, subject enrollments, at least one '
      'weekly availability window and appropriate study limits. Dated grades, classroom timetable, '
      'assessments and actual study logs increase personalization. All scores use a 0-100 scale. Weekdays '
      'are Monday=0 through Sunday=6, and the MVP assumes a single school-local timezone.')
    p(doc, 'The planning-week Monday is also the information cutoff. Scores or study logs dated after '
      'the cutoff must not affect a recommendation for that period. One grade is sufficient for '
      'performance ranking; historical adaptation requires paired grade observations and completed study logs.')

    heading(doc, '3. Performance representation')
    heading(doc, '3.1 Recent mastery and trend', 2)
    p(doc, 'For student i and subject j, retain up to eight most recent grades at or before the planning '
      'cutoff. Compute a recency-weighted average where each grade loses half its weight after 45 days:')
    formula(doc, 'w_r = exp[-ln(2) * age_days(r) / 45] ;  mastery_ij = sum(w_r * score_r) / sum(w_r)')
    p(doc, 'Trend is the most recent grade minus the preceding grade. If no observed score exists, '
      'the target score is used solely as a neutral scheduling baseline, and is explicitly marked as '
      'missing (not an observed grade). The class summary excludes missing grades from its average.')
    heading(doc, '3.2 Explainable priority', 2)
    formula(doc, 'P_ij = (0.25 + 2.00 D_ij + 0.30 T_ij + 0.50 E_ij + 0.15 C_ij + 0.10 R_ij) * L_ij')
    table(doc, ['Feature', 'Definition', 'Interpretation'], [
        ('D - mastery deficit', 'max(0, target - mastery) / 100', 'Gap from a student-specific desired score'),
        ('T - decline', 'min(1, max(0, -recent_change) / 10)', 'Increases urgency for falling results'),
        ('E - exam urgency', 'max(0, 1 - days_to_next_exam / 15)', 'Exam within the next 15 days'),
        ('C - classroom gap', 'max(0, (180 - class_minutes) / 180)', 'Limited class exposure in a week'),
        ('R - practice gap', '1 only when the latest observed log is >7 days old', 'Missing logs are not proof of no practice'),
        ('L - learned effect', 'Capped multiplier in [0.80, 1.20]', 'Bounded adjustment from actual outcomes'),
    ], widths=[3.6, 6.3, 6.45], small=True)
    p(doc, 'Coefficients, thresholds and target scores are policy choices in this reference implementation. '
      'They are not universal educational constants. Schools should validate their values with teachers '
      'and prospective data before deployment.')

    heading(doc, '4. Constrained scheduling')
    heading(doc, '4.1 Feasible time slots', 2)
    p(doc, 'The engine subtracts recurring classroom sessions from each student-provided availability '
      'window, then forms 30-minute study slots separated by five-minute gaps. Overlapping availability '
      'windows are de-duplicated. Available slots are distributed across days before filling additional '
      'slots, supporting spaced participation rather than front-loading the whole week [1]. Daily and weekly '
      'limits are interpreted as ceilings, not targets to exceed.')
    heading(doc, '4.2 Marginal utility heuristic', 2)
    formula(doc, 'M_ij(k) = P_ij * exp[-allocated_minutes_ij / 180] * q_ij(k) * f_ij(k)')
    p(doc, 'Here, q captures the temporal suitability of slot k (for example, before an upcoming '
      'assessment or shortly after a relevant class). The f term favors first exposure and discourages '
      'repeating one subject many times on the same day. Each new slot is allocated to the eligible '
      'subject with the highest marginal score; this is an interpretable greedy heuristic, not an '
      'exact global optimum.')
    heading(doc, '4.3 Hard and soft limits', 2)
    table(doc, ['Constraint', 'Reference policy'], [
        ('School conflict', 'Study slots never intersect timetable blocks'),
        ('Daily and weekly burden', 'Never exceed each student\'s recorded minute ceilings'),
        ('Session duration', '30 study minutes plus at least 5 break minutes'),
        ('Subject concentration', 'Up to 55% for 3+ subjects; 70% for two; 100% for one'),
        ('Subject coverage', 'At least one session for each subject when total available slots permit'),
        ('Practical availability', 'Only schedule within declared availability windows'),
    ], widths=[4.7, 11.65])
    p(doc, 'The reference engine awards a pre-exam preference, but does not yet impose a hard '
      '"all revision before examination" deadline. A production scheduler that promises exam-specific '
      'guarantees should add a dated assessment constraint and use a constrained optimization solver.')

    heading(doc, '5. Adaptive statistical learning')
    p(doc, 'A preference score alone is a static heuristic. ASLS adds an intentionally modest statistical '
      'feedback loop. For each consecutive pair of grade observations for the same student and subject, '
      'between 3 and 45 days apart, it sums actual completed study minutes strictly after the earlier '
      'grade and on or before the later grade. At least 30 minutes must have been logged.')
    formula(doc, 'observed_gain_per_hour = clip((score_after - score_before) / actual_hours, -3, +6)')
    p(doc, 'This is an association, not a causal effect. To reduce instability, subject estimates are '
      'shrunk toward 1.0 score point per hour with eight pseudo-observations; student-subject estimates '
      'are then shrunk toward the subject estimate with five pseudo-observations:')
    formula(doc, 'mu_subject = (8 * 1.0 + sum(g_subject)) / (8 + n_subject)')
    formula(doc, 'mu_student_subject = (5 * mu_subject + sum(g_student_subject)) / (5 + n_student_subject)')
    formula(doc, 'L_ij = clip(1 + 0.18 * (mu_student_subject - 1.0), 0.80, 1.20)')
    p(doc, 'The engine recalculates these smoothed estimates when new observations arrive; it is '
      '"self-improving" only to the extent that accurate and sufficiently numerous new grades and '
      'actual study logs are entered. The multiplier cannot be used to withhold all practice from '
      'students whose historical results appear difficult to improve. Data without completed study '
      'logs produces no training events.')
    p(doc, 'Important limitations include varying test difficulty, incomplete logs, regression to the '
      'mean, simultaneous classroom teaching, motivation and the absence of a randomized control. '
      'For a genuine predicted causal response to extra study time, use a carefully evaluated treatment '
      'effect or randomized intervention design in a later phase.')

    heading(doc, '6. End-to-end pipeline')
    table(doc, ['Stage', 'Primary responsibility', 'Implementation'], [
        ('1. Ingestion', 'Resolve grades, enrollments, availability, timetable, exams, logged study', 'MySQLStore / MongoStore'),
        ('2. Cutoff', 'Ignore observations after the week-start Monday', 'service + adapters'),
        ('3. Learning', 'Pair dated grade changes with observed study logs', 'learning.py'),
        ('4. Priority', 'Compute mastery, trend, context, bounded L and reason codes', 'core.py'),
        ('5. Scheduling', 'Remove conflicts, spread feasible slots, select marginal best subject', 'core.py'),
        ('6. Persistence', 'Store per-week allocations and recommended appointments', 'store.save_plan'),
        ('7. Delivery', 'Emit JSON plan and aggregated teacher view', 'CLI / FastAPI'),
    ], widths=[2.2, 8.25, 5.9], small=True)
    heading(doc, '6.1 Pseudocode', 2)
    formula(doc, 'for student in class:\n  history, logs, availability, classes, exams = read_db(student)\n  L = derive_outcomes_and_shrunk_rates(history, logs, cutoff)\n  P = score_each_enrolled_subject(history, exams, classes, L)\n  slots = subtract_class_and_space_study_windows(availability, classes)\n  slots = spread_across_week_and_apply_daily_weekly_limits(slots)\n  for slot in slots:\n    subject = argmax_eligible_marginal_utility(P, current_allocations, slot)\n    append_recommendation(subject, slot, explanation)\n  save_one_student_week(plan)')

    heading(doc, '7. Synthetic reference experiment')
    p(doc, 'The accompanying project includes two invented students with identical classroom '
      'timetables but different score profiles. This section reports output generated by the executable '
      'engine for the week beginning 19 October 2026. Results are illustrative of system behavior; '
      'they are not measurements of real learning improvement.')
    if DEMO.exists():
        data = json.loads(DEMO.read_text(encoding='utf-8'))
        profiles = {student['student_id']:{row['subject']:row for row in student['allocations']}
                    for student in data['student_plans']}
        subjects = ['English', 'Mathematics', 'Physics', 'Chemistry', 'History']
        rows=[]
        for name in subjects:
            a=profiles[101][name]
            b=profiles[102][name]
            rows.append((name, f"{a['mastery_score']:.1f}%", f"{a['recommended_minutes']/60:g} h",
                         f"{b['mastery_score']:.1f}%", f"{b['recommended_minutes']/60:g} h"))
        table(doc, ['Subject', 'Student A mastery', 'A: study', 'Student B mastery', 'B: study'], rows,
              widths=[3.4, 3.5, 2.6, 3.5, 3.35], small=True)
        total_a = data['student_plans'][0]['total_recommended_minutes'] / 60
        total_b = data['student_plans'][1]['total_recommended_minutes'] / 60
        p(doc, f'Student A receives {total_a:g} scheduled study hours (of a 10-hour weekly ceiling). '
          f'Student B receives {total_b:g} hours (of a 9-hour ceiling). Unused weekly allowance '
          'can result from the available windows and mandatory session gaps.')
    p(doc, 'The physics quiz increases Physics urgency for both students. Nonetheless, the '
      'English-strong/Physics-weak student receives much more Physics time than English time, '
      'and the Physics-strong/English-weak student receives more English than Physics time. '
      'Wednesday availability spanning 15:00-17:30 automatically excludes the 15:30-16:30 class.')
    heading(doc, 'Teacher use case', 2)
    p(doc, 'The teacher summary aggregates time, students under a specified observed-mastery '
      'threshold (70) and subject averages. It may recommend small-group diagnostics for subjects '
      'with struggling learners. A deployed school platform must apply teacher-class authorization '
      'and suppress or restrict small-group reports if re-identification is possible. [2]')

    heading(doc, '8. Database and software architecture')
    table(doc, ['Domain', 'MySQL representation', 'MongoDB representation'], [
        ('Student + subjects', 'sr_students + sr_enrollments + sr_subjects', 'Three collections using student_id / subject_id'),
        ('Grades + logs', 'sr_scores + sr_study_logs, DATE indices', 'sr_scores + sr_study_logs, ISO date string indices'),
        ('Availability / classes / exams', 'sr_availability + sr_class_timetable + sr_assessments', 'Analogous collections'),
        ('Generated plan', 'sr_recommendations + sr_plan_sessions', 'One sr_plans document per student/week'),
        ('Atomicity', 'Transactional delete-and-insert for one student/week', 'Atomic single-document replacement for one student/week'),
    ], widths=[3.35, 6.5, 6.5], small=True)
    p(doc, 'Both adapters map persistence-specific formats to identical Python dataclasses. '
      'The scoring and scheduling logic never issues SQL or MongoDB queries. In the MySQL '
      'implementation the generated plan is replaced inside a transaction; in MongoDB the '
      'whole student-week output is stored in one atomic document. A full class batch is not '
      'globally atomic in either backend.')
    heading(doc, '8.1 API surfaces', 2)
    p(doc, 'The CLI has demo, student and class commands. The optional FastAPI development '
      'application exposes read-only GET endpoints for students and classes, plus explicit '
      'POST generation endpoints to persist plans. Because the starter API intentionally '
      'contains no identity and role checks, it must stay bound to localhost until integrated '
      'behind a secure application server.')
    heading(doc, '8.2 Existing student score tables', 2)
    p(doc, 'Existing installations can retain their current tbl_student_score table and create '
      'a view or repeatable ETL job that maps its actual columns into student_id, subject_id, '
      'score, recorded_on. Exact legacy columns are unknown, so the package does not perform '
      'a destructive schema migration. The recommendation engine can coexist with a '
      'separate prediction-score engine if their input/output contracts remain clear.')

    heading(doc, '9. Quality, safety, privacy and evaluation')
    heading(doc, '9.1 Engineering acceptance tests', 2)
    table(doc, ['Measure', 'Acceptance criterion'], [
        ('No timetable overlap', 'Zero study/class collisions across all emitted sessions'),
        ('Study ceilings', "Every student's planned daily and weekly minutes <= recorded limits"),
        ('Break spacing', 'At least 5 minutes between sessions on the same day'),
        ('Coverage', 'When slots >= subject count, every enrolled subject receives >=1 slot'),
        ('Data cutoff', 'No grades dated later than the selected planning Monday used'),
        ('Reproducibility', 'Identical normalized inputs yield identical allocations across backends'),
        ('Privacy', 'Authenticated teacher can see only authorized class data'),
    ], widths=[4.3, 12.05], small=True)
    heading(doc, '9.2 Educational evaluation', 2)
    p(doc, 'Before high-stakes deployment, conduct a teacher-reviewed pilot with students and '
      'guardians as appropriate. Compare the plan against an appropriate baseline, for example '
      'a teacher-authored timetable or a balanced subject plan. Track adherence, actual weekly '
      'study burden, grade change on comparable assessments, learner satisfaction, teacher '
      'overrides, and differential effects across groups. Whenever possible, use prospectively '
      'designed comparisons to avoid over-attributing improvement to the recommender.')
    heading(doc, '9.3 Data protection and fairness', 2)
    p(doc, 'Student records are sensitive educational information. A school-grade production '
      'deployment needs authentication, class-level and student-level authorization, audit logs, '
      'data minimization, encryption at rest/in transit, retention rules, teacher override '
      'workflows, consent/governance review and policies applicable to its jurisdiction. '
      'Avoid sensitive characteristics as model optimization shortcuts. Monitor whether '
      'recommended workloads or learning opportunities are systematically inequitable.')

    heading(doc, '10. Limitations and recommended roadmap')
    table(doc, ['Stage', 'Deliverable', 'Exit test'], [
        ('Phase 1 - working prototype', 'Core scheduler, explanations, MySQL/Mongo adapters, tests', 'Conflict-free synthetic plans'),
        ('Phase 2 - school pilot', 'Real timetable/grade ingestion, authorized teacher review, audit', 'Usable plans and low override burden'),
        ('Phase 3 - richer learner model', 'Topic-level mastery, prerequisites, delayed retention and uncertainty', 'Validated topic recommendations'),
        ('Phase 4 - optimizer', 'Assignment constraints for exam deadlines and homework, CP-SAT/MILP', 'Measured advantage over greedy baseline'),
        ('Phase 5 - adaptive evaluation', 'Controlled interventions, calibration, longitudinal feedback', 'Credible improvement with equity audit'),
    ], widths=[4, 7.25, 5.1], small=True)
    p(doc, 'The current version does not understand curriculum topics, special accommodations, '
      'irregular term breaks, overnight schedules or non-school activities unless supplied as '
      'unavailable time. It does not produce a trustworthy numerical forecast of future grades. '
      'Priority coefficients are configurable policy assumptions only through code in this '
      'reference implementation; a production product should externalize and version them.')

    heading(doc, 'References')
    references = [
        '[1] Dunlosky J. et al. (2013). Improving Students\' Learning With Effective Learning '
        'Techniques. Psychological Science in the Public Interest, 14(1). '
        'https://doi.org/10.1177/1529100612453266',
        '[2] Education Endowment Foundation (2025). Metacognition and Self-Regulated Learning, '
        'Second Edition. https://educationendowmentfoundation.org.uk/education-evidence/guidance-reports/metacognition',
        '[3] Oracle. MySQL Connector/Python Developer Guide. '
        'https://dev.mysql.com/doc/connector-python/en/',
        '[4] MongoDB. PyMongo Driver: Bulk Write Operations and CRUD Guide. '
        'https://www.mongodb.com/docs/languages/python/pymongo-driver/current/crud/bulk-write/',
    ]
    for r in references:
        p(doc, r, style='SmallNote')

    heading(doc, 'Appendix A. Execution quick reference')
    formula(doc, 'python -m asls.cli demo --week 2026-10-19 --output demo.json\n'
                 'python -m asls.cli student --backend mysql --student-id 101 --week 2026-10-19\n'
                 'python -m asls.cli class --backend mongodb --class-id 10 --week 2026-10-19\n'
                 'python -m unittest discover -s tests -v')
    p(doc, 'The project README contains step-by-step installation, schema initialization, '
      'synthetic-data seeding, environment configuration, API routes and deployment warnings.')
    doc.save(TARGET)
    print(TARGET)


if __name__ == '__main__':
    body()
