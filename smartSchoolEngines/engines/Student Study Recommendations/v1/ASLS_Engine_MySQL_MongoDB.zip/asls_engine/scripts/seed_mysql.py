"""Seed an EMPTY/DEVELOPMENT MySQL schema with synthetic student data.

First apply sql/schema.sql. Do not run against a real school database.
"""
from __future__ import annotations
import argparse
from datetime import date, timedelta
from asls.demo_data import make_demo
from asls.storage.mysql_store import MySQLStore


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--week', required=True, help='Monday YYYY-MM-DD')
    parser.add_argument('--confirm-demo-db', action='store_true',
                        help='Required: modifies student IDs 101/102 and class 10')
    args = parser.parse_args()
    if not args.confirm_demo_db:
        parser.error('Pass --confirm-demo-db and use only a development database')
    bundles = make_demo(date.fromisoformat(args.week))
    store = MySQLStore()
    c = store.conn.cursor()
    try:
        store.conn.start_transaction()
        for uid in (101, 102):
            for table in ['sr_plan_sessions', 'sr_recommendations', 'sr_scores',
                          'sr_study_logs', 'sr_availability', 'sr_enrollments']:
                c.execute(f'DELETE FROM {table} WHERE student_id=%s', (uid,))
        c.execute('DELETE FROM sr_class_timetable WHERE class_id=10')
        c.execute('DELETE FROM sr_assessments WHERE class_id=10')
        for subj in bundles[0].subjects:
            c.execute('INSERT INTO sr_subjects (subject_id,subject_name) VALUES (%s,%s) '
                      'ON DUPLICATE KEY UPDATE subject_name=VALUES(subject_name)',
                      (subj.subject_id, subj.name))
        for bundle in bundles:
            u = bundle.student
            c.execute('INSERT INTO sr_students (student_id,student_name,class_id,weekly_limit_minutes,'
                      'daily_limit_minutes,target_score,active) VALUES (%s,%s,%s,%s,%s,%s,1) '
                      'ON DUPLICATE KEY UPDATE student_name=VALUES(student_name),class_id=VALUES(class_id),'
                      'weekly_limit_minutes=VALUES(weekly_limit_minutes),daily_limit_minutes=VALUES(daily_limit_minutes),'
                      'target_score=VALUES(target_score),active=1',
                      (u.student_id, u.name, u.class_id, u.weekly_limit_minutes,
                       u.daily_limit_minutes, u.target_score))
            c.executemany('INSERT INTO sr_enrollments (student_id,subject_id) VALUES (%s,%s)',
                          [(u.student_id, s.subject_id) for s in bundle.subjects])
            c.executemany('INSERT INTO sr_scores (student_id,subject_id,score,recorded_on) '
                          'VALUES (%s,%s,%s,%s)',
                          [(x.student_id, x.subject_id, x.score, x.recorded_on) for x in bundle.scores])
            c.executemany('INSERT INTO sr_study_logs (student_id,subject_id,studied_on,minutes) '
                          'VALUES (%s,%s,%s,%s)',
                          [(x.student_id, x.subject_id, x.studied_on, x.minutes)
                           for x in bundle.study_logs])
            c.executemany('INSERT INTO sr_availability (student_id,weekday,start_time,end_time) '
                          'VALUES (%s,%s,%s,%s)',
                          [(u.student_id, w.weekday, w.start, w.end) for w in bundle.availability])
        c.executemany('INSERT INTO sr_class_timetable (class_id,weekday,start_time,end_time,subject_id) '
                      'VALUES (%s,%s,%s,%s,%s)',
                      [(10, x.weekday, x.start, x.end, x.subject_id) for x in bundles[0].timetable])
        c.executemany('INSERT INTO sr_assessments (class_id,subject_id,due_on,title) VALUES (%s,%s,%s,%s)',
                      [(10, x.subject_id, x.due_on, x.title) for x in bundles[0].assessments])
        store.conn.commit()
        print(f'Seeded synthetic class 10 for the week of {args.week} in MySQL')
    except Exception:
        store.conn.rollback()
        raise
    finally:
        c.close()
        store.close()


if __name__ == '__main__':
    main()
