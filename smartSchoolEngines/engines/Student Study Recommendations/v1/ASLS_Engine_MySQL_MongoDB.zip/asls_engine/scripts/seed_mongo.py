"""Seed MongoDB with synthetic data; modifies only synthetic IDs 101/102, class 10."""
from __future__ import annotations
import argparse
from dataclasses import asdict
from datetime import date
from asls.demo_data import make_demo
from asls.storage.mongo_store import MongoStore


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--week', required=True)
    parser.add_argument('--confirm-demo-db', action='store_true')
    args = parser.parse_args()
    if not args.confirm_demo_db:
        parser.error('Pass --confirm-demo-db and use only a development database')
    bundles = make_demo(date.fromisoformat(args.week))
    store = MongoStore()
    db = store.db
    try:
        for coll in ['sr_enrollments', 'sr_scores', 'sr_study_logs', 'sr_availability', 'sr_plans']:
            db[coll].delete_many({'student_id': {'$in': [101, 102]}})
        db.sr_class_timetable.delete_many({'class_id': 10})
        db.sr_assessments.delete_many({'class_id': 10})
        for subject in bundles[0].subjects:
            db.sr_subjects.replace_one({'subject_id': subject.subject_id},
                {'subject_id': subject.subject_id, 'subject_name': subject.name}, upsert=True)
        for bundle in bundles:
            s = bundle.student
            db.sr_students.replace_one({'student_id': s.student_id}, {
                'student_id': s.student_id, 'student_name': s.name, 'class_id': s.class_id,
                'weekly_limit_minutes': s.weekly_limit_minutes, 'daily_limit_minutes': s.daily_limit_minutes,
                'target_score': s.target_score, 'active': True,
            }, upsert=True)
            db.sr_enrollments.insert_many([{'student_id': s.student_id, 'subject_id': x.subject_id}
                                           for x in bundle.subjects])
            db.sr_scores.insert_many([{'student_id': x.student_id, 'subject_id': x.subject_id,
                                       'score': x.score, 'recorded_on': x.recorded_on.isoformat()}
                                      for x in bundle.scores])
            db.sr_study_logs.insert_many([{'student_id': x.student_id, 'subject_id': x.subject_id,
                                          'studied_on': x.studied_on.isoformat(), 'minutes': x.minutes}
                                         for x in bundle.study_logs])
            db.sr_availability.insert_many([{'student_id': s.student_id, 'weekday': x.weekday,
                                            'start_time': x.start.strftime('%H:%M'),
                                            'end_time': x.end.strftime('%H:%M')}
                                           for x in bundle.availability])
        db.sr_class_timetable.insert_many([{
            'class_id': 10, 'weekday': x.weekday, 'start_time': x.start.strftime('%H:%M'),
            'end_time': x.end.strftime('%H:%M'), 'subject_id': x.subject_id,
        } for x in bundles[0].timetable])
        db.sr_assessments.insert_many([{'class_id': 10, 'subject_id': x.subject_id,
                                        'due_on': x.due_on.isoformat(), 'title': x.title}
                                       for x in bundles[0].assessments])
        print(f'Seeded synthetic class 10 for the week of {args.week} in MongoDB')
    finally:
        store.close()


if __name__ == '__main__':
    main()
