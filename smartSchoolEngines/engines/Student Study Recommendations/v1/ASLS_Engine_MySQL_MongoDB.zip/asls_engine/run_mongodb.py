"""Convenience launcher: MongoDB-connected engine."""
import sys
from asls.cli import main

if __name__ == '__main__':
    main([*sys.argv[1:2], '--backend', 'mongodb', *sys.argv[2:]])
