"""Convenience launcher: MySQL-connected engine."""
import sys
from asls.cli import main

if __name__ == '__main__':
    main([*sys.argv[1:2], '--backend', 'mysql', *sys.argv[2:]])
