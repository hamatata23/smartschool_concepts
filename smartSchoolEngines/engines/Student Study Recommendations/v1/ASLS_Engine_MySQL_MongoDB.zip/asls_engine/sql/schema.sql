-- ASLS 1.0 - MySQL 8 schema; install into a dedicated empty database.
-- Existing schemas such as tbl_student_score are NOT overwritten.
CREATE TABLE IF NOT EXISTS sr_students (
 student_id BIGINT NOT NULL PRIMARY KEY,
 student_name VARCHAR(160) NOT NULL,
 class_id BIGINT NOT NULL,
 weekly_limit_minutes INT NOT NULL DEFAULT 600,
 daily_limit_minutes INT NOT NULL DEFAULT 120,
 target_score DECIMAL(5,2) NOT NULL DEFAULT 85.00,
 active BOOLEAN NOT NULL DEFAULT TRUE,
 INDEX idx_students_class (class_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sr_subjects (
 subject_id BIGINT NOT NULL PRIMARY KEY,
 subject_name VARCHAR(120) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sr_enrollments (
 student_id BIGINT NOT NULL,
 subject_id BIGINT NOT NULL,
 PRIMARY KEY (student_id,subject_id),
 FOREIGN KEY (student_id) REFERENCES sr_students(student_id),
 FOREIGN KEY (subject_id) REFERENCES sr_subjects(subject_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sr_scores (
 score_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 student_id BIGINT NOT NULL,
 subject_id BIGINT NOT NULL,
 score DECIMAL(5,2) NOT NULL,
 recorded_on DATE NOT NULL,
 INDEX idx_scores_student_subject_date (student_id,subject_id,recorded_on),
 INDEX idx_scores_date (recorded_on),
 FOREIGN KEY (student_id) REFERENCES sr_students(student_id),
 FOREIGN KEY (subject_id) REFERENCES sr_subjects(subject_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sr_study_logs (
 log_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 student_id BIGINT NOT NULL,
 subject_id BIGINT NOT NULL,
 studied_on DATE NOT NULL,
 minutes INT NOT NULL,
 INDEX idx_logs_student_date (student_id,studied_on),
 INDEX idx_logs_date (studied_on),
 FOREIGN KEY (student_id) REFERENCES sr_students(student_id),
 FOREIGN KEY (subject_id) REFERENCES sr_subjects(subject_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sr_availability (
 availability_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 student_id BIGINT NOT NULL,
 weekday TINYINT UNSIGNED NOT NULL COMMENT 'Monday=0 through Sunday=6',
 start_time TIME NOT NULL,
 end_time TIME NOT NULL,
 INDEX idx_availability_student (student_id),
 FOREIGN KEY (student_id) REFERENCES sr_students(student_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sr_class_timetable (
 timetable_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 class_id BIGINT NOT NULL,
 weekday TINYINT UNSIGNED NOT NULL,
 start_time TIME NOT NULL,
 end_time TIME NOT NULL,
 subject_id BIGINT NULL COMMENT 'NULL means a non-subject busy period',
 INDEX idx_timetable_class (class_id,weekday),
 FOREIGN KEY (subject_id) REFERENCES sr_subjects(subject_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sr_assessments (
 assessment_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 class_id BIGINT NOT NULL,
 subject_id BIGINT NOT NULL,
 due_on DATE NOT NULL,
 title VARCHAR(200) NOT NULL,
 INDEX idx_assessments_class_date (class_id,due_on),
 FOREIGN KEY (subject_id) REFERENCES sr_subjects(subject_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sr_recommendations (
 student_id BIGINT NOT NULL,
 week_start DATE NOT NULL,
 subject_id BIGINT NOT NULL,
 recommended_minutes INT NOT NULL,
 mastery_score DECIMAL(5,2) NOT NULL,
 priority_score DECIMAL(9,4) NOT NULL,
 reasons_json JSON NOT NULL,
 methods_json JSON NOT NULL,
 engine_version VARCHAR(30) NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (student_id,week_start,subject_id),
 FOREIGN KEY (student_id) REFERENCES sr_students(student_id),
 FOREIGN KEY (subject_id) REFERENCES sr_subjects(subject_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sr_plan_sessions (
 student_id BIGINT NOT NULL,
 week_start DATE NOT NULL,
 subject_id BIGINT NOT NULL,
 start_at DATETIME NOT NULL COMMENT 'School-local time; use a single timezone per deployment',
 end_at DATETIME NOT NULL,
 minutes INT NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (student_id,week_start,start_at),
 INDEX idx_sessions_week (week_start),
 FOREIGN KEY (student_id) REFERENCES sr_students(student_id),
 FOREIGN KEY (subject_id) REFERENCES sr_subjects(subject_id)
) ENGINE=InnoDB;
