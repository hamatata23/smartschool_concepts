"""CLI for live DB plans or a dependency-free synthetic offline demo."""
from __future__ import annotations
import argparse
import json
from datetime import date, timedelta
from pathlib import Path
from .core import plan_week, teacher_summary
from .demo_data import make_demo
from .learning import LearningIndex, derive_outcomes
from .service import generate_student_plan, generate_class_plans, open_store


def monday_default() -> date:
    today = date.today()
    return today - timedelta(days=today.weekday())


def main(argv=None):
    parser = argparse.ArgumentParser(description='ASLS weekly study recommendation engine')
    parser.add_argument('command', choices=('demo', 'student', 'class'))
    parser.add_argument('--backend', choices=('mysql', 'mongodb'), default='mysql')
    parser.add_argument('--student-id', type=int)
    parser.add_argument('--class-id', type=int)
    parser.add_argument('--week', default=monday_default().isoformat(), help='Monday, YYYY-MM-DD')
    parser.add_argument('--output', type=Path, help='Write full JSON to this file')
    parser.add_argument('--dry-run', action='store_true', help='Do not save plans into DB')
    args = parser.parse_args(argv)
    week = date.fromisoformat(args.week)
    if week.weekday() != 0:
        parser.error('--week must be a Monday')
    if args.command == 'demo':
        bundles = make_demo(week)
        grades = [g for bundle in bundles for g in bundle.scores]
        logs = [entry for bundle in bundles for entry in bundle.study_logs]
        model = LearningIndex(derive_outcomes(grades, logs, week))
        plans = [plan_week(b, week, model) for b in bundles]
        result = {'teacher_summary': teacher_summary(plans), 'student_plans': plans}
    else:
        if args.command == 'student' and args.student_id is None:
            parser.error('student command requires --student-id')
        if args.command == 'class' and args.class_id is None:
            parser.error('class command requires --class-id')
        store = open_store(args.backend)
        try:
            if args.command == 'student':
                result = generate_student_plan(store, args.student_id, week, not args.dry_run)
            else:
                result = generate_class_plans(store, args.class_id, week, not args.dry_run)
        finally:
            store.close()
    output = json.dumps(result, indent=2, ensure_ascii=False)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(output + '\n', encoding='utf-8')
        print(f'Wrote {args.output}')
    else:
        print(output)


if __name__ == '__main__':
    main()
