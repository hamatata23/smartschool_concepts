"""Development-only FastAPI endpoints. Add authentication and RBAC before use."""
from __future__ import annotations
from datetime import date
import os
from fastapi import FastAPI, HTTPException, Query
from .service import open_store, generate_student_plan, generate_class_plans

app = FastAPI(title='ASLS Study Recommendation API', version='1.0.0')


def parse_week(text: str) -> date:
    try:
        week = date.fromisoformat(text)
    except ValueError as exc:
        raise HTTPException(422, 'week must be YYYY-MM-DD') from exc
    if week.weekday() != 0:
        raise HTTPException(422, 'week must be Monday')
    return week


def compute(kind: str, identifier: int, week: str, persist: bool):
    store = open_store(os.getenv('ASLS_BACKEND', 'mysql'))
    try:
        start = parse_week(week)
        if kind == 'student':
            return generate_student_plan(store, identifier, start, persist=persist)
        return generate_class_plans(store, identifier, start, persist=persist)
    except LookupError as exc:
        raise HTTPException(404, str(exc)) from exc
    finally:
        store.close()


@app.get('/health')
def health():
    return {'status': 'ok', 'service': 'asls', 'note': 'Does not test database connectivity'}


@app.get('/students/{student_id}/recommendations')
def student_recommendations(student_id: int, week: str = Query(...)):
    return compute('student', student_id, week, persist=False)


@app.get('/classes/{class_id}/recommendations')
def class_recommendations(class_id: int, week: str = Query(...)):
    return compute('class', class_id, week, persist=False)


@app.post('/students/{student_id}/generate')
def create_student_recommendation(student_id: int, week: str = Query(...)):
    return compute('student', student_id, week, persist=True)


@app.post('/classes/{class_id}/generate')
def create_class_recommendation(class_id: int, week: str = Query(...)):
    return compute('class', class_id, week, persist=True)
