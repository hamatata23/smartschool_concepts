"""Deterministic, explainable weekly self-study planner, independent of DB."""
from __future__ import annotations
from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from math import exp, floor, log
from .models import StudentBundle, Score, ClassSession
from .learning import LearningIndex, clamp

ENGINE_VERSION = '1.0.0'
SLOT_MINUTES = 30
BREAK_MINUTES = 5
TAU_MINUTES = 180.0


@dataclass(frozen=True)
class Slot:
    start: datetime
    end: datetime


def as_minutes(t: time) -> int:
    return 60 * t.hour + t.minute


def at_time(day: date, minutes: int) -> datetime:
    return datetime.combine(day, time()) + timedelta(minutes=minutes)


def subtract_busy(start: int, end: int, busy: list[tuple[int, int]]) -> list[tuple[int, int]]:
    """Subtract potentially overlapping class blocks from a free interval."""
    parts = [(start, end)]
    for bstart, bend in sorted(busy):
        next_parts = []
        for left, right in parts:
            if bend <= left or bstart >= right:
                next_parts.append((left, right))
            else:
                if left < bstart:
                    next_parts.append((left, bstart))
                if bend < right:
                    next_parts.append((bend, right))
        parts = next_parts
    return parts


def generate_slots(bundle: StudentBundle, week_start: date) -> list[Slot]:
    """Build 30-minute work sessions inside availability, with five-minute gaps.

    Available windows are assumed to be student-local and within a single day.
    Duplicate/overlapping input windows do not produce overlapping output.
    """
    if week_start.weekday() != 0:
        raise ValueError('week_start must be a Monday (YYYY-MM-DD)')
    student = bundle.student
    if student.weekly_limit_minutes < 0 or student.daily_limit_minutes < 0:
        raise ValueError('Study limits must be nonnegative')
    candidates: list[Slot] = []
    for wd in range(7):
        day = week_start + timedelta(days=wd)
        occupied = [
            (as_minutes(c.start), as_minutes(c.end))
            for c in bundle.timetable if c.weekday == wd
        ]
        for avail in bundle.availability:
            if avail.weekday != wd:
                continue
            a, b = as_minutes(avail.start), as_minutes(avail.end)
            if a >= b:
                raise ValueError('Availability must fit within one day and end after start')
            for left, right in subtract_busy(a, b, occupied):
                pos = left
                while pos + SLOT_MINUTES <= right:
                    candidates.append(Slot(at_time(day, pos), at_time(day, pos + SLOT_MINUTES)))
                    pos += SLOT_MINUTES + BREAK_MINUTES
    candidates.sort(key=lambda x: (x.start, x.end))
    # A second pass protects against overlapping or duplicated availability.
    by_day = defaultdict(list)
    for candidate in candidates:
        by_day[candidate.start.date()].append(candidate)
    result = []
    per_day_limit = student.daily_limit_minutes // SLOT_MINUTES
    for day in sorted(by_day):
        selected = []
        for candidate in by_day[day]:
            if len(selected) >= per_day_limit:
                break
            if selected and candidate.start < selected[-1].end + timedelta(minutes=BREAK_MINUTES):
                continue
            selected.append(candidate)
        result.extend(selected)
    return result



def spread_slots(slots: list[Slot], blocks: int) -> list[Slot]:
    """Distribute planned sessions across available days before filling extra slots."""
    by_day = defaultdict(list)
    for slot in slots:
        by_day[slot.start.date()].append(slot)
    days = sorted(by_day)
    taken = []
    while len(taken) < blocks and days:
        for day in list(days):
            if not by_day[day]:
                days.remove(day)
                continue
            taken.append(by_day[day].pop(0))
            if len(taken) >= blocks:
                break
    return sorted(taken, key=lambda slot: slot.start)

def weighted_mastery(history: list[Score], as_of: date, cold_start: float = 85.0) -> tuple[float, float, int]:
    hist = sorted((x for x in history if x.recorded_on <= as_of), key=lambda x: x.recorded_on)
    if not hist:
        return cold_start, 0.0, 0  # neutral; not counted as an observed grade
    hist = hist[-8:]
    weights = [exp(-log(2) * max(0, (as_of - x.recorded_on).days) / 45.0) for x in hist]
    mastery = sum(x.score * w for x, w in zip(hist, weights)) / sum(weights)
    trend = hist[-1].score - hist[-2].score if len(hist) >= 2 else 0.0
    return round(mastery, 2), round(trend, 2), len(hist)


def student_subject_profiles(bundle: StudentBundle, week_start: date,
                             learning: LearningIndex) -> list[dict]:
    out = []
    student = bundle.student
    for subject in bundle.subjects:
        subject_scores = [x for x in bundle.scores if x.subject_id == subject.subject_id]
        score, trend, n = weighted_mastery(subject_scores, week_start, student.target_score)
        class_minutes = sum(
            as_minutes(t.end) - as_minutes(t.start)
            for t in bundle.timetable if t.subject_id == subject.subject_id
        )
        assessments = [a for a in bundle.assessments if a.subject_id == subject.subject_id
                       and a.due_on >= week_start]
        next_exam = min((a.due_on for a in assessments), default=None)
        exam_days = (next_exam - week_start).days if next_exam else None
        urgency = max(0.0, 1.0 - exam_days / 15.0) if exam_days is not None else 0.0
        subject_logs = [x for x in bundle.study_logs if x.subject_id == subject.subject_id
                        and x.studied_on <= week_start]
        last_study = max((x.studied_on for x in subject_logs), default=None)
        # Missing logs are not assumed to mean the student did not study.
        practice_gap = 1.0 if last_study and (week_start - last_study).days > 7 else 0.0
        deficit = max(0.0, student.target_score - score) / 100.0
        fall = min(1.0, max(0.0, -trend) / 10.0)
        class_gap = max(0.0, (180 - class_minutes) / 180.0)
        learning_stat = learning.estimate(student.student_id, subject.subject_id)
        base = 0.25 + 2 * deficit + 0.30 * fall + 0.50 * urgency + 0.15 * class_gap + 0.10 * practice_gap
        priority = base * learning_stat['multiplier']
        reasons = []
        if n == 0:
            reasons.append('No grades yet; neutral cold-start baseline, not an observed grade')
        elif score < student.target_score:
            reasons.append(f'Current mastery {score:.1f}% is below {student.target_score:.0f}% target')
        else:
            reasons.append(f'Maintenance of current mastery {score:.1f}%')
        if trend < -2:
            reasons.append(f'Recent grade declined by {abs(trend):.1f} points')
        if exam_days is not None and exam_days <= 14:
            reasons.append(f'Upcoming assessment in {exam_days} day(s)')
        if class_minutes < 120:
            reasons.append(f'Only {class_minutes} classroom minutes scheduled this week')
        if practice_gap:
            reasons.append('Last recorded independent practice was over seven days ago')
        if learning_stat['subject_observations']:
            reasons.append('Adjusted conservatively using past logged study/grade associations')
        if next_exam and exam_days is not None and exam_days <= 7:
            methods = ['Timed retrieval quiz', 'Practice mistakes and feedback', 'Short spaced review']
        elif score < 65:
            methods = ['Worked examples', 'Guided problem practice', 'Self-test with corrections']
        elif score < 85:
            methods = ['Active recall', 'Targeted exercises', 'Review mistakes']
        else:
            methods = ['Spaced retrieval', 'Challenge problems', 'Brief maintenance quiz']
        out.append({
            'subject_id': subject.subject_id,
            'subject': subject.name,
            'mastery_score': score,
            'trend_points': trend,
            'grades_count': n,
            'class_minutes': class_minutes,
            'next_assessment': next_exam.isoformat() if next_exam else None,
            'priority': round(priority, 4),
            'adaptive_multiplier': learning_stat['multiplier'],
            'learning_observations': learning_stat['subject_observations'],
            'student_learning_observations': learning_stat['student_subject_observations'],
            'reasons': reasons,
            'methods': methods,
        })
    return out


def _slot_fit(profile: dict, slot: Slot, classes: list[ClassSession],
              daily_count: int) -> float:
    fit = 1.0
    due = date.fromisoformat(profile['next_assessment']) if profile['next_assessment'] else None
    if due is not None:
        if slot.start.date() <= due:
            days = (due - slot.start.date()).days
            if days <= 5:
                fit *= 1.18 + 0.15 * (5 - days) / 5
        else:
            fit *= 0.92
    wd = slot.start.weekday()
    if any(t.subject_id == profile['subject_id'] and t.weekday == wd and
           as_minutes(t.end) <= slot.start.hour * 60 + slot.start.minute for t in classes):
        fit *= 1.08  # after-class consolidation
    if any(t.subject_id == profile['subject_id'] and t.weekday == (wd + 1) % 7
           for t in classes):
        fit *= 1.04  # preparation before class
    if daily_count:
        fit *= 0.76 ** daily_count  # distribute across days / subjects
    return fit


def plan_week(bundle: StudentBundle, week_start: date,
              learning: LearningIndex | None = None) -> dict:
    """Generate explanations, subject allocations and conflict-free sessions."""
    if not bundle.subjects:
        raise ValueError('Student must be enrolled in at least one subject')
    if not (0 <= bundle.student.target_score <= 100):
        raise ValueError('target_score must be between 0 and 100')
    learning = learning or LearningIndex()
    profiles = student_subject_profiles(bundle, week_start, learning)
    slots = generate_slots(bundle, week_start)
    total_blocks = min(len(slots), bundle.student.weekly_limit_minutes // SLOT_MINUTES)
    slots = spread_slots(slots, total_blocks)
    n_subjects = len(profiles)
    share = 1.0 if n_subjects == 1 else (0.70 if n_subjects == 2 else 0.55)
    cap = max(1, floor(total_blocks * share))
    while n_subjects * cap < total_blocks:
        cap += 1  # preserve feasibility for small budgets
    taken = defaultdict(int)
    daily_taken = defaultdict(int)
    sessions = []
    for ix, slot in enumerate(slots):
        remaining = total_blocks - ix
        unseen = [p for p in profiles if taken[p['subject_id']] == 0]
        # Guarantee one maintenance session per enrolled subject when feasible.
        must_cover = remaining <= len(unseen)
        eligible = [p for p in profiles if taken[p['subject_id']] < cap and
                    (not must_cover or taken[p['subject_id']] == 0)]
        if not eligible:  # defensive, should not occur with the cap calculation
            raise RuntimeError('Unable to allocate all study blocks')

        def marginal(p: dict) -> tuple[float, int]:
            sid = p['subject_id']
            current_minutes = taken[sid] * SLOT_MINUTES
            freshness = 1.18 if taken[sid] == 0 else 1.0
            fit = _slot_fit(p, slot, bundle.timetable,
                            daily_taken[(slot.start.date(), sid)])
            utility = p['priority'] * exp(-current_minutes / TAU_MINUTES) * fit * freshness
            return utility, -sid  # deterministic ties

        selected = max(eligible, key=marginal)
        sid = selected['subject_id']
        taken[sid] += 1
        daily_taken[(slot.start.date(), sid)] += 1
        sessions.append({
            'subject_id': sid,
            'subject': selected['subject'],
            'start_at': slot.start.isoformat(timespec='minutes'),
            'end_at': slot.end.isoformat(timespec='minutes'),
            'minutes': SLOT_MINUTES,
            'methods': selected['methods'][:2],
        })
    allocations = []
    for item in sorted(profiles, key=lambda p: (-taken[p['subject_id']], -p['priority'], p['subject_id'])):
        allocations.append({**item, 'recommended_minutes': taken[item['subject_id']] * SLOT_MINUTES})
    return {
        'engine_version': ENGINE_VERSION,
        'student_id': bundle.student.student_id,
        'student_name': bundle.student.name,
        'class_id': bundle.student.class_id,
        'week_start': week_start.isoformat(),
        'week_end': (week_start + timedelta(days=6)).isoformat(),
        'target_score': bundle.student.target_score,
        'weekly_limit_minutes': bundle.student.weekly_limit_minutes,
        'daily_limit_minutes': bundle.student.daily_limit_minutes,
        'total_recommended_minutes': len(sessions) * SLOT_MINUTES,
        'unallocated_weekly_limit_minutes': max(0, bundle.student.weekly_limit_minutes - len(sessions) * SLOT_MINUTES),
        'allocation_policy': {'slot_minutes': SLOT_MINUTES, 'break_minutes': BREAK_MINUTES,
                              'max_subject_share': share, 'diminishing_returns_tau_minutes': TAU_MINUTES},
        'allocations': allocations,
        'sessions': sessions,
    }


def teacher_summary(plans: list[dict]) -> dict:
    """Aggregate by subject; does not expose student identities or grade rows."""
    by_subject: dict[int, dict] = {}
    for plan in plans:
        for row in plan['allocations']:
            sid = row['subject_id']
            agg = by_subject.setdefault(sid, {
                'subject_id': sid, 'subject': row['subject'], 'students': 0,
                'students_below_70': 0, 'total_study_minutes': 0, 'sum_mastery': 0.0,
            })
            agg['students'] += 1
            agg['students_below_70'] += int(row['grades_count'] > 0 and row['mastery_score'] < 70)
            agg['total_study_minutes'] += row['recommended_minutes']
            if row['grades_count'] > 0:
                agg['sum_mastery'] += row['mastery_score']
            else:
                # Do not report the cold-start assumption as an observed grade.
                pass
    result = []
    for row in by_subject.values():
        observed = [a for p in plans for a in p['allocations']
                    if a['subject_id'] == row['subject_id'] and a['grades_count'] > 0]
        avg = round(sum(a['mastery_score'] for a in observed) / len(observed), 2) if observed else None
        result.append({
            'subject_id': row['subject_id'], 'subject': row['subject'],
            'students': row['students'], 'students_below_70': row['students_below_70'],
            'average_observed_mastery': avg,
            'total_recommended_hours': round(row['total_study_minutes'] / 60, 2),
            'recommended_teacher_action': (
                'Offer a small-group diagnostic and targeted exercises'
                if row['students_below_70'] else 'Provide maintenance practice and extension tasks'
            ),
        })
    result.sort(key=lambda x: (-x['students_below_70'], -x['total_recommended_hours'], x['subject_id']))
    return {'students': len(plans), 'class_id': plans[0]['class_id'] if plans else None,
            'week_start': plans[0]['week_start'] if plans else None, 'subjects': result}
