"""MySQL 8 adapter using parameterized MySQL Connector/Python queries."""
from __future__ import annotations
from datetime import date, datetime, time, timedelta
import json
import os
from asls.models import (Student, Subject, Score, StudyLog, Window, ClassSession,
                         Assessment, StudentBundle)


def _date(value):
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value)[:10])


def _time(value):
    if isinstance(value, time):
        return value
    if isinstance(value, timedelta):  # Connector/Python often returns TIME as timedelta.
        seconds = int(value.total_seconds())
        return time((seconds // 3600) % 24, (seconds // 60) % 60, seconds % 60)
    return time.fromisoformat(str(value))


class MySQLStore:
    def __init__(self, connection=None):
        if connection is None:
            import mysql.connector  # optional until MySQL adapter is selected
            connection = mysql.connector.connect(
                host=os.getenv('MYSQL_HOST', '127.0.0.1'),
                port=int(os.getenv('MYSQL_PORT', '3306')),
                user=os.getenv('MYSQL_USER', 'asls'),
                password=os.getenv('MYSQL_PASSWORD', ''),
                database=os.getenv('MYSQL_DATABASE', 'asls'),
                connection_timeout=10,
                autocommit=True,
            )
        self.conn = connection

    def close(self):
        self.conn.close()

    def _rows(self, query, params=()):
        cursor = self.conn.cursor(dictionary=True)
        try:
            cursor.execute(query, params)
            return cursor.fetchall()
        finally:
            cursor.close()

    def list_student_ids(self, class_id=None):
        if class_id is None:
            rows = self._rows('SELECT student_id FROM sr_students WHERE active=1 ORDER BY student_id')
        else:
            rows = self._rows('SELECT student_id FROM sr_students WHERE class_id=%s AND active=1 ORDER BY student_id', (class_id,))
        return [int(row['student_id']) for row in rows]

    def load_student_bundle(self, student_id: int, as_of: date):
        rows = self._rows('SELECT * FROM sr_students WHERE student_id=%s AND active=1', (student_id,))
        if not rows:
            raise LookupError(f'No active student {student_id}')
        u = rows[0]
        student = Student(int(u['student_id']), u['student_name'], int(u['class_id']),
                          int(u['weekly_limit_minutes']), int(u['daily_limit_minutes']), float(u['target_score']))
        subjects = [Subject(int(x['subject_id']), x['subject_name']) for x in self._rows(
            'SELECT s.subject_id, s.subject_name FROM sr_subjects s JOIN sr_enrollments e '
            'ON s.subject_id=e.subject_id WHERE e.student_id=%s ORDER BY s.subject_id', (student_id,))]
        scores = [Score(int(x['student_id']), int(x['subject_id']), float(x['score']), _date(x['recorded_on']))
                  for x in self._rows('SELECT student_id,subject_id,score,recorded_on FROM sr_scores '
                                      'WHERE student_id=%s AND recorded_on<=%s ORDER BY recorded_on',
                                      (student_id, as_of))]
        logs = [StudyLog(int(x['student_id']), int(x['subject_id']), _date(x['studied_on']), int(x['minutes']))
                for x in self._rows('SELECT student_id,subject_id,studied_on,minutes FROM sr_study_logs '
                                    'WHERE student_id=%s AND studied_on<=%s', (student_id, as_of))]
        windows = [Window(int(x['weekday']), _time(x['start_time']), _time(x['end_time']))
                   for x in self._rows('SELECT weekday,start_time,end_time FROM sr_availability WHERE student_id=%s',
                                       (student_id,))]
        classes = [ClassSession(int(x['weekday']), _time(x['start_time']), _time(x['end_time']),
                                int(x['subject_id']) if x['subject_id'] is not None else None)
                   for x in self._rows('SELECT weekday,start_time,end_time,subject_id FROM sr_class_timetable '
                                       'WHERE class_id=%s', (student.class_id,))]
        assess = [Assessment(int(x['subject_id']), _date(x['due_on']), x['title'])
                  for x in self._rows('SELECT subject_id,due_on,title FROM sr_assessments '
                                      'WHERE class_id=%s AND due_on BETWEEN %s AND %s',
                                      (student.class_id, as_of, as_of + timedelta(days=21)))]
        return StudentBundle(student, subjects, scores, logs, windows, classes, assess)

    def load_training_history(self, as_of: date):
        earliest = as_of - timedelta(days=365)
        scores = [Score(int(x['student_id']), int(x['subject_id']), float(x['score']), _date(x['recorded_on']))
                  for x in self._rows('SELECT student_id,subject_id,score,recorded_on FROM sr_scores '
                                      'WHERE recorded_on BETWEEN %s AND %s', (earliest, as_of))]
        logs = [StudyLog(int(x['student_id']), int(x['subject_id']), _date(x['studied_on']), int(x['minutes']))
                for x in self._rows('SELECT student_id,subject_id,studied_on,minutes FROM sr_study_logs '
                                    'WHERE studied_on BETWEEN %s AND %s', (earliest, as_of))]
        return scores, logs

    def save_plan(self, plan):
        """Transactionally replace recommendations for student+week (idempotent)."""
        student_id, week = plan['student_id'], plan['week_start']
        cursor = self.conn.cursor()
        try:
            self.conn.start_transaction()
            cursor.execute('DELETE FROM sr_plan_sessions WHERE student_id=%s AND week_start=%s',
                           (student_id, week))
            cursor.execute('DELETE FROM sr_recommendations WHERE student_id=%s AND week_start=%s',
                           (student_id, week))
            cursor.executemany(
                'INSERT INTO sr_recommendations (student_id,week_start,subject_id,'
                'recommended_minutes,mastery_score,priority_score,reasons_json,methods_json,engine_version) '
                'VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)',
                [(student_id, week, x['subject_id'], x['recommended_minutes'], x['mastery_score'],
                  x['priority'], json.dumps(x['reasons']), json.dumps(x['methods']), plan['engine_version'])
                 for x in plan['allocations']]
            )
            if plan['sessions']:
                cursor.executemany(
                    'INSERT INTO sr_plan_sessions (student_id,week_start,subject_id,start_at,end_at,minutes) '
                    'VALUES (%s,%s,%s,%s,%s,%s)',
                    [(student_id, week, x['subject_id'],
                      datetime.fromisoformat(x['start_at']), datetime.fromisoformat(x['end_at']), x['minutes'])
                     for x in plan['sessions']]
                )
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        finally:
            cursor.close()
