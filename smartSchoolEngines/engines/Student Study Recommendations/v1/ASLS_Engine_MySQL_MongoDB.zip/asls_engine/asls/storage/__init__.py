"""Independent storage adapters for ASLS."""
