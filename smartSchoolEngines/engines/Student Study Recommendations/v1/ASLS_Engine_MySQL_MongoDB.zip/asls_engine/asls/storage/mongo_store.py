"""MongoDB adapter. Dates are ISO yyyy-mm-dd strings, local times HH:MM."""
from __future__ import annotations
from datetime import date, timedelta, time
import os
from asls.models import (Student, Subject, Score, StudyLog, Window, ClassSession,
                         Assessment, StudentBundle)


def _day(value):
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value)[:10])


def _clock(value):
    if isinstance(value, time):
        return value
    return time.fromisoformat(str(value))


class MongoStore:
    def __init__(self, database=None):
        if database is None:
            from pymongo import MongoClient  # imported only for MongoDB requests
            self.client = MongoClient(os.getenv('MONGODB_URI', 'mongodb://127.0.0.1:27017'),
                                      serverSelectionTimeoutMS=7000)
            self.client.admin.command('ping')
            database = self.client[os.getenv('MONGODB_DATABASE', 'asls')]
        else:
            self.client = None
        self.db = database

    def close(self):
        if self.client:
            self.client.close()

    def list_student_ids(self, class_id=None):
        query = {'active': True}
        if class_id is not None:
            query['class_id'] = int(class_id)
        return [int(x['student_id']) for x in self.db.sr_students.find(query, {'student_id': 1}).sort('student_id', 1)]

    def load_student_bundle(self, student_id: int, as_of: date):
        u = self.db.sr_students.find_one({'student_id': student_id, 'active': True})
        if u is None:
            raise LookupError(f'No active student {student_id}')
        student = Student(int(u['student_id']), u['student_name'], int(u['class_id']),
                          int(u['weekly_limit_minutes']), int(u['daily_limit_minutes']), float(u['target_score']))
        ids = [x['subject_id'] for x in self.db.sr_enrollments.find({'student_id': student_id})]
        subjects = [Subject(int(x['subject_id']), x['subject_name'])
                    for x in self.db.sr_subjects.find({'subject_id': {'$in': ids}}).sort('subject_id', 1)]
        scores = [Score(int(x['student_id']), int(x['subject_id']), float(x['score']), _day(x['recorded_on']))
                  for x in self.db.sr_scores.find({'student_id': student_id,
                                                   'recorded_on': {'$lte': as_of.isoformat()}})]
        logs = [StudyLog(int(x['student_id']), int(x['subject_id']), _day(x['studied_on']), int(x['minutes']))
                for x in self.db.sr_study_logs.find({'student_id': student_id,
                                                     'studied_on': {'$lte': as_of.isoformat()}})]
        windows = [Window(int(x['weekday']), _clock(x['start_time']), _clock(x['end_time']))
                   for x in self.db.sr_availability.find({'student_id': student_id})]
        classes = [ClassSession(int(x['weekday']), _clock(x['start_time']), _clock(x['end_time']),
                                x.get('subject_id'))
                   for x in self.db.sr_class_timetable.find({'class_id': student.class_id})]
        assess = [Assessment(int(x['subject_id']), _day(x['due_on']), x['title'])
                  for x in self.db.sr_assessments.find({'class_id': student.class_id,
                    'due_on': {'$gte': as_of.isoformat(), '$lte': (as_of + timedelta(days=21)).isoformat()}})]
        return StudentBundle(student, subjects, scores, logs, windows, classes, assess)

    def load_training_history(self, as_of: date):
        start = (as_of - timedelta(days=365)).isoformat()
        end = as_of.isoformat()
        scores = [Score(int(x['student_id']), int(x['subject_id']), float(x['score']), _day(x['recorded_on']))
                  for x in self.db.sr_scores.find({'recorded_on': {'$gte': start, '$lte': end}})]
        logs = [StudyLog(int(x['student_id']), int(x['subject_id']), _day(x['studied_on']), int(x['minutes']))
                for x in self.db.sr_study_logs.find({'studied_on': {'$gte': start, '$lte': end}})]
        return scores, logs

    def save_plan(self, plan):
        """Atomic replace of a complete student+week plan in a single document."""
        document = dict(plan)
        self.db.sr_plans.replace_one(
            {'student_id': plan['student_id'], 'week_start': plan['week_start']},
            document, upsert=True,
        )
