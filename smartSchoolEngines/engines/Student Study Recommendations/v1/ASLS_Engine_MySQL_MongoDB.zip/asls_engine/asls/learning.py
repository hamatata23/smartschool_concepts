"""Conservative, auditable Bayesian-smoothed adaptation to observed outcomes.

Outcomes are observational associations, NOT causal treatment effects.
Only grades available before the planning cutoff are considered.
"""
from __future__ import annotations
from collections import defaultdict
from dataclasses import dataclass
from datetime import date
from .models import Score, StudyLog


def clamp(a: float, lo: float, hi: float) -> float:
    return min(hi, max(lo, a))


@dataclass(frozen=True)
class Outcome:
    student_id: int
    subject_id: int
    gain_per_hour: float


def derive_outcomes(scores: list[Score], logs: list[StudyLog], as_of: date) -> list[Outcome]:
    """Consecutive grade changes / observed completed hours over matching periods.

    Intervals of 3..45 days and >=30 logged study minutes are retained. A grade
    is not retrospectively paired with study time outside its measurement window.
    """
    by_key: dict[tuple[int, int], list[Score]] = defaultdict(list)
    logged: dict[tuple[int, int], list[StudyLog]] = defaultdict(list)
    for item in scores:
        if item.recorded_on <= as_of and 0 <= item.score <= 100:
            by_key[(item.student_id, item.subject_id)].append(item)
    for item in logs:
        if item.studied_on <= as_of and item.minutes > 0:
            logged[(item.student_id, item.subject_id)].append(item)
    outcomes = []
    for (student_id, subject_id), grades in by_key.items():
        grades.sort(key=lambda x: x.recorded_on)
        for before, after in zip(grades, grades[1:]):
            delta_days = (after.recorded_on - before.recorded_on).days
            if not (3 <= delta_days <= 45):
                continue
            minutes = sum(
                log.minutes for log in logged[(student_id, subject_id)]
                if before.recorded_on < log.studied_on <= after.recorded_on
            )
            if minutes < 30:
                continue
            gain = (after.score - before.score) / (minutes / 60.0)
            outcomes.append(Outcome(student_id, subject_id, clamp(gain, -3.0, 6.0)))
    return outcomes


class LearningIndex:
    """Online-compatible hierarchical mean with regularizing pseudo-counts.

    Subject mean is shrunk toward 1.0 points/hour (8 pseudo observations);
    student-subject mean is shrunk toward that subject mean (5 pseudo obs).
    Adjustment to priority is deliberately capped at +/-20%.
    """

    def __init__(self, outcomes: list[Outcome] | None = None) -> None:
        self.subject_rates: dict[int, list[float]] = defaultdict(list)
        self.student_rates: dict[tuple[int, int], list[float]] = defaultdict(list)
        for event in outcomes or []:
            self.add(event)

    def add(self, event: Outcome) -> None:
        self.subject_rates[event.subject_id].append(event.gain_per_hour)
        self.student_rates[(event.student_id, event.subject_id)].append(event.gain_per_hour)

    def estimate(self, student_id: int, subject_id: int) -> dict:
        subject = self.subject_rates[subject_id]
        own = self.student_rates[(student_id, subject_id)]
        prior = 1.0
        subject_est = (8 * prior + sum(subject)) / (8 + len(subject))
        own_est = (5 * subject_est + sum(own)) / (5 + len(own))
        # A bounded, cautious adjustment; never treats negative association
        # as a reason to deprive a student of essential subject study time.
        multiplier = clamp(1.0 + 0.18 * (own_est - prior), 0.8, 1.2)
        return {
            'multiplier': round(multiplier, 4),
            'association_points_per_hour': round(own_est, 3),
            'subject_observations': len(subject),
            'student_subject_observations': len(own),
        }
