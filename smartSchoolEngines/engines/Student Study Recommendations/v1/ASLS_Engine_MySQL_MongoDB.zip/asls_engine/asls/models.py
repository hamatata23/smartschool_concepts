"""Typed, backend-neutral inputs to the adaptive recommendation engine."""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, time


@dataclass(frozen=True)
class Student:
    student_id: int
    name: str
    class_id: int
    weekly_limit_minutes: int = 600
    daily_limit_minutes: int = 120
    target_score: float = 85.0


@dataclass(frozen=True)
class Subject:
    subject_id: int
    name: str


@dataclass(frozen=True)
class Score:
    student_id: int
    subject_id: int
    score: float
    recorded_on: date


@dataclass(frozen=True)
class StudyLog:
    student_id: int
    subject_id: int
    studied_on: date
    minutes: int


@dataclass(frozen=True)
class Window:
    weekday: int  # Monday=0, Sunday=6
    start: time
    end: time


@dataclass(frozen=True)
class ClassSession:
    weekday: int
    start: time
    end: time
    subject_id: int | None = None


@dataclass(frozen=True)
class Assessment:
    subject_id: int
    due_on: date
    title: str = 'Assessment'


@dataclass
class StudentBundle:
    student: Student
    subjects: list[Subject] = field(default_factory=list)
    scores: list[Score] = field(default_factory=list)
    study_logs: list[StudyLog] = field(default_factory=list)
    availability: list[Window] = field(default_factory=list)
    timetable: list[ClassSession] = field(default_factory=list)
    assessments: list[Assessment] = field(default_factory=list)
