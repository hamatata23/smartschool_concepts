"""Synthetic demonstration records; no real student data is included."""
from __future__ import annotations
from datetime import date, time, timedelta
from .models import (Student, Subject, Score, StudyLog, Window,
                     ClassSession, Assessment, StudentBundle)


def make_demo(week_start: date):
    if week_start.weekday() != 0:
        raise ValueError('Demo week_start must be a Monday')
    subjects = [Subject(1, 'English'), Subject(2, 'Mathematics'),
                Subject(3, 'Physics'), Subject(4, 'Chemistry'), Subject(5, 'History')]
    scores = {
        101: {1: [87, 90, 92], 2: [75, 70, 64], 3: [62, 60, 58],
              4: [69, 72, 73], 5: [82, 85, 86]},
        102: {1: [64, 59, 55], 2: [80, 83, 85], 3: [87, 90, 92],
              4: [70, 73, 75], 5: [71, 75, 78]},
    }
    timetable = [
        ClassSession(0, time(9), time(10), 2),
        ClassSession(0, time(10, 30), time(11, 30), 3),
        ClassSession(1, time(9), time(10), 1),
        ClassSession(1, time(11), time(12), 5),
        ClassSession(2, time(15, 30), time(16, 30), 4),
        ClassSession(3, time(9), time(10), 2),
        ClassSession(4, time(10), time(11), 3),
    ]
    availability = [Window(0, time(18), time(20)), Window(1, time(18), time(20)),
                    Window(2, time(15), time(17, 30)), Window(3, time(18), time(20)),
                    Window(4, time(18), time(19)), Window(5, time(9), time(12)),
                    Window(6, time(10), time(12))]
    assessments = [Assessment(3, week_start + timedelta(days=4), 'Physics quiz'),
                   Assessment(4, week_start + timedelta(days=10), 'Chemistry exam'),
                   Assessment(1, week_start + timedelta(days=15), 'English presentation')]
    bundles = []
    for uid, name, limit in [(101, 'Demo Student A', 600), (102, 'Demo Student B', 540)]:
        hist = []
        logs = []
        for subject_id, values in scores[uid].items():
            for offset, grade in zip((-36, -15, -1), values):
                hist.append(Score(uid, subject_id, grade, week_start + timedelta(days=offset)))
            for offset, mins in [(-29, 45), (-23, 60), (-10, 45), (-4, 75)]:
                logs.append(StudyLog(uid, subject_id, week_start + timedelta(days=offset), mins))
        bundles.append(StudentBundle(
            student=Student(uid, name, 10, limit, 120, 85),
            subjects=subjects, scores=hist, study_logs=logs,
            availability=availability, timetable=timetable, assessments=assessments,
        ))
    return bundles
