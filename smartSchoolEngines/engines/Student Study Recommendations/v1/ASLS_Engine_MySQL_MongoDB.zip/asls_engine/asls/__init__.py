"""ASLS 1.0 - adaptive self-study recommendation engine."""
from .core import plan_week, teacher_summary
from .learning import LearningIndex, derive_outcomes
__all__ = ['plan_week', 'teacher_summary', 'LearningIndex', 'derive_outcomes']
