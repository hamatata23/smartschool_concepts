"""Shared orchestration layer, independent of persistence vendor."""
from __future__ import annotations
from datetime import date
from .core import plan_week, teacher_summary
from .learning import LearningIndex, derive_outcomes


def make_learning_index(store, week_start: date) -> LearningIndex:
    grades, logs = store.load_training_history(week_start)
    return LearningIndex(derive_outcomes(grades, logs, week_start))


def generate_student_plan(store, student_id: int, week_start: date, persist=True,
                          learning: LearningIndex | None = None):
    model = learning if learning is not None else make_learning_index(store, week_start)
    bundle = store.load_student_bundle(student_id, week_start)
    plan = plan_week(bundle, week_start, model)
    if persist:
        store.save_plan(plan)
    return plan


def generate_class_plans(store, class_id: int, week_start: date, persist=True):
    model = make_learning_index(store, week_start)
    plans = [generate_student_plan(store, student_id, week_start, persist, model)
             for student_id in store.list_student_ids(class_id)]
    return {'teacher_summary': teacher_summary(plans), 'student_plans': plans}


def open_store(backend: str):
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:  # offline demo does not require any driver
        pass
    if backend == 'mysql':
        from .storage.mysql_store import MySQLStore
        return MySQLStore()
    if backend in ('mongo', 'mongodb'):
        from .storage.mongo_store import MongoStore
        return MongoStore()
    raise ValueError('backend must be mysql or mongodb')
