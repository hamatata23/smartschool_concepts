from __future__ import annotations
import unittest
from collections import defaultdict
from datetime import date, timedelta, time
from asls.core import plan_week, teacher_summary, generate_slots, SLOT_MINUTES, BREAK_MINUTES
from asls.demo_data import make_demo
from asls.learning import derive_outcomes, LearningIndex, Outcome
from asls.models import Student, Subject, Score, Window, ClassSession, StudentBundle

WEEK = date(2026, 10, 19)


def plans():
    b = make_demo(WEEK)
    history = [x for item in b for x in item.scores]
    logs = [x for item in b for x in item.study_logs]
    model = LearningIndex(derive_outcomes(history, logs, WEEK))
    return b, [plan_week(x, WEEK, model) for x in b]


class TestRecommendations(unittest.TestCase):
    def test_students_have_opposite_weak_subjects(self):
        _, output = plans()
        a = {x['subject']: x for x in output[0]['allocations']}
        b = {x['subject']: x for x in output[1]['allocations']}
        self.assertGreater(a['Physics']['priority'], a['English']['priority'])
        self.assertGreater(b['English']['priority'], b['Physics']['priority'])
        self.assertGreater(a['Physics']['recommended_minutes'], a['English']['recommended_minutes'])
        self.assertGreater(b['English']['recommended_minutes'], b['Physics']['recommended_minutes'])

    def test_limits_and_timetable_conflicts(self):
        bundles, output = plans()
        for bundle, result in zip(bundles, output):
            sessions = result['sessions']
            self.assertLessEqual(result['total_recommended_minutes'], bundle.student.weekly_limit_minutes)
            self.assertEqual(result['total_recommended_minutes'], sum(s['minutes'] for s in sessions))
            per_day = defaultdict(int)
            by_day = defaultdict(list)
            allowed = {(x.start.isoformat(timespec='minutes'), x.end.isoformat(timespec='minutes'))
                       for x in generate_slots(bundle, WEEK)}
            for s in sessions:
                from datetime import datetime
                start = datetime.fromisoformat(s['start_at'])
                end = datetime.fromisoformat(s['end_at'])
                self.assertIn((s['start_at'], s['end_at']), allowed)
                self.assertEqual(int((end-start).total_seconds()/60), SLOT_MINUTES)
                self.assertEqual(start.isoweekday(), start.date().isoweekday())
                by_day[start.date()].append((start,end))
                per_day[start.date()] += s['minutes']
            for day in per_day:
                self.assertLessEqual(per_day[day], bundle.student.daily_limit_minutes)
            for day, times in by_day.items():
                times.sort()
                for (prev_a, prev_b), (cur_a, cur_b) in zip(times,times[1:]):
                    self.assertGreaterEqual((cur_a-prev_b).total_seconds()/60, BREAK_MINUTES)
                for begin,end in times:
                    for class_block in bundle.timetable:
                        if class_block.weekday == day.weekday():
                            cl_start = begin.replace(hour=class_block.start.hour, minute=class_block.start.minute)
                            cl_end = begin.replace(hour=class_block.end.hour, minute=class_block.end.minute)
                            self.assertTrue(end <= cl_start or begin >= cl_end)

    def test_spread_across_multiple_days(self):
        _, output = plans()
        dates = {s['start_at'][:10] for s in output[0]['sessions']}
        self.assertGreaterEqual(len(dates), 5)

    def test_teacher_aggregate_anonymous(self):
        _, output = plans()
        summary = teacher_summary(output)
        self.assertEqual(summary['students'], 2)
        self.assertEqual(summary['class_id'], 10)
        self.assertNotIn('Demo Student', str(summary))
        self.assertGreater(summary['subjects'][0]['students_below_70'], 0)

    def test_no_availability_zero_study(self):
        bundle = make_demo(WEEK)[0]
        bundle.availability = []
        output = plan_week(bundle, WEEK)
        self.assertEqual(output['total_recommended_minutes'], 0)
        self.assertFalse(output['sessions'])

    def test_one_subject_uses_all_feasible_blocks(self):
        bundle = make_demo(WEEK)[0]
        bundle.subjects = bundle.subjects[:1]
        output = plan_week(bundle, WEEK)
        self.assertTrue(all(s['subject_id'] == 1 for s in output['sessions']))
        self.assertLessEqual(output['total_recommended_minutes'], 600)

    def test_missing_scores_not_reported_as_observed(self):
        bundle = StudentBundle(Student(555, 'No Grades', 9, 60, 60),
                               [Subject(1, 'Math')], [], [],
                               [Window(0, time(18), time(20))], [], [])
        output = plan_week(bundle, WEEK)
        self.assertEqual(output['allocations'][0]['grades_count'], 0)
        self.assertIsNone(teacher_summary([output])['subjects'][0]['average_observed_mastery'])

    def test_class_conflict_partially_splits_window(self):
        b = StudentBundle(Student(1, 'Test', 1, 240, 240), [Subject(1, 'Science')], [], [],
                          [Window(0, time(14), time(18))],
                          [ClassSession(0, time(15), time(16), 1)], [])
        windows = generate_slots(b, WEEK)
        for w in windows:
            self.assertTrue(w.end.time() <= time(15) or w.start.time() >= time(16))

    def test_no_same_day_double_booking_overlapping_availability(self):
        b = StudentBundle(Student(1, 'Test', 1, 240, 240), [Subject(1, 'Science')], [], [],
                          [Window(0, time(14), time(18)), Window(0, time(15), time(19))], [], [])
        output = plan_week(b, WEEK)
        starts = [s['start_at'] for s in output['sessions']]
        self.assertEqual(len(starts), len(set(starts)))

    def test_monday_required(self):
        with self.assertRaises(ValueError):
            plan_week(make_demo(WEEK)[0], WEEK + timedelta(days=1))


class TestAdaptiveLearning(unittest.TestCase):
    def test_posterior_adjusts_and_caps(self):
        improved = LearningIndex([Outcome(1, 2, 6.0)] * 50)
        declined = LearningIndex([Outcome(1, 2, -3.0)] * 50)
        self.assertGreater(improved.estimate(1,2)['multiplier'], 1)
        self.assertLess(declined.estimate(1,2)['multiplier'], 1)
        self.assertLessEqual(improved.estimate(1,2)['multiplier'], 1.2)
        self.assertGreaterEqual(declined.estimate(1,2)['multiplier'], 0.8)

    def test_no_outcomes_when_no_verified_study_logs(self):
        b = make_demo(WEEK)[0]
        self.assertEqual(derive_outcomes(b.scores, [], WEEK), [])
        self.assertTrue(derive_outcomes(b.scores, b.study_logs, WEEK))

    def test_future_scores_excluded_from_learning(self):
        b = make_demo(WEEK)[0]
        g = list(b.scores)
        g += [Score(101, 3, 99, WEEK + timedelta(days=20))]
        self.assertEqual(derive_outcomes(g, b.study_logs, WEEK),
                         derive_outcomes(b.scores, b.study_logs, WEEK))


if __name__ == '__main__':
    unittest.main()
