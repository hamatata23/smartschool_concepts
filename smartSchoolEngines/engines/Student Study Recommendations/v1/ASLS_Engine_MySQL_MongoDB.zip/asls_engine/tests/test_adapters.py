"""Offline DB-adapter contract tests (without requiring database servers).

MySQL adapter is exercised through an SQLite-backed MySQL cursor shim;
MongoDB adapter is exercised through a minimal document-collection shim.
These are not substitutes for deployment integration tests against real servers.
"""
from __future__ import annotations
from datetime import date
import sqlite3
from datetime import datetime
sqlite3.register_adapter(date, lambda value: value.isoformat())
sqlite3.register_adapter(datetime, lambda value: value.isoformat(sep=" "))
import unittest
from asls.demo_data import make_demo
from asls.service import generate_student_plan, generate_class_plans
from asls.storage.mysql_store import MySQLStore
from asls.storage.mongo_store import MongoStore

WEEK = date(2026, 10, 19)


class SqlCursorShim:
    def __init__(self, cursor, dictionary=False):
        self.cursor = cursor
        self.dictionary = dictionary

    def execute(self, statement, params=()):
        return self.cursor.execute(statement.replace('%s', '?'), params)

    def executemany(self, statement, param_sets):
        return self.cursor.executemany(statement.replace('%s', '?'), param_sets)

    def fetchall(self):
        rows = self.cursor.fetchall()
        if not self.dictionary:
            return rows
        return [dict(zip([x[0] for x in self.cursor.description], row)) for row in rows]

    def close(self):
        return self.cursor.close()


class SqlConnectionShim:
    def __init__(self):
        self.db = sqlite3.connect(':memory:', isolation_level=None)

    def cursor(self, dictionary=False):
        return SqlCursorShim(self.db.cursor(), dictionary)

    def start_transaction(self):
        self.db.execute('BEGIN')

    def commit(self):
        self.db.commit()

    def rollback(self):
        self.db.rollback()

    def close(self):
        self.db.close()


class CursorList(list):
    def sort(self, key, direction=1):  # PyMongo cursor .sort(name, ascending)
        return CursorList(sorted(self, key=lambda x: x.get(key, ''), reverse=direction == -1))


def matches(doc: dict, query: dict) -> bool:
    for key, expected in query.items():
        value = doc.get(key)
        if isinstance(expected, dict):
            for op, operand in expected.items():
                if op == '$in' and value not in operand:
                    return False
                if op == '$lte' and not (value <= operand):
                    return False
                if op == '$gte' and not (value >= operand):
                    return False
        elif value != expected:
            return False
    return True


class CollectionShim:
    def __init__(self, documents=None):
        self.documents = list(documents or [])

    def find(self, query, projection=None):
        return CursorList([doc.copy() for doc in self.documents if matches(doc, query)])

    def find_one(self, query):
        return next((doc.copy() for doc in self.documents if matches(doc, query)), None)

    def replace_one(self, query, replacement, upsert=False):
        indexes = [i for i, doc in enumerate(self.documents) if matches(doc, query)]
        if indexes:
            self.documents[indexes[0]] = replacement.copy()
        elif upsert:
            self.documents.append(replacement.copy())


class MongoDatabaseShim:
    def __init__(self, records):
        self._collections = {key: CollectionShim(val) for key, val in records.items()}

    def __getattr__(self, attr):
        if attr.startswith('sr_'):
            return self._collections.setdefault(attr, CollectionShim())
        raise AttributeError(attr)


def fixtures():
    bundles = make_demo(WEEK)
    subjects = bundles[0].subjects
    rows = {
        'sr_students': [], 'sr_subjects': [], 'sr_enrollments': [],
        'sr_scores': [], 'sr_study_logs': [], 'sr_availability': [],
        'sr_class_timetable': [], 'sr_assessments': [], 'sr_plans': [],
    }
    for s in subjects:
        rows['sr_subjects'].append({'subject_id': s.subject_id, 'subject_name': s.name})
    for b in bundles:
        u = b.student
        rows['sr_students'].append({
            'student_id': u.student_id, 'student_name': u.name, 'class_id': u.class_id,
            'weekly_limit_minutes': u.weekly_limit_minutes,
            'daily_limit_minutes': u.daily_limit_minutes, 'target_score': u.target_score,
            'active': True,
        })
        rows['sr_enrollments'].extend([{'student_id': u.student_id, 'subject_id': s.subject_id}
                                      for s in b.subjects])
        rows['sr_scores'].extend([{'student_id': x.student_id, 'subject_id': x.subject_id,
                                   'score': x.score, 'recorded_on': x.recorded_on.isoformat()}
                                  for x in b.scores])
        rows['sr_study_logs'].extend([{'student_id': x.student_id, 'subject_id': x.subject_id,
                                       'studied_on': x.studied_on.isoformat(), 'minutes': x.minutes}
                                      for x in b.study_logs])
        rows['sr_availability'].extend([{'student_id': u.student_id, 'weekday': x.weekday,
                                         'start_time': x.start.isoformat(timespec='minutes'),
                                         'end_time': x.end.isoformat(timespec='minutes')}
                                        for x in b.availability])
    rows['sr_class_timetable'].extend([{'class_id': 10, 'weekday': x.weekday,
                                         'start_time': x.start.isoformat(timespec='minutes'),
                                         'end_time': x.end.isoformat(timespec='minutes'),
                                         'subject_id': x.subject_id}
                                        for x in bundles[0].timetable])
    rows['sr_assessments'].extend([{'class_id': 10, 'subject_id': x.subject_id,
                                     'due_on': x.due_on.isoformat(), 'title': x.title}
                                    for x in bundles[0].assessments])
    return rows


def sqlite_mysql_shim(records):
    conn = SqlConnectionShim()
    statements = {
        'sr_students': 'student_id INTEGER, student_name TEXT, class_id INTEGER, weekly_limit_minutes INTEGER, daily_limit_minutes INTEGER, target_score REAL, active INTEGER',
        'sr_subjects': 'subject_id INTEGER, subject_name TEXT',
        'sr_enrollments': 'student_id INTEGER, subject_id INTEGER',
        'sr_scores': 'student_id INTEGER, subject_id INTEGER, score REAL, recorded_on TEXT',
        'sr_study_logs': 'student_id INTEGER, subject_id INTEGER, studied_on TEXT, minutes INTEGER',
        'sr_availability': 'student_id INTEGER, weekday INTEGER, start_time TEXT, end_time TEXT',
        'sr_class_timetable': 'class_id INTEGER, weekday INTEGER, start_time TEXT, end_time TEXT, subject_id INTEGER',
        'sr_assessments': 'class_id INTEGER, subject_id INTEGER, due_on TEXT, title TEXT',
        'sr_recommendations': 'student_id INTEGER, week_start TEXT, subject_id INTEGER, recommended_minutes INTEGER, mastery_score REAL, priority_score REAL, reasons_json TEXT, methods_json TEXT, engine_version TEXT',
        'sr_plan_sessions': 'student_id INTEGER, week_start TEXT, subject_id INTEGER, start_at TEXT, end_at TEXT, minutes INTEGER',
    }
    for name, ddl in statements.items():
        conn.db.execute(f'CREATE TABLE {name} ({ddl})')
        for record in records.get(name, []):
            fields = list(record)
            cols = ','.join(fields)
            placeholders = ','.join(['?'] * len(fields))
            values = [int(value) if isinstance(value, bool) else value for value in record.values()]
            conn.db.execute(f'INSERT INTO {name} ({cols}) VALUES ({placeholders})', values)
    return conn


class TestAdapters(unittest.TestCase):
    def test_mysql_and_mongo_student_plan_parity_and_saving(self):
        records = fixtures()
        mysql = MySQLStore(connection=sqlite_mysql_shim(records))
        mongo = MongoStore(database=MongoDatabaseShim(records))
        try:
            first_mysql = generate_student_plan(mysql, 101, WEEK, persist=True)
            first_mongo = generate_student_plan(mongo, 101, WEEK, persist=True)
            self.assertEqual(first_mysql, first_mongo)
            self.assertEqual(len(first_mysql['allocations']), 5)
            self.assertEqual(len(mongo.db.sr_plans.documents), 1)
            rows = mysql.conn.db.execute('SELECT count(*) FROM sr_recommendations').fetchone()[0]
            sessions = mysql.conn.db.execute('SELECT count(*) FROM sr_plan_sessions').fetchone()[0]
            self.assertEqual(rows, 5)
            self.assertEqual(sessions, len(first_mysql['sessions']))
            self.assertEqual(mongo.db.sr_plans.documents[0], first_mongo)
            # Both backends replace in-place on regeneration; no duplicate plan rows.
            self.assertEqual(generate_student_plan(mysql, 101, WEEK), first_mysql)
            self.assertEqual(generate_student_plan(mongo, 101, WEEK), first_mongo)
            self.assertEqual(mysql.conn.db.execute('SELECT count(*) FROM sr_recommendations').fetchone()[0], 5)
            self.assertEqual(len(mongo.db.sr_plans.documents), 1)
        finally:
            mysql.close()
            mongo.close()

    def test_mysql_and_mongo_teacher_class_parity(self):
        records = fixtures()
        mysql = MySQLStore(connection=sqlite_mysql_shim(records))
        mongo = MongoStore(database=MongoDatabaseShim(records))
        try:
            m1 = generate_class_plans(mysql, 10, WEEK, persist=False)
            m2 = generate_class_plans(mongo, 10, WEEK, persist=False)
            self.assertEqual(m1, m2)
            self.assertEqual(m1['teacher_summary']['students'], 2)
        finally:
            mysql.close()
            mongo.close()


if __name__ == '__main__':
    unittest.main()
