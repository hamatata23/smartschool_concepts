# ASLS 1.0 - Adaptive Student Learning & Study Scheduling Engine

A working, explainable Python self-study recommendation engine with **the same planner** behind two independent adapters: **MySQL 8.4** and **MongoDB 7**. Includes a teacher-facing aggregated summary, synthetic fixtures, CLI, development REST API, and 15 automated tests including offline adapter-contract parity tests.

**Status:** Tested algorithmic prototype, not a validated educational intervention or production-ready student information system. Real database integration requires running your own MySQL/MongoDB instance; automatic performance learning requires both dated grades and actual completed study logs.

## 1. Design at a glance

- **Scores:** weighted recent grade average per student+subject; student target as a neutral cold-start baseline when no grades; recent score declines increase need.
- **Subject priority:** weighted mastery deficit, declining grades, exams within 15 days, low scheduled classroom exposure, gaps in *recorded* practice, and a tightly bounded adaptive multiplier.
- **Schedules:** five-minute breaks between 30-minute study sessions. Respects user-entered available windows, school timetable, daily/weekly study limits, and weekly per-subject share limits. Sessions are spread across weekdays.
- **Self-learning:** scores before the planning cutoff plus verified study logs are matched into observational grade-change-per-hour records, shrunk to conservative prior estimates. Weights are recalculated each week as new evidence enters the DB; no `train` command needed.
- **Teachers:** per-class recommendations, anonymous subject-level summary, low-mastery counts, and recommended interventions. A future application must authenticate/authorize access to all these educational records.
- **Explanation:** reasons and study methods are included with each subject recommendation.

## 2. Quickest possible demonstration (no database needed)

Python **3.10+**. From the project root:

```bash
python -m asls.cli demo --week 2026-10-19 --output demo.json
python -m pytest -q   # after installing pytest; alternatively use unittest below
```

If `pytest` isn't available, run the stdlib tests:

```bash
python -m unittest discover -s tests -v
```

The demo uses 2 entirely synthetic students, 5 subjects, school classes, individual available windows, grades, actual past logs, and assessments. Its scores differ: Student A is stronger in English and weaker in Physics, while Student B is the opposite. It writes plans plus teacher summary to `demo.json`.

## 3. Install & start both database servers (local development)

Requirements: Python 3.10+, pip, and optionally Docker Compose. **The supplied Docker Compose file is for localhost development only**: it uses static demo credentials and MongoDB without authentication. Do not use it as-is on the Internet.

```bash
cd asls_engine
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
docker compose up -d
```

The compose services bind only to `127.0.0.1` on ports `3306` and `27017`. On a real server, provision database users with least-privilege access and enable database authentication/TLS.

### MySQL database path

In a new terminal, from this project root:

```bash
# Initialize MySQL tables; run once when database is ready:
docker compose exec -T mysql mysql -uasls -pasls_dev_password asls < sql/schema.sql

cp .env.example .env
# In .env set MYSQL_PASSWORD=asls_dev_password for this local demo only.
# Or export MYSQL_PASSWORD=asls_dev_password in the shell.
export MYSQL_PASSWORD=asls_dev_password

python -m scripts.seed_mysql --week 2026-10-19 --confirm-demo-db
python run_mysql.py student --student-id 101 --week 2026-10-19 --output mysql_plan.json
python run_mysql.py class --class-id 10 --week 2026-10-19 --output mysql_class.json
```

The MySQL output is persisted in `sr_recommendations` (weekly subject allocations) and `sr_plan_sessions` (dated sessions). Re-running replaces a student+week's generated suggestion transactionally. **Do not use the demo seeder against existing school records**; the seeded IDs 101/102 and class 10 are overwritten.

### MongoDB database path

```bash
python -m scripts.init_mongo
python -m scripts.seed_mongo --week 2026-10-19 --confirm-demo-db
python run_mongodb.py student --student-id 101 --week 2026-10-19 --output mongo_plan.json
python run_mongodb.py class --class-id 10 --week 2026-10-19 --output mongo_class.json
```

MongoDB stores each complete student-week plan as a single document in `sr_plans`; replacement is atomic at the document level. Re-running replaces the same student/week. MongoDB collections are automatically created on first insert; `init_mongo` adds unique/query indexes.

Alternative official CLIs:

```bash
python -m asls.cli student --backend mysql --student-id 101 --week 2026-10-19
python -m asls.cli student --backend mongodb --student-id 101 --week 2026-10-19
python -m asls.cli class --backend mongodb --class-id 10 --week 2026-10-19 --dry-run
```

The `--week` argument must be Monday and is also the **information cutoff** (no future grades used). Without `--week`, the CLI uses the Monday of the server-local current week.

## 4. REST API for your existing student/teacher applications

Development-only: **no authentication or authorization is supplied**. For that reason, run it on loopback only, not behind a public load balancer:

```bash
export ASLS_BACKEND=mysql       # or mongodb
uvicorn asls.api:app --host 127.0.0.1 --port 8000
```

- `GET /health`: process liveness (not DB health).
- `GET /students/101/recommendations?week=2026-10-19`: read-only compute.
- `GET /classes/10/recommendations?week=2026-10-19`: read-only compute and summarize.
- `POST /students/101/generate?week=2026-10-19`: compute and save.
- `POST /classes/10/generate?week=2026-10-19`: compute and save for class.

Interactive localhost docs: `http://127.0.0.1:8000/docs`.

Do not publish this development API for real student data. Add OIDC-based authentication, per-school tenant isolation, per-student/teacher authorization, audit logging, input validation, request throttling, and consent/retention policies before deployment.

## 5. Required input structure (both DBs)

| Collection / MySQL table | Required fields | Purpose |
|---|---|---|
| `sr_students` | `student_id`, `student_name`, `class_id`, `weekly_limit_minutes`, `daily_limit_minutes`, `target_score`, `active` | Student limits and goals |
| `sr_subjects` | `subject_id`, `subject_name` | Subject metadata |
| `sr_enrollments` | `student_id`, `subject_id` | Many-to-many student subjects |
| `sr_scores` | `student_id`, `subject_id`, `score`, `recorded_on` | Grade history, 0..100 scale |
| `sr_study_logs` | `student_id`, `subject_id`, `studied_on`, `minutes` | **Actual** study performed, not recommended time |
| `sr_availability` | `student_id`, `weekday`, `start_time`, `end_time` | Independent study windows |
| `sr_class_timetable` | `class_id`, `weekday`, `start_time`, `end_time`, `subject_id` | School classes and unavailability |
| `sr_assessments` | `class_id`, `subject_id`, `due_on`, `title` | Future assessment dates |
| `sr_recommendations` + `sr_plan_sessions` (MySQL) / `sr_plans` (MongoDB) | Generated allocations and sessions | Output |

**Weekdays**: `0=Monday`, ..., `6=Sunday`. MySQL dates are native `DATE`, times are `TIME`, and plan sessions use school-local `DATETIME`. MongoDB dates are ISO `YYYY-MM-DD` strings, times are `HH:MM`, and output sessions use local ISO datetimes. **The MVP assumes one school-local timezone**, no overnight availability, and a stable weekly timetable. For a multi-timezone production system, persist UTC instants plus IANA timezones and implement DST-aware recurrence.

### Working with an existing `tbl_student_score` table

If your existing grade history is stored in `tbl_student_score`, **do not rename or overwrite it**. Add a view or ETL projection to the new normalized `sr_scores` interface. Exact SQL depends on your current column names; for example, if the legacy columns truly are `student_id, subject_id, average_score, measured_on`:

```sql
INSERT INTO sr_scores (student_id, subject_id, score, recorded_on)
SELECT student_id, subject_id, average_score, measured_on
FROM tbl_student_score;
```

This example is **conditional on those columns existing** and is not a tested migration for an unknown legacy schema. Use idempotent synchronization logic and unique assessment identifiers in production to avoid duplicate grade rows.

## 6. Updating the data and automatic adaptation

1. Add new score observations (date, student, subject, score). The planner accepts even one grade; more history makes trend/mastery estimates useful.
2. Save **actual completed** study logs to `sr_study_logs`. Do not treat planned minutes as completed minutes.
3. Run the next weekly generation. The service looks back up to 365 days, pairs consecutive grade observations 3..45 days apart with study minutes in those intervals, computes clipped observed change/hour, and updates the hierarchical-smoothed subject/student-subject effectiveness estimates.
4. The adaptive effect changes the priority multiplier by **at most 20%**, never determines that a student should stop studying an essential subject, and does not imply causal learning gain.

Production improvements: transactional ingestion, deduplication of external assessment IDs, incremental learned statistics, confidence intervals, non-studied baselines, curricular topic-level mastery, graded intervention experiments, and model versioning.

## 7. Recommended operations

```bash
# Every Friday or Sunday, select a *future Monday* and generate next week's plans:
python -m asls.cli class --backend mysql --class-id 10 --week 2026-10-19

# Preview a class recommendation without any writes:
python -m asls.cli class --backend mysql --class-id 10 --week 2026-10-19 --dry-run

# Regression tests:
python -m unittest discover -s tests -v
```

Schedule a cron/systemd timer in your own deployment if you want this to run weekly. API and CLI share the same core planner. By default a class generation runs each student as a separate transaction; in MySQL a large class is **not** one all-or-nothing transaction, and in MongoDB all students are **not** replaced atomically together.

## 8. Known limitations (important)

- No proof of uplift or reliable grade forecasting from the simple outcome ratio. The design should be tested against a teacher-reviewed baseline with prospectively collected results.
- Dated study completion must actually be captured or learning adjustment remains neutral. Unlogged practice is **not** taken as zero practice.
- Does not yet optimize homework deadlines, prerequisites, accommodations, student preferences, tutoring obligations, holidays, partial-term schedules, or exact class scheduling changes. Subject priorities and times are advisory.
- Fixed 30-minute session granularity + 5-minute gaps rounds available time downward; 600-minute weekly allowance may result in fewer than 600 planned minutes.
- Does not force all exam-specific review before an exam, although pre-exam slots receive increased preference; add a hard-deadline constraint if that is required.
- No built-in authentication, school tenancy, access control, PII encryption, retention enforcement, or consent collection. Production deployment must add them.
- Simple multi-student learning history scan has bounded 365-day lookback, not incremental; at district scale add a materialized features pipeline.

## 9. Included files

```text
asls/core.py                     subject scoring, slots, scheduling, teacher summary
asls/learning.py                 conservative Bayesian-smoothed adaptive rates
asls/models.py                   backend-neutral data classes
asls/service.py                  generate/save orchestration
asls/storage/mysql_store.py      MySQL connector
asls/storage/mongo_store.py      MongoDB connector
asls/api.py                      development-only FastAPI application
asls/cli.py                      CLI + offline demo
asls/demo_data.py                synthetic sample student records
sql/schema.sql                   MySQL schema
scripts/init_mongo.py            MongoDB indexes
scripts/seed_mysql.py            MySQL synthetic demo seeder
scripts/seed_mongo.py            MongoDB synthetic demo seeder
tests/test_engine.py             unit/regression tests
docker-compose.yml               local demo databases
```

The companion whitepaper explains the mathematical objective, adaptive estimator, data assumptions, validation plan, and production rollout strategy.

## 10. Test evidence and validation scope

The repository passes **15 offline automated tests**, including conflicting class-time blocks, weekly/daily limits, spaced allocation, teacher aggregation, adaptive learning cutoffs, and MySQL-vs-MongoDB output parity exercised through test database shims. These tests **do not prove a live MySQL or live MongoDB deployment works**; before adopting the engine run the documented seed and generate commands against your own development instances, add integration tests in CI, and validate the business rules with teachers.

To rebuild the whitepaper DOCX, install optional document dependencies (`pip install -e ".[docs]"`) then run `python -m scripts.make_whitepaper`.
